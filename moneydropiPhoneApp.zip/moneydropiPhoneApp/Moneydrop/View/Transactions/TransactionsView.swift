//
//  TransactionsView.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI


struct TransactionsView: View {
    
    @State var transactionlist      =   [TransactionModel]()
    @State var order_by             =   "DESC"
    @State var no_of_page           =   1
    @State var total                =   0
    @State var index                =   0
 
    var body: some View {
        
        VStack{
            
            HStack {
                Spacer()
                Text("MY TRANSACTIONS")
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            
            //MARK: - Filter by date -
            
            .overlay(
                Menu {
                    Button(action: {
                        order_by    = "DESC"
                        no_of_page  =   1
                        getMyTransactionHistory()
                    }, label: { Text("Descending by date")  })
                    Button(action: {
                        order_by        =   "ASC"
                        no_of_page      =   1
                        getMyTransactionHistory()
                    }, label: { Text("Ascending by date")  })
                } label: {
                    HStack {
                        Text("SORT")
                            .padding(.vertical, 7)
                            .frame(maxWidth: .infinity)
                    }
                    .frame(width: 60)
                    .background(Color.yellowColor)
                    .foregroundColor(.black)
                    .cornerRadius(5)
                    .customFont(.bold, 14)
                    .padding(.trailing)
                }
                ,alignment: .trailing
            )
            
            VStack {
                
                ScrollView(.vertical, showsIndicators: false) {
                    
                    //MARK: - Transaction  list -
                    
                    LazyVGrid(columns: [GridItem(.flexible())], alignment: .leading) {
                        
                        ForEach(Array(transactionlist.enumerated()), id: \.offset) { index, element in
                            TransactionsRow(index: index, transaction: element)
                                .onAppear {
                                 if (transactionlist.last?._id ?? "") == element._id && total > transactionlist.count  {
                                    no_of_page += 1
                                    getMyTransactionHistory()
                                }
                            }
                        }
                        
                    }
                    .padding(.bottom, 90)
                }
                .background(emptyView(transactionlist.isEmpty))
            }
            .navigationBarHidden(true)
            .padding()
            .background(Color.lightGray.ignoresSafeArea())
        }
        .onAppear {
//            transactionlist = []
//            no_of_page = 1
            getMyTransactionHistory()
        }
    }
    
    //MARK: - My Transactions Api call -
    
    func getMyTransactionHistory() {
        
        if no_of_page == 1 {
          transactionlist = []
        }
        showProgressHUD()
        
        let parameter = [
            ApiKey.slug     : Storage.slug,
            ApiKey.sortBy   : "id",
            ApiKey.order    : order_by,
            ApiKey.page     : no_of_page
        ] as [String : Any]
        
        DataManager.getApiResponse(parameter, methodName: .getMyTransactionHistory) { json, error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                self.total  = json["model"]["total"].intValue
                for data in json["model"]["data"].arrayValue {
                    if self.transactionlist.filter({ $0.id == data.id}).count > 0 { return }
                    self.transactionlist.append(TransactionModel(data))
                }
            } else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
}

struct TransactionsView_Previews: PreviewProvider {
    static var previews: some View {
        TransactionsView()
    }
}

