//
//  SuccessfullPaymentView.swift
//  Money Drop
//
//  Created by Gipl on 05/12/22.
//

import SwiftUI

struct SuccessfullPaymentView: View {
    
    @Binding var transactionID    : String
    @Binding var currencyCode     : String
    @Binding var paymentAmount    : String
    @Binding var paymentType      : String
    @State var index = 0
    
    var body: some View {
        
        VStack {
            
            ScrollView {
                
                VStack(spacing: 20) {
                    
                    Image("check")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .padding(.top, ScreenSize.SCREEN_HEIGHT/6)
                    
                    if paymentType == "PayID" {
                        Text("Your payment will be initiated once you make payment to MoneyDrop.")
                            .customFont(.regular, 15)
                    } else {
                        Text("Transaction in progress.")
                            .customFont(.regular, 15)
                    }
                    
                    let amount = Double(paymentAmount)
                    Text(currencyCode + " " + amount!.price).customFont(.semibold, 15)
                    
                }
                .foregroundColor(Color.white)
                .multilineTextAlignment(.center)
                .padding()
                
                Button {
                    rootView()?.view.window?.rootViewController = UIHostingController(rootView: NavigationView { TabBarView(index: index) })
                } label: {
                    Text("Done")
                        .frame(maxWidth: .infinity)
                }
                .yellowButton()
                .padding(.top,20)
                .padding()
            }
        }
        .navigationBarHidden(true)
        .frame(maxWidth: .infinity)
        .background(Color.greenColor.ignoresSafeArea())
    }
}

struct SuccessfullPaymentView_Previews: PreviewProvider {
    static var previews: some View {
        SuccessfullPaymentView(transactionID: .constant(""), currencyCode: .constant(""), paymentAmount: .constant(""), paymentType: .constant(""))
    }
}
