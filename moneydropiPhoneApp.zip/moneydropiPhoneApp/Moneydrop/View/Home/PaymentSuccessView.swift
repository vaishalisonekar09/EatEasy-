//
//  PaymentSuccessView.swift
//  Moneydrop
//
//  Created by gipl on 13/12/23.
//

import SwiftUI

struct PaymentSuccessView: View {
    
   @State private var  isLoading =  false
    @Binding var tid    : String
    @Binding var monoova_pay_id    : String
    @Binding var currency_code     : String
    @Binding var final_amount      : String
    @Environment(\.presentationMode) var presentation

    var body: some View {
        
        VStack {
            
            HStack {
                
                Button(action: {
                    presentation.wrappedValue.dismiss()
                }, label: {
                    Image("back")
                    
                    
                })
                Spacer()
            }
           
            VStack(spacing: 10) {
                //
                HStack(spacing: 2) {
                    
                    Text("You have to pay")
                        .customFont(.regular, 15)
                    //
                    Text(final_amount + " " + currency_code)
                        .customFont(.bold, 15)
                }
                
                Text("make your payment easily from your banking app")
                    .customFont(.regular, 14)
                
                Image("monoova")
                    .padding([.top, .bottom])
                
                Text("PayId for YOUR INTERNET BANKING")
                    .customFont(.regular, 14)
                
                Text(monoova_pay_id)
                    .customFont(.bold, 15)
                    .accentColor(Color.black)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.bottom, 80)
            .foregroundColor(Color.blackTxtColor)
            .grayOuterShadow(5)
            .padding(.horizontal,15)
            
        }
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        .onAppear {
             getmonoovaTransferStatus()
        }
      
    }

    func getmonoovaTransferStatus()  {

        let parameter = [
            ApiKey.tid: tid]
        
        DataManager.getApiResponse( parameter, methodName: .getMonoovaTransStstus, completion: { json, error in
            
            if apiStatus(json) {

            } else {
          
            }
            
        })
    }
}


struct PaymentSuccessView_Previews: PreviewProvider {
    static var previews: some View {
        PaymentSuccessView(tid: .constant(""), monoova_pay_id: .constant(""), currency_code: .constant(""), final_amount:  .constant(""))
    }
}
