//
//  ChangePasswordView.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI

struct ChangePasswordView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @State var oldpassword                   = ""
    @State var newpassword                   = ""
    @State var confirmpassword               = ""
    
    @State var oldpass_error                 = ""
    @State var newpass_error                 = ""
    @State var confirmpass_error             = ""
    
    @State private var oldpasswordHidden     = false
    @State private var newpasswordHidden     = false
    @State private var confirmpasswordHidden = false
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
                Text("Change Password".uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            .padding(.horizontal)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(spacing: 0) {
                    
                    VStack(spacing: 0) {
                        
//                        CustomTextField(title: "Old Password", placeholder: "Enter old password", text: $oldpassword, star: true, isSecure: !oldpasswordHidden, rightImage: oldpasswordHidden ? "eye-open" : "eye-close") {
//                            oldpasswordHidden.toggle()
//                        }
                        
                        CustomTextFieldWithLabel(title: "Old Password",placeholder: "Enter old password" ,text: $oldpassword, star: true, isSecure : !oldpasswordHidden, errorMsg: $oldpass_error, rightView: AnyView (

                        Button(action: {
                            oldpasswordHidden.toggle()
                        }, label: {
                            Image(oldpasswordHidden ? "eye-open" : "eye-close")
                        })
                    ))
                        
//                        CustomTextField(title: "New Password", placeholder: "Enter new password", text: $newpassword, star: true, isSecure: !newpasswordHidden, rightImage: newpasswordHidden ? "eye-open" : "eye-close") {
//                            newpasswordHidden.toggle()
//                        }
                        
                        CustomTextFieldWithLabel(title: "New Password",placeholder:  "Enter new password" ,text: $newpassword, star: true, isSecure : !newpasswordHidden, errorMsg: $newpass_error, rightView: AnyView (

                        Button(action: {
                            newpasswordHidden.toggle()
                        }, label: {
                            Image(newpasswordHidden ? "eye-open" : "eye-close")
                        })
                    ))
                        
                        
//
//                        CustomTextField(title: "Confirm Password", placeholder: "Enter confirm password", text: $confirmpassword, star: true, isSecure: !confirmpasswordHidden, rightImage: confirmpasswordHidden ? "eye-open" : "eye-close") {
//                            confirmpasswordHidden.toggle()
//                        }
                        
                        CustomTextFieldWithLabel(title: "Confirm Password",placeholder:  "Enter confirm password" ,text: $confirmpassword, star: true, isSecure : !confirmpasswordHidden, errorMsg: $confirmpass_error, rightView: AnyView (

                        Button(action: {
                            confirmpasswordHidden.toggle()
                        }, label: {
                            Image(confirmpasswordHidden ? "eye-open" : "eye-close")
                        })
                    ))
                        
                        
                        
                    }
                    .padding(.vertical)
                    
                    Button {
                        //changePassword()
                      changeValidForm()
                    } label: {
                        Text("CHANGE PASSWORD")
                            .frame(maxWidth: .infinity)
                    }
                    .yellowButton()
                    .padding(.top, 50)
                }
                .padding(.horizontal)
                .navigationBarHidden(true)
            }
        }
        .onTapGesture {
            hideKeyboard()
        }
    }
    
    func changeValidForm() {
        
        oldpass_error = oldpassword.isEmpty ? Messages.enterOldPassword : ""
        newpass_error = newpassword.isEmpty ? Messages.enterNewPassword : ""
        confirmpass_error = confirmpassword.isEmpty ? Messages.enterConfirmPassword : ""
       
        
        if oldpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            
            oldpass_error = Messages.enterOldPassword
        
        } else if newpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            
            newpass_error = Messages.enterNewPassword
    
        }
        else if confirmpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            
            confirmpass_error =  Messages.enterConfirmPassword
            
        } else if newpassword != confirmpassword {
            
            confirmpass_error =  Messages.passwordMatch
          
        }

        
      if oldpass_error == "" &&   newpass_error == "" && confirmpass_error == "" {
          
          changePassword()
          
        }
    }
    
    
    //MARK: - Change Password Api call -
    
    func changePassword() {
        
        hideKeyboard()
        
        if ValidationClass().changePasswordForm(self) {
            
            let parameter = [
                ApiKey.slug             : Storage.slug,
                ApiKey.old_password     : oldpassword,
                ApiKey.new_password     : newpassword,
                ApiKey.confirm_password : confirmpassword
            ] as [String : Any]
            showProgressHUD()
            
            DataManager.getApiResponse(parameter, methodName: .changePassword) { json , error in
                dismissProgressHUD()
                if apiStatus(json) {
                    makeToast(apiMessage(json))
                    Storage.login = ""
                    clearStorage()
                    rootView()?.view.window?.rootViewController = UIHostingController(rootView:  LoginView() )
                } else {
                    makeToast(apiMessage(json))
                }
            }
            
        }
    }

}

struct ChangePasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ChangePasswordView()
    }
}

func validate(password: String) -> Bool  {
    // let regularExpression = "^(?=.*[0-9])" + "(?=.[a-z])(?=.[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$"
    let regularExpression = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,}"
    
//        let regularExpression = "^(?=.*[a-z])(?=.*\\d)(?=.*[$@#$!%*?&])[A-Za-z\\d$#@$!%*?&]{8,}"
    
    let passwordValidation = NSPredicate.init(format: "SELF MATCHES %@", regularExpression)
    return passwordValidation.evaluate(with: password)
}
