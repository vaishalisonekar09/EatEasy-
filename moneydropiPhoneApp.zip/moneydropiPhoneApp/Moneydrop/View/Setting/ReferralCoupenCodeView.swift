//
//  ReferralCoupenCodeView.swift
//  Moneydrop
//
//  Created by Gipl on 30/03/23.
//

import SwiftUI

struct ReferralCoupenCodeView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @State var shareCoupenCode = false
    
    @State var title        =   ""
    @State var description  =   ""
    @State var share_text   =   ""
    @State var my_referrer_code =   ""

    
    var body: some View {
        
        ScrollView {
            
            VStack (spacing: 15) {
                
                Image("refer-and-earn")
                    .resizable()
                    .scaledToFit()
                
                Text(title)
                    .font(headlineBold)
                
                Text(description)
                    .customFont(.regular, 14)
                    .padding(.horizontal, 25)
                
                HStack(spacing: 20) {
                    
                    VStack (spacing: 5) {
                        Text("Your referral code")
                            .customFont(.regular, 16)
                        
                        Text(my_referrer_code)
                            .customFont(.bold, 16)
                    }
                    Divider()
                    
                    Button {
                        UIPasteboard.general.string = my_referrer_code
                        makeToast("Copied")
                    } label: {
                        Text("COPY CODE")
                            .customFont(.regular, 16)
                    }
                    
                }
                .foregroundColor(Color.black)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding()
                .background(Color.lightGray)
                .cornerRadius(10)
                
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(style: StrokeStyle(lineWidth: 0.5, dash: [5.0]))
                )
                .padding(.horizontal, 10)
                .padding()
                
                Button {
                    shareCoupenCode.toggle()
                    
                } label: {
                    Text("Share")
                        .yellowButton()
                }
                .padding(.horizontal, 25)
                .padding(.bottom, 25)
                
            }
            .multilineTextAlignment(.center)
            .sheet(isPresented: $shareCoupenCode, content: {
                ShareSheet(activityItems: [share_text])
            })
            
        }
        .ignoresSafeArea()
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Refer & Earn".uppercased())
                    .customFont(.headingBrandon, 20)
                    .foregroundColor(Color.white)
            }
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image("back")
                        .renderingMode(.template)
                        .foregroundColor(Color.white)
                }
            }
        }
        .onAppear {
            referralSetting()
        }
    }
    
    //MARK: - Share and Earn Api call -
    
    func referralSetting() {
        
        var parameter = [:] as [String:Any]
        
        parameter = [ApiKey.slug : Storage.slug ]
        
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .referralSetting) { json, error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                let result          =   json.result
                self.title          =   result.title
                self.description    =  result["description"].stringValue
                self.share_text     = result["share_text"].stringValue
                self.my_referrer_code   = result["my_referrer_code"].stringValue
               // makeToast(apiMessage(json))
                
            } else {
                makeToast(apiMessage(json))
            }
        }
        
    }
        
}

struct ReferralCoupenCodeView_Previews: PreviewProvider {
    static var previews: some View {
        ReferralCoupenCodeView()
    }
}

