//
//  ContactUsView.swift
//  Moneydrop
//
//  Created by Gipl on 28/12/22.
//

import SwiftUI

struct ContactUsView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var first_name               =       Storage.first_name
    @State var last_name                =       Storage.last_name
    @State var email                    =       Storage.email
    @State var phone                    =       Storage.phone_number
    @State var dial_code                =       Storage.dial_code
    @State var subject                  =       ""
    @State var comment                  =       ""
    @State var commentPlaceholder       =       "Enter comment"
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image("back")
                }
                Spacer()
                Text("Contact Us".uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(spacing: 0) {
                    
                    CustomTextField(title: "First Name", placeholder: "Enter first name", text: $first_name, star: true).disabled(true)
                    CustomTextField(title: "Last Name", placeholder: "Enter last name", text: $last_name,  star: true).disabled(true)
                    CustomTextField(title: "Email", placeholder: "Enter your valid email", text: $email,  keyboard: .emailAddress, star: true).disabled(true)
                    NumberTextFieldView(title: "Phone Number", placeholder: "Enter your valid phone number", dial_code: $dial_code, text: $phone, star: true).disabled(true)
                    CustomTextField(title: "Subject", placeholder: "Enter subject", text: $subject,  star: true)
                    
                    VStack(alignment: .leading, spacing: 5) {
                        
                        HStack(spacing:0) {
                            Text("Comment")
                            Text("*").foregroundColor(Color.redColor)
                        }
                        .customFont(.semibold, 14)
                        
                        ZStack{
                            if comment.isEmpty{
                                TextEditor(text: $commentPlaceholder)
                                    .customFont(.regular, 15)
                                    .foregroundColor(Color.blackTxtColor)
                                    .disabled(true)
                            }
                            TextEditor(text: $comment)
                                .customFont(.regular, 15)
                                .opacity(comment.isEmpty ? 0.25 : 1)
                        }
                        .frame(height: 40)
                        .padding(EdgeInsets(top: 0, leading: -5, bottom: 0, trailing: 0))
                        .overlay(
                            Rectangle().fill(Color.greenColor).frame(height: 1)
                                .frame(maxWidth: .infinity)
                            // .offset(y: 5)
                            ,alignment: .bottomLeading
                        )
                    }
                    .multilineTextAlignment(.leading)
                    .frame(height: 75)
                    .frame(maxWidth: .infinity)
                    .foregroundColor(Color.blackTxtColor)
                    .padding(.top, 10)
                    
                    VStack{
                        Button { saveContact() } label: {
                            Text("SUBMIT")
                                .frame(maxWidth: .infinity)
                        }
                        .yellowButton()
                    }
                    .padding(.top, 60)
                    
                }
            }
        }
        .padding()
        .onTapGesture {
            hideKeyboard()
        }
        .navigationBarHidden(true)
    }
    
    //MARK: - Contact Us api call -
    
    func saveContact() {
        
        hideKeyboard()
        
        if ValidationClass().ContactUsForm(self) {
            
            let parameter = [
                ApiKey.first_name   : first_name.trimWhitespaces(),
                ApiKey.last_name    : last_name.trimWhitespaces(),
                ApiKey.email        : email.trimWhitespaces(),
                ApiKey.mobile       : phone,
                ApiKey.subject      : subject.trimWhitespaces(),
                ApiKey.comment      : comment.trimWhitespaces()
            ] as [String : Any]
            showProgressHUD()
            
            DataManager.getApiResponse(parameter, methodName: .saveContact) { json , error in
                
                dismissProgressHUD()
                if apiStatus(json) {
                    makeToast(apiMessage(json))
                    presentationMode.wrappedValue.dismiss()
                } else {
                    let is_logout = json["is_logout"].intValue
                    if is_logout == 1 {
                        // Deleted Account Logout
                        userAccountDelete()
                    }
                    else {
                        makeToast(apiMessage(json))
                    }
                }
            }
        }
    }
    
    
}

struct ContactUsView_Previews: PreviewProvider {
    static var previews: some View {
        ContactUsView()
    }
}


 
