//
//  UserAmountLogView.swift
//  Moneydrop
//
//  Created by Gipl on 05/04/23.
//

import SwiftUI

struct UserAmountLogView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var amount_log_list          =   [JSON]()
    
    @State var no_of_page               =   1
    @State var total                    =   0
    @State var site_currency            =   ""
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
                Text("My Amount Balance Log".uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .padding(.horizontal)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                LazyVGrid(columns: [GridItem(.flexible())], alignment: .leading) {
                    
                    ForEach(0..<amount_log_list.count, id: \.self) { i in
                        
                        VStack(alignment: .leading, spacing: 5) {
                            
                            HStack {
                                Text("Date")
                                Spacer()
                                let date = amount_log_list[i]["created_at"].stringValue
                                let createDate = date.convertFromISOFormat()
                                Text(createDate)
                            }
                            
                            HStack {
                                if amount_log_list[i]["debit_balance"].stringValue != "" {
                                    
                                    Text("Debit")
                                    Spacer()
                                    let debit_balance = Double(amount_log_list[i]["debit_balance"].stringValue)
                                    let debitAmt = debit_balance?.price
                                    
                                    Text("\(site_currency) \(debitAmt ?? "0.0")")
                                    
                                }  else {
                                    Text("Credit")
                                    Spacer()
                                    let credit_balance = Double(amount_log_list[i]["credit_balance"].stringValue)
                                    let creditAmt = credit_balance?.price
                                    
                                    Text("\(site_currency) \(creditAmt ?? "0.0")")
                                }
                            }
                            
                            
                            HStack {
                                Text("Balance")
                                Spacer()
                                let balance = Double(amount_log_list[i]["balance"].stringValue)
                                let balanceAmt = balance?.price
                                
                                Text("\(site_currency) \(balanceAmt ?? "0.0")")
                            }
                            
                            
                            Text(amount_log_list[i]["description"].stringValue)
                                .multilineTextAlignment(.leading)
                                .customFont(.regular, 15.8)
                                .foregroundColor(Color.lightBlackTxtColor)
                        }
                        .customFont(.semibold, 15.8)
                        .foregroundColor(Color.black)
                        .frame(maxWidth: .infinity)
                        .background(Color.white)
                        .padding()
                        .outerShadow()
                        .onAppear {
                            if (amount_log_list.last?.id ?? "") == amount_log_list[i].id && total > amount_log_list.count {
                                no_of_page += 1
                                getUserBalanceAmountLog()
                            }
                        }
                    }
                }
                
                .padding(.horizontal)
                .padding(.top)
            }
            .background(emptyView(amount_log_list.isEmpty))
        }
        .navigationBarHidden(true)
        .onAppear {
            getUserBalanceAmountLog()
        }
    }
    
    //MARK: - User Balance log API call -
    
    func getUserBalanceAmountLog() {
        
        let parameter = [  ApiKey.slug  : Storage.slug, ApiKey.page     : no_of_page ] as [String : Any]
        
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .getUserBalanceAmountLog) { json , error in
            dismissProgressHUD()
            if apiStatus(json) {
                
                 self.total  = json.model.total_record
                self.site_currency =    json.site_currency
                print(site_currency)
                
                for list in json["model"]["data"].arrayValue {
                    if self.amount_log_list.filter({$0.id == list.id}).count > 0 { return}
                    self.amount_log_list.append(list)
                }
                
                //makeToast(apiMessage(json))
            } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
 }

struct UserAmountLogView_Previews: PreviewProvider {
    static var previews: some View {
        UserAmountLogView()
    }
}
