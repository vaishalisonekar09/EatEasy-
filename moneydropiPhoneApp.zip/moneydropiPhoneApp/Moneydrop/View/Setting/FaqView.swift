//
//  FaqView.swift
//  Moneydrop
//
//  Created by Gipl on 30/12/22.
//

import SwiftUI
import WebKit

struct FaqView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @State var selectedIndex    = -1
    @State var faqs             = [JSON]()
    @State var text             = ""
    
    var body: some View {
        VStack {
            
            HStack{
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image("back")
                }
                Spacer()
                Text("FAQ".uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .padding(.horizontal)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                LazyVStack {
                    
                    ForEach(0..<faqs.count, id: \.self) { i in
                        
                        VStack(spacing: 0) {
                            
                            Button {
                                withAnimation {
                                    selectedIndex = selectedIndex == i ? -1 : i
                                }
                            } label: {
                                
                                HStack {
                                    Text(faqs[i].question)
                                        .customFont(.semibold, 14)
                                    Spacer()
                                    Image(systemName: selectedIndex == i ? "chevron.down" : "chevron.right")
                                }
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                                .padding(10)
                            }
                            
                            if selectedIndex == i {
                                FAQRow(faq: faqs[i]).padding(.horizontal, 5)
                            }
                        }
                        .foregroundColor(Color.blackTxtColor)
                        .outerShadow()
                        .padding(.horizontal)
                    }
                    
                }
                .padding(.top, 5)
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            getFaqList()
        }
    }
    
    //MARK: - getFaqList Api -
    
    func getFaqList() {
        showProgressHUD()
        DataManager.getApiResponse([:], methodName: .getFaqList) { json , error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.faqs = json["faq_data"].arrayValue
            } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
}

struct FaqView_Previews: PreviewProvider {
    static var previews: some View {
        FaqView()
    }
}

struct FAQRow: View {
    var faq: JSON
    @State var dynamicHeight: CGFloat = 0
    var body: some View {
        WebView(text: faq.answer, dynamicHeight: $dynamicHeight)
            .frame(height: dynamicHeight)
    }
}

 
