//
//  CMSView.swift
//  Moneydrop
//
//  Created by Gipl on 20/12/22.
//

import SwiftUI
import WebKit

struct CMSView: View {
    @Environment(\.presentationMode) var presentationMode
    var slug                = ""
    @State private var name = ""
    @State private var text = ""
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image("back")
                }
                Spacer()
                Text(name.uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            
            //MARK: - Webview open -
            
            VStack {
                WebView(text: text, dynamicHeight: .constant(0))
                .foregroundColor(.black)
            }
            Spacer()
        }
        .padding()
        .onAppear() {
            showCms()
        }
        .navigationBarHidden(true)
    }
    
    //MARK: - CMS api call -
    
    func showCms() {
        
        let parameter = [ApiKey.cms_slug : slug]
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .showCms) { json , error in
            
            dismissProgressHUD()
            if apiStatus(json) {
               // print(json["result"])
                self.name = json["result"]["name"].stringValue
                self.text = json["result"]["description"].stringValue
            }else{
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
}

struct CMSView_Previews: PreviewProvider {
    static var previews: some View {
        CMSView(slug: "")
    }
}

