//
//  ProfileView.swift
//  Moneydrop
//
//  Created by Gipl on 20/12/22.
//

import SwiftUI
import SDWebImageSwiftUI
import SDWebImage
import AVFoundation

struct ProfileView: View {
    
    @State var presentItem                  :   PresentItem<AnyView>?
    @State var shetPresentItem              :   PresentItem<AnyView>?
    @State var actionSheetItem              :   PresentItem<AnyView>?
    @State var alertItem                    :   AlertItem?
    
    @State var first_name               =   ""
    @State var last_name                =   ""
    @State var name                     =   ""
    @State var email                    =   Storage.email
    @State var dial_code                =   "+91"
    @State var phone_number             =   ""
    @State var passport_driving_no      =   ""
    @State var address                    =   ""
    @State var image_url                =   ""
    @State var zip_code                 =   ""
    @State var image                    =   UIImage(named: "no_image")!
    @State var image1                   =   UIImage(named: "no_image")!
    @State var isUploadImage            =   false
    @State var is_selfie_verify         =   0
    
    @State var first_name_error          =   ""
    @State var last_name_error           =   ""
    @State var name_error                =   ""
    @State var phone_number_error        =   ""
    @State var passport_driving_no_error =   ""
    @State var address_error             =   ""
    @State var image_url_error           =   ""
    @State var zip_code_error            =   ""
    @State var email_error               =   ""
    
    
    @State var verificationlist         =   [KeyValueModel]()
    @State var selectedDoc              =   KeyValueModel(id: "", value: "")
    
    @State var countrylist              =   [KeyValueModel]()
    @State var selectedCountry          =   KeyValueModel(id: "", value: "")
    
    @State var statelist                =   [KeyValueModel]()
    @State var selectedState            =   KeyValueModel(id: "", value: "")
    
    @State var citylist                 =   [KeyValueModel]()
    @State var selectedCity             =   KeyValueModel(id: "", value: "")
    
    @State var nationalityCountryList       =   [KeyValueModel]()
    @State var selectedNationalityCountry   =   KeyValueModel(id: "", value: "")
    
    @State var imageUploadActionSheet           = false
    @State var frontImageUploadActionSheet      = false
    @State var backImageUploadActionSheet       = false
    
    @State var frontUIimage                 =   UIImage()
    @State var backUIimage                  =   UIImage()
    
    @State var frontImageValidation         =   ""
    @State var backImageValidation          =   ""
    
    
    @State var national_id_countries        =   [JSON]()
    @State var dl_passport_countries        =   [JSON]()
    
    @State var user_upload_id_type          =   ""
    
    @State var upload_document      =   ""
    @State var national_id          =   ""
    @State var dl_image_1           =   ""
    @State var dl_image_2           =   ""
    @State var passport_image       =   ""
    
    @State var is_document_verify   =   0
    @State var is_document_deleted  =   0
    
    @State var frontImage   = ""
    @State var backImage    = ""
    
    @State var document_base_url = ""
    @State var document_verify_note = ""
    
    @State var dob =   Date()
    @State private var datePickerIdentifier = UUID()
    
    
    @State var loader = 0
    
    var body: some View {
        
        VStack {
            
            HStack {
                Spacer()
                Text("MY PROFILE")
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack {
                    
                    VStack(alignment: .center, spacing: 10) {
                        
                        //MARK: - Profile Image -
                        
                        Image(uiImage: image1)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 120, height: 120)
                            .clipped()
                            .clipShape(Circle())
                        
                        if is_selfie_verify != 1 {
                            
                            Button {
                                hideKeyboard()
                                imageUploadActionSheet.toggle()
                            } label: {
                                Text("Select Photo")
                                    .padding(.vertical, 10)
                                    .padding(.horizontal, 15)
                                    .customFont(.bold, 14)
                                    .foregroundColor(Color.white)
                            }
                            .background(Color.yellowColor)
                            .cornerRadius(5)
                        }
                        
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.horizontal, 10)
                    
                    .actionSheet(isPresented: $imageUploadActionSheet, content: {
                        
                        ActionSheet(title: Text(""), message: nil, buttons: [.default(Text("Camera"), action: {
                            
                            AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                                if granted {
                                    
                                    self.presentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .camera) { (image) in
                                        self.image = image
                                        updateProfileImage()
                                        
                                    }))
                                    
                                } else {
                                    
                                    alertItem = AlertItem(alert:  Alert(title: Text("Money Drop"), message: Text("You have not allowed access to your camera. Kindly allow from setting option of your device."), primaryButton: Alert.Button.cancel(), secondaryButton: Alert.Button.default(Text("OK"), action: {
                                        rootVC.self?.openSettings()
                                    })))
                                    
                                }
                            })
                        }), .default(Text("Photo Library"), action: {
                            
                            self.presentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .photoLibrary) { (image) in
                                self.image = image
                                updateProfileImage()
                            }))
                            
                        }), .cancel(Text("Cancel"))])
                    })
                    
                    VStack(alignment: .leading, spacing: 0) {
                        
                        Text("Profile").font(headlineBold)
                        
                        CustomTextFieldWithLabel(title: "First Name & Other Names", placeholder: "Enter your full given names", text: $first_name, star: true, errorMsg: $first_name_error).disabled(is_document_verify == 1 ? true : false)
                        CustomTextFieldWithLabel(title: "Last Name", placeholder: "Enter last name", text: $last_name,  star: true, errorMsg: $last_name_error).disabled(is_document_verify == 1 ? true : false)
                        CustomTextFieldWithLabel(title: "Email", placeholder: "Enter your valid email", text: $email,  keyboard: .emailAddress, star: true, errorMsg: $email_error).disabled(true)
                        
                        HStack (spacing: 0) {
                            Text("D.O.B").customFont(.semibold, 15)
                            Text("*")
                                .foregroundColor(Color.redColor)
                                .customFont(.semibold, 15)
                            
                            Spacer()
                            DatePicker("", selection: $dob, in: ...Calendar.current.date(byAdding: .year, value: -18, to: Date())!, displayedComponents: .date)
                                .id(datePickerIdentifier)
                                .datePickerStyle(.compact)
                                .labelsHidden()
                        }
                        .customFont(.regular, 15)
                        .foregroundColor(Color.blackTxtColor)
                        .frame(height: 40)
                        .overlay(
                            Rectangle().fill(Color.greenColor).frame(height: 1)
                                .frame(maxWidth: .infinity).offset(y:7)
                            ,alignment: .bottomLeading
                        )
                        .frame(height: 70)
                        .customFont(.regular, 15)
                        .disabled(is_document_verify == 1 ? true : false)
                        
       NumberTextFieldView(title: "Phone Number", placeholder: "Enter your valid phone number", dial_code: $dial_code, text: $phone_number, star: true)
                        
                        Group {
                            
                            VStack(alignment:.leading){
                                
                                Text("Address Details").font(headlineBold)
                                    .padding(.top)
                                    .multilineTextAlignment(.leading)
                                
                                CustomTextFieldWithLabel(title: "Address", text: $address, star: true, errorMsg: $address_error)
                                    .frame(height: 75, alignment: .leading)
                                    .foregroundColor(Color.blackTxtColor)
                                
                                VStack(alignment: .leading, spacing: 15) {
                                    
                                    HStack(spacing:0) {
                                        
                                        Text("Country")
                                        Text("*").foregroundColor(Color.redColor)
                                    }
                                    .customFont(.semibold, 14)
                                    .multilineTextAlignment(.leading)
                                    Menu {
                                        if countrylist.isEmpty {
                                            Text("Record not found")
                                        } else {
                                            
                                            ForEach (countrylist) { i in
                                                
                                                Button(action: {
                                                    
                                                    selectedCountry.id      =   i.id
                                                    selectedCountry.value   =   i.value
                                                    
                                                    selectedNationalityCountry.id    = i.id
                                                    selectedNationalityCountry.value = i.value
                                                    
                                                    selectedState.value     =   ""
                                                    selectedState.id        =   ""
                                                    selectedCity.id         =   ""
                                                    selectedCity.value      =   ""
                                                    
                                                    passport_driving_no     = ""
                                                    frontImageValidation    = ""
                                                    backImageValidation     = ""
                                                    
                                                    statelist               =   []
                                                    citylist                =   []
                                                    getStateList()
                                                    
                                                    if dl_passport_countries.contains(JSON(rawValue: selectedCountry.id)!) {
                                                        user_upload_id_type = "dl_passport_countries"
                                                    }
                                                    else if national_id_countries.contains(JSON(rawValue: selectedCountry.id)!) {
                                                        user_upload_id_type  = "national_id_countries"
                                                    }
                                                    else {
                                                        user_upload_id_type  = "upload_document"
                                                    }
                                                    
                                                }, label: {
                                                    Text(i.value)
                                                    if selectedCountry.id == i.id {
                                                        Image(systemName: "checkmark")
                                                    }
                                                })
                                            }
                                        }
                                    } label: {
                                        
                                        HStack {
                                            Text(selectedCountry.value != "" ? selectedCountry.value : "Select country")
                                                .foregroundColor(Color.gray)
                                            Spacer()
                                            Image("down-arrow").renderingMode(.template)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .overlay(
                                            Rectangle().fill(Color.gray).frame(height: 1)
                                                .frame(maxWidth: .infinity).offset(y:7)
                                            , alignment: .bottomLeading
                                        )
                                    }
                                }
                                .customFont(.regular, 15)
                                .frame(height: 75, alignment: .leading)
                                .foregroundColor(Color.blackTxtColor)
                                
                                VStack(alignment: .leading, spacing: 15) {
                                    HStack(spacing:0) {
                                        Text("Document Issuing Country")
                                        Text("*").foregroundColor(Color.redColor)
                                    }
                                    .customFont(.semibold, 14)
                                    .multilineTextAlignment(.leading)
                                    
                                    Menu {
                                        if nationalityCountryList.isEmpty {
                                            Text("Record not found")
                                        } else {
                                            ForEach (nationalityCountryList) { i in
                                                
                                                Button(action: {
                                                    
                                                    selectedNationalityCountry.id      =   i.id
                                                    selectedNationalityCountry.value   =   i.value
                                                    
                                                    selectedDoc.id          = ""
                                                    selectedDoc.value       = ""
                                                    passport_driving_no     = ""
                                                    frontImageValidation    = ""
                                                    backImageValidation     = ""
                                                    
                                                    if dl_passport_countries.contains(JSON(rawValue: selectedNationalityCountry.id)!) {
                                                        user_upload_id_type = "dl_passport_countries"
                                                    }
                                                    else if national_id_countries.contains(JSON(rawValue: selectedNationalityCountry.id)!) {
                                                        user_upload_id_type  = "national_id_countries"
                                                    }
                                                    else {
                                                        user_upload_id_type  = "upload_document"
                                                    }
                                                    
                                                }, label: {
                                                    Text(i.value)
                                                    if selectedNationalityCountry.id == i.id {
                                                        Image(systemName: "checkmark")
                                                    }
                                                })
                                            }
                                        }
                                    } label: {
                                        HStack {
                                            Text(selectedNationalityCountry.value != "" ? selectedNationalityCountry.value : "Select country")
                                                .foregroundColor(Color.gray)
                                            Spacer()
                                            Image("down-arrow").renderingMode(.template)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .overlay(
                                            Rectangle().fill(Color.gray).frame(height: 1)
                                                .frame(maxWidth: .infinity).offset(y:7)
                                            , alignment: .bottomLeading
                                        )
                                    }
                                }
                                .customFont(.regular, 15)
                                .frame(height: 75, alignment: .leading)
                                .foregroundColor(Color.blackTxtColor)
                                
                                
                                VStack(alignment: .leading, spacing: 15) {
                                    HStack(spacing:0) {
                                        Text("State")
                                        Text("*").foregroundColor(Color.redColor)
                                    }
                                    .customFont(.semibold, 14)
                                    .multilineTextAlignment(.leading)
                                    Menu {
                                        if statelist.isEmpty {
                                            Text("Record not found")
                                        } else {
                                            ForEach (statelist) { i in
                                                Button(action: {
                                                    selectedState.id    =   i.id
                                                    selectedState.value =   i.value
                                                    selectedCity.id     =   ""
                                                    selectedCity.value  =   ""
                                                    getCityList()
                                                }, label: {
                                                    Text(i.value)
                                                    if selectedState.id == i.id {
                                                        Image(systemName: "checkmark")
                                                    }
                                                })
                                            }
                                        }
                                    } label: {
                                        HStack {
                                            Text(selectedState.value != "" ? selectedState.value :  "Select state")
                                                .foregroundColor(Color.gray)
                                            Spacer()
                                            Image("down-arrow").renderingMode(.template)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .overlay(
                                            Rectangle().fill(Color.gray).frame(height: 1)
                                                .frame(maxWidth: .infinity).offset(y:7)
                                            , alignment: .bottomLeading
                                        )
                                    }
                                }
                                .customFont(.regular, 15)
                                .frame(height: 75, alignment: .leading)
                                .foregroundColor(Color.blackTxtColor)
                                
                                VStack(alignment: .leading, spacing: 15) {
                                    HStack(spacing:0) {
                                        Text("City")
                                        Text("*").foregroundColor(Color.redColor)
                                    }
                                    .customFont(.semibold, 14)
                                    .multilineTextAlignment(.leading)
                                    Menu {
                                        if citylist.isEmpty {
                                            Text("Record not found")
                                        }else{
                                            ForEach (citylist) { i in
                                                Button(action: {
                                                    selectedCity.id     = i.id
                                                    selectedCity.value  = i.value
                                                }, label: {
                                                    Text(i.value)
                                                    if selectedCity.id == i.id {
                                                        Image(systemName: "checkmark")
                                                    }
                                                })
                                            }
                                        }
                                    } label: {
                                        HStack {
                                            Text(selectedCity.value != "" ? selectedCity.value  : "Select city")
                                                .foregroundColor(Color.gray)
                                            Spacer()
                                            Image("down-arrow").renderingMode(.template)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .overlay(
                                            Rectangle().fill(Color.gray).frame(height: 1)
                                                .frame(maxWidth: .infinity).offset(y:7)
                                            , alignment: .bottomLeading
                                        )
                                    }
                                }
                                .customFont(.regular, 15)
                                .frame(height: 75, alignment: .leading)
                                .foregroundColor(Color.blackTxtColor)
                                //  CustomTextField(title: "Zip Code", placeholder: "Enter zip code", text: $zip_code)
                                
                                
                                
                                //MARK: - Document Verification Code -
                                
                                if is_document_deleted == 0 {
                                    
                                    //MARK: - If selected Australia and United State
                                    
                                    if user_upload_id_type == "dl_passport_countries" {
                                        
                                        VStack(alignment: .leading, spacing: 15) {
                                            HStack(spacing:0) {
                                                Text("Verification Type Here")
                                                Text("*").foregroundColor(Color.redColor)
                                            }
                                            .customFont(.semibold, 14)
                                            .multilineTextAlignment(.leading)
                                            
                                            Menu {
                                                if verificationlist.isEmpty {
                                                    Text("Record not found")
                                                } else {
                                                    ForEach (verificationlist) { i in
                                                        Button(action: {
                                                            selectedDoc.id = i.id
                                                            selectedDoc.value = i.value
                                                            print(i.id)
                                                            passport_driving_no = ""
                                                            frontImageValidation = ""
                                                            backImageValidation = ""
                                                        }, label: {
                                                            Text(i.value)
                                                            if selectedDoc.id == i.id {
                                                                Image(systemName: "checkmark")
                                                            }
                                                        })
                                                    }
                                                }
                                                
                                            } label: {
                                                HStack {
                                                    Text(selectedDoc.value != "" ? selectedDoc.value  :"Select type")
                                                        .customFont(.regular, 15)
                                                    Spacer()
                                                    Image("down-arrow")
                                                }
                                                .frame(maxWidth: .infinity)
                                                .overlay(
                                                    Rectangle().fill(Color.greenColor).frame(height: 1)
                                                        .frame(maxWidth: .infinity).offset(y:7)
                                                    , alignment: .bottomLeading
                                                )
                                            }
                                        }
                                        .frame(height: 75, alignment: .leading)
                                        .foregroundColor(Color.blackTxtColor)
                                        
                                        CustomTextField(title: selectedDoc.id == "" ? "Passport no / Driving License no" : selectedDoc.id == "passport" ? "Passport no" : "Driving License no", placeholder: "Enter details here", text: $passport_driving_no, star: true)
                                        
                                    }
                                    
                                    VStack(alignment: .leading, spacing: 0) {
                                        
                                        if is_document_verify == 0 || is_document_deleted == 0 {
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                
                                                //MARK: - Document verified -
                                                if is_document_verify == 0 {
                                                    
                                                    HStack( alignment: .top, spacing:0) {
                                                        
                                                        if user_upload_id_type != "dl_passport_countries" {
                                                            Text( user_upload_id_type == "national_id_countries" ? "Please upload national id" : "Please upload document")
                                                        } else {
                                                            if selectedDoc.id != "" {
                                                                Text(selectedDoc.id == "passport" ? "Please upload a copy of passport" : "Please upload front picture of license")
                                                            }
                                                            else {
                                                                Text("Please upload passport / driving license")
                                                            }
                                                        }
                                                        Text("*").foregroundColor(Color.redColor)
                                                        Spacer()
                                                        
                                                        
                                                        Button {
                                                            hideKeyboard()
                                                            frontImageUploadActionSheet.toggle()
                                                        } label: {
                                                            Image(systemName: "plus")
                                                                .padding(.vertical, 5)
                                                                .frame(maxWidth: .infinity)
                                                        }
                                                        .frame(width: 50)
                                                        .background(Color.yellowColor)
                                                        .foregroundColor(.black)
                                                        .cornerRadius(5)
                                                        .customFont(.bold, 16)
                                                    }
                                                    .multilineTextAlignment(.leading)
                                                    .customFont(.semibold, 14)
                                                }
                                                if !frontImageValidation.isEmpty {
                                                    VStack{
                                                        Image(uiImage: frontUIimage)
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(width: 200, height: 130)
                                                    }
                                                    .frame(height: 130)
                                                    .clipped()
                                                }
                                                
                                            }
                                            .clipped()
                                            .padding(.top, 5)
                                            .padding(.vertical, 10)
                                            .foregroundColor(Color.blackTxtColor)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .overlay(
                                                Rectangle().fill(Color.greenColor).frame(height: 1)
                                                    .frame(maxWidth: .infinity).offset(y:7)
                                                , alignment: .bottomLeading
                                            )
                                            .actionSheet(isPresented: $frontImageUploadActionSheet, content: {
                                                
                                                ActionSheet(title: Text(""), message: nil, buttons: [.default(Text("Camera"), action: {
                                                    
                                                    AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                                                        if granted {
                                                            
                                                            self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .camera) { (image) in
                                                                self.frontUIimage = image
                                                                frontImageValidation = "1"
                                                            }))
                                                            
                                                        } else {
                                                            
                                                            alertItem = AlertItem(alert:    Alert(title: Text("Money Drop"), message: Text("You have not allowed access to your contacts. Kindly allow from setting option of your device."), primaryButton: Alert.Button.cancel(), secondaryButton: Alert.Button.default(Text("OK"), action: {
                                                                rootVC.self?.openSettings()
                                                            })))
                                                            
                                                        }
                                                    })
                                                }), .default(Text("Photo Library"), action: {
                                                    
                                                    self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .photoLibrary) { (image) in
                                                        self.frontUIimage = image
                                                        frontImageValidation = "1"
                                                    }))
                                                    
                                                }), .cancel(Text("Cancel"))])
                                            })
                                            
                                        }
                                        //MARK: - Upload back copy of license -
                                        
                                        if user_upload_id_type == "dl_passport_countries" && selectedDoc.id == "driving_license"  {
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                
                                                if is_document_verify == 0 {
                                                    
                                                    HStack( alignment: .top, spacing:0) {
                                                        Text("Please upload back copy of license")
                                                        Text("*").foregroundColor(Color.redColor)
                                                        Spacer()
                                                        
                                                        Button {
                                                            hideKeyboard()
                                                            backImageUploadActionSheet.toggle()
                                                        } label: {
                                                            Image(systemName: "plus")
                                                                .padding(.vertical, 5)
                                                                .frame(maxWidth: .infinity)
                                                        }
                                                        .frame(width: 50)
                                                        .background(Color.yellowColor)
                                                        .foregroundColor(.black)
                                                        .cornerRadius(5)
                                                        .customFont(.bold, 16)
                                                        
                                                    }
                                                    .multilineTextAlignment(.leading)
                                                    .customFont(.semibold, 14)
                                                }
                                                
                                                if !backImageValidation.isEmpty {
                                                    VStack{
                                                        Image(uiImage: backUIimage)
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(width: 200, height: 130)
                                                    }
                                                    .frame(height: 130)
                                                    .clipped()
                                                }
                                            }
                                            .clipped()
                                            .padding(.top, 15)
                                            .padding(.vertical, 10)
                                            .foregroundColor(Color.blackTxtColor)
                                            .overlay(
                                                Rectangle().fill(Color.greenColor).frame(height: 1)
                                                    .frame(maxWidth: .infinity).offset(y:7)
                                                , alignment: .bottomLeading
                                            )
                                            .actionSheet(isPresented: $backImageUploadActionSheet, content: {
                                                
                                                ActionSheet(title: Text(""), message: nil, buttons: [.default(Text("Camera"), action: {
                                                    
                                                    AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                                                        if granted {
                                                            self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .camera) { (image) in
                                                                self.backUIimage = image
                                                                backImageValidation = "1"
                                                            }))
                                                        } else {
                                                            alertItem = AlertItem(alert:    Alert(title: Text("Money Drop"), message: Text("You have not allowed access to your contacts. Kindly allow from setting option of your device."), primaryButton: Alert.Button.cancel(), secondaryButton: Alert.Button.default(Text("OK"), action: {
                                                                rootVC.self?.openSettings()
                                                            })))
                                                        }
                                                    })
                                                }), .default(Text("Photo Library"), action: {
                                                    
                                                    self.presentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .photoLibrary) { (image) in
                                                        self.backUIimage = image
                                                        backImageValidation = "1"
                                                    }))
                                                    
                                                }),  .cancel(Text("Cancel"))])
                                            })
                                            
                                        }
                                    }
                                }
                                
                            }
                            .disabled(is_document_verify == 1 ? true : false)
                        }
                        
                        if is_document_verify == 1 {
                            VStack {
                                Text("*" + document_verify_note)
                                    .font(footnoteFont)
                                    .foregroundColor(Color.redColor)
                                    .italic()
                            }
                            .padding(.vertical)
                        }
                        
                        Button {
                            validProfileForm()
                            
                        } label: {
                            Text("UPDATE")
                                .frame(maxWidth: .infinity)
                        }
                        .yellowButton()
                        .padding(.top, 25)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 10)
                    .padding(.bottom, 90)
                }
                .navigationBarHidden(true)
                .frame(maxWidth: .infinity)
                .padding()
            }
        }
        .background(Color.lightGray.ignoresSafeArea())
        .onTapGesture {
            hideKeyboard()
        }
        
        .sheet(item: $shetPresentItem, content: { item in
            item.content
        })
        
        .fullScreenCover(item: $presentItem) { item in
            item.content
        }
        .alert(item: $alertItem, content: { item in
            item.alert
        })
        .onAppear {
            getUserProfileData()
        }
    }
    
    func validProfileForm() {
        
        first_name_error            = first_name.isEmpty ? Messages.enterName : ""
        last_name_error             = last_name.isEmpty ? Messages.enterLastName : ""
        name_error                  = name.isEmpty ? Messages.enterEmail : ""
        phone_number_error          = phone_number.isEmpty ? Messages.enterPhoneNumber : ""
        passport_driving_no_error   = passport_driving_no.isEmpty ? Messages.enterPassword : ""
        address_error               = address.isEmpty ? Messages.enterAddress : ""
        zip_code_error              = zip_code.isEmpty ? Messages.enterZipcode : ""
        email_error                 = email.isEmpty ? Messages.enterEmail : ""
        //address_one
        
       if  first_name_error == "" && last_name_error == "" && name_error == "" && phone_number_error == "" &&
            passport_driving_no_error == "" &&  address_error  == ""  && zip_code_error  == "" &&  email_error == "" {
           updateProfile()
       }
    }
    
    //MARK: - Update Profile Api call -
    
    func updateProfile() {
        
        var imageArr = [[String: Any]]()
        
        if user_upload_id_type == "dl_passport_countries" {
            
            //MARK: - Passport -
            
            if selectedDoc.id == "passport" {
                
                if let data = frontUIimage.jpegData(compressionQuality: 0.1) {
                    var image           =   [String: Any]()
                    image["imagename"]  =   "passport_image"
                    image["ext"]        =   "png"
                    image["imagedata"]  =   data
                    imageArr.append(image)
                }
                
            }
            
            //MARK: - Driving License -
            
            else {
                
                //MARK: - Front -
                
                if let data = frontUIimage.jpegData(compressionQuality: 0.1) {
                    var image           =   [String: Any]()
                    image["imagename"]  =   "dl_image_1"
                    image["ext"]        =   "png"
                    image["imagedata"]  =   data
                    imageArr.append(image)
                }
                
                //MARK: - Back -
                
                if let data = backUIimage.jpegData(compressionQuality: 0.1) {
                    var image           =   [String: Any]()
                    image["imagename"]  =   "dl_image_2"
                    image["ext"]        =   "png"
                    image["imagedata"]  =   data
                    imageArr.append(image)
                }
            }
            
        } else {
            
            //MARK: - National / Upload ID -
            
            if let data = frontUIimage.jpegData(compressionQuality: 0.1) {
                var image           =   [String: Any]()
                image["imagename"]  =   user_upload_id_type == "national_id_countries" ? "national_id" : "upload_document"
                image["ext"]        =   "png"
                image["imagedata"]  =   data
                imageArr.append(image)
            }
        }
        
        
        hideKeyboard()
        
        if ValidationClass().updatedProfileForm(self) {
            
            if is_document_deleted == 0 {
                
                //MARK: - Upload document Validation  -
                
                if user_upload_id_type == "dl_passport_countries" {
                    
                    if selectedDoc.id.isEmpty {
                        makeToast(Messages.selectVerification)
                        return
                    }
                    else if passport_driving_no.trimmingCharacters(in: .whitespaces).isEmpty {
                        if selectedDoc.id == "passport" {
                            makeToast(Messages.enterPassportDetails)
                        } else {
                            makeToast(Messages.enterDrivingDetails)
                        }
                        return
                    }
                    else if frontImageValidation.isEmpty {
                        if selectedDoc.id == "passport" {
                            makeToast(Messages.selectPassportCopy)
                        } else {
                            makeToast(Messages.selectFrontCopyOfLicense)
                        }
                        return
                    }
                    else if backImageValidation.isEmpty && selectedDoc.id == "driving_license" {
                        makeToast(Messages.selectBackCopyOfLicense)
                        return
                    }
                    
                } else {
                    //MARK: Toast For National Id and Document
                    if frontImageValidation.isEmpty {
                        makeToast(user_upload_id_type == "national_id_countries" ? "Please select national ID." : "Please select document.")
                        return
                    }
                }
            }
            
            
            var parameter = [String: Any]()
            
            //MARK: - Request for driving and passport -
            
            if user_upload_id_type == "dl_passport_countries" {
                
                parameter = [
                    ApiKey.slug         : Storage.slug,
                    ApiKey.first_name   : first_name.trimWhitespaces(),
                    ApiKey.last_name    : last_name.trimWhitespaces(),
                    ApiKey.email        : email,
                    ApiKey.dial_code    : dial_code,
                    ApiKey.phone        : phone_number,
                    ApiKey.verification_type: selectedDoc.id,
                    ApiKey.passport_driving_no: passport_driving_no,
                    ApiKey.country      : selectedCountry.id,
                    ApiKey.state        : selectedState.id,
                    ApiKey.city         : selectedCity.id,
                    ApiKey.address_one  : address.trimWhitespaces(),
                    ApiKey.nationality_country : selectedNationalityCountry.id,
                    ApiKey.dob          : dob.getDate1()
                ]
            } else {
                
                //MARK: - Request for national and document Id -
                
                parameter = [
                    ApiKey.slug         : Storage.slug,
                    ApiKey.first_name   : first_name.trimWhitespaces(),
                    ApiKey.last_name    : last_name.trimWhitespaces(),
                    ApiKey.email        : email,
                    ApiKey.dial_code    : dial_code,
                    ApiKey.phone        : phone_number,
                    ApiKey.country      : selectedCountry.id,
                    ApiKey.state        : selectedState.id,
                    ApiKey.city         : selectedCity.id,
                    ApiKey.address_one  : address.trimWhitespaces(),
                    ApiKey.nationality_country : selectedNationalityCountry.id,
                    ApiKey.dob          : dob.getDate1()
                ]
            }
            
            showProgressHUD()
            
            //MARK: - After delete document -
            
            if is_document_deleted == 1 {
                DataManager.getApiResponse(parameter, methodName: .updateUserProfileData) { json , error in
                    dismissProgressHUD()
                    if apiStatus(json) {
                        makeToast(apiMessage(json))
                        getUserProfileData()
                    } else {
                        makeToast(apiMessage(json))
                    }
                }
            } else {
                
                //MARK: - Before delete document -
                
                DataManager.getApiFileResponse(parameter, images: imageArr, methodName: .updateUserProfileData) { json, error in
                    dismissProgressHUD()
                    if apiStatus(json) {
                        makeToast(apiMessage(json))
                        getUserProfileData()
                    } else {
                        makeToast(apiMessage(json))
                    }
                }
            }
            
        }
    }
    
    
    //MARK: -GET User Profile Data Api call-
    
    func getUserProfileData() {
        
        let parameter = [ApiKey.slug: Storage.slug] as [String : Any]
        if loader == 0 {
            showProgressHUD()
        }
        DataManager.getApiResponse(parameter, methodName: .getUserProfileData) { json , error in
            
            dismissProgressHUD()
            
            
            if apiStatus(json) {
                
                loader = 1
                let result              = json.result
                let token               = Storage.token
                saveStorage(result)
                Storage.token           = token
                first_name              =   result.first_name
                last_name               =   result.last_name
                email                   =   result.email
                dial_code               =   result.dial_code
                phone_number            =   result.phone_number
                is_selfie_verify        =   result.is_selfie_verify
                
                selectedNationalityCountry.id       = result.nationality_country
                selectedNationalityCountry.value    = result.nationality_country_name
                
                selectedCountry.id      =   result.country
                selectedCountry.value   =   result.country_name
                
                selectedState.id        =   result.state
                selectedState.value     =   result.state_name
                selectedCity.id         =   result.city
                selectedCity.value      =   result.city_name
                address                 =   result.address_one
                selectedDoc.id          =   result.verification_type
                selectedDoc.value       =   result.verification_value
                passport_driving_no     =   result.passport_driving_no
                
                upload_document         =   result.upload_document
                national_id             =   result.national_id
                dl_image_1              =   result.dl_image_1
                dl_image_2              =   result.dl_image_2
                passport_image          =   result.passport_image
                
                is_document_verify      =   result.is_document_verify
                is_document_deleted     =   result.is_document_deleted
                
                document_base_url       =   result.document_base_url
                document_verify_note    =   result.document_verify_note
                
                let date_of_birth   = result["dob"].stringValue
                dob                 = date_of_birth.getDate1()
                
                getCountryList()
                getVerificationTypeList()
                
                Storage.image_url       =   result.image_url
                
                //MARK: - User Image  -
                
                SDWebImageManager.shared.loadImage(with: URL(string: result.image_url), options: [], progress: nil) { image, data, error, _, _, url in
                    if let image = image { self.image1 = image }
                }
                
            } else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
    //MARK: Update Profile Image Api call
    
    func updateProfileImage() {
        
        var imageArr = [[String:Any]]()
        
        if let data = image.jpegData(compressionQuality: 0.1) {
            var image           =   [String: Any]()
            image["imagename"]  =   "image"
            image["ext"]        =   "png"
            image["imagedata"]  =   data
            imageArr.append(image)
        }
        
        showProgressHUD()
        
        DataManager.getApiFileResponse([ApiKey.slug: Storage.slug], images: imageArr, methodName: .updateProfileImage) { json, error in
            
            dismissProgressHUD()
            if apiStatus(json) {
                makeToast(apiMessage(json))
                //MARK: - Getuser profile data api call -
                getUserProfileData()
            }else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
            
        }
    }
    
    
    //MARK: - getCountryList List Api Call -
    
    func getCountryList() {
        
        //showProgressHUD()
        
        DataManager.getApiResponse([:], methodName: .getCountryList) { json, error in
            // dismissProgressHUD()
            
            if apiStatus(json) {
                
                self.countrylist                =   json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                self.nationalityCountryList     =   json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                
                self.national_id_countries      =   json["national_id_countries"].arrayValue
                self.dl_passport_countries      =   json["dl_passport_countries"].arrayValue
                
                //MARK: - Upload document check Verify not verified -
                
                if dl_passport_countries.contains(JSON(rawValue: selectedNationalityCountry.id)!) {
                    
                    user_upload_id_type = "dl_passport_countries"
                    
                    if selectedDoc.id == "passport" {
                        frontImage = passport_image
                    } else {
                        frontImage  = dl_image_1
                        backImage   = dl_image_2
                    }
                }
                else if national_id_countries.contains(JSON(rawValue: selectedNationalityCountry.id)!) {
                    user_upload_id_type  = "national_id_countries"
                    frontImage  = national_id
                }
                else {
                    user_upload_id_type  = "upload_document"
                    frontImage  = upload_document
                }
                
                print(user_upload_id_type)
                print("+++++")
                print(frontImage)
                
                //MARK: - Front document upload image -
                
                SDWebImageManager.shared.loadImage(with: URL(string: document_base_url+frontImage), options: [], progress: nil) { image, data, error, _, _, url in
                    if let image = image {
                        self.frontUIimage = image
                        frontImageValidation = "1"
                    }
                }
                
                //MARK: - Back document upload image -
                
                SDWebImageManager.shared.loadImage(with: URL(string: document_base_url+backImage), options: [], progress: nil) { image, data, error, _, _, url in
                    if let image = image {
                        self.backUIimage = image
                        backImageValidation = "1"
                    }
                }
                
                statelist = []
                citylist = []
                getStateList()
                
            }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - getStateList Api call -
    
    func getStateList() {
        //showProgressHUD()
        DataManager.getApiResponse([ApiKey.country_id: selectedCountry.id], methodName: .getStateList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.statelist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                getCityList()
            }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - getCityList Api call -
    
    func getCityList() {
        // showProgressHUD()
        DataManager.getApiResponse([ApiKey.country_id: selectedCountry.id, ApiKey.state_id : selectedState.id], methodName: .getCityList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.citylist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
            }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - Verification Type List Api Call -
    
    func getVerificationTypeList() {
        //showProgressHUD()
        DataManager.getApiResponse([:], methodName: .getVerificationTypeList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.verificationlist = json["verificationType"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
            }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
