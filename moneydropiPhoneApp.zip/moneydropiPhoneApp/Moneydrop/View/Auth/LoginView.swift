//
//  LoginView.swift
//  Moneydrop
//
//  Created by Gipl on 08/12/22.
//

import SwiftUI
import ProgressHUD
import LocalAuthentication
import AVFoundation


struct LoginView: View {
    @State var email_error_msg          = ""
    @State var pass_error_msg       = ""
    @State private var email            =   ""
    @State private var password         =   ""
    @State var email_validate_string    =   ""
    @State private var showPassword     =   false
    @State private var presentItem      :   PresentItem<AnyView>?
    @State var selection                :   String?
    
    var body: some View {
        
        VStack {
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(alignment: .leading) {
                    Text("Hey!")
                        .customFont(.headingBrandon, 60)
                    Text("Welcome to Money Drop Transfer,\nPlease Login to continue.")
                        .customFont(.medium, 16)
                }
                .foregroundColor(Color.black)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 95)
                .padding(.bottom)
                
                VStack(spacing: 10) {
                    
                    
                    CustomTextFieldWithLabel(title: "Email", placeholder: "Enter your valid email", text: $email, fontSize: 16, keyboard: .emailAddress, star: true, disabled: true, errorMsg: $email_error_msg)
                    
                    CustomTextFieldWithLabel(title: "Password",placeholder: "Password" , text: $password, isSecure : !showPassword, errorMsg: $pass_error_msg , rightView: AnyView (
                        
                        Button(action: {
                            showPassword.toggle()
                        }, label: {
                            Image(systemName:   showPassword ? "eye-open" : "eye-close")
                        })
                    ))
                    

                    HStack(alignment: .top) {
                        Spacer()
                        Button {
                            self.presentItem = PresentItem(content: AnyView(ForgotPasswordView()))
                        } label: {
                            Text("Forgot password?")
                        }
                    }
                    .customFont(.regular, 14)
                    .foregroundColor(Color.redColor)
                    .padding(.top, -5)
                    
                    Button {
                        validLoginForm()
                    } label: {
                        
                        Text("LOG IN")
                            .yellowButton()
                            .frame(maxWidth: .infinity)
                    }
                    .padding(.vertical, 30)
                }
            }
            
            HStack(spacing : 4) {
                Text("Don't have an account?")
                    .foregroundColor(Color.blackTxtColor)
                Button {
                    self.presentItem = PresentItem(content: AnyView(RegisterView()))
                } label: {
                    Text("Sign up.").foregroundColor(Color.textGreen)
                        .customFont(.medium, 14)
                }
            }
            .customFont(.regular, 14)
            .padding(.vertical)
        }
        
        .onTapGesture {
            hideKeyboard()
        }
        .fullScreenCover(item: $presentItem) { item in
            item.content
        }
        .padding()
        .padding(.horizontal, 10)
//        .ignoresSafeArea()
        .edgesIgnoringSafeArea(.top)
        .onAppear {
            //MARK: Check authenticate values save in local storage
            if Storage.is_screen_lock && Storage.is_screen_lock_slug != "" {
                authenticate()
            }
            getVerificationTypeList()
        }
    }
    
    //MARK: - Device Authentication -
    
    func authenticate() {
        
        let context = LAContext()
        var error:NSError?
        
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            print(error?.localizedDescription)
            Storage.is_screen_lock = false
            return
        }

        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) {
            let reason = "We need to unlock your passwords."
            context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason, reply: { (success, error) in
                if success {
                        print(success.description)
                    biometric()
                }else {
                        print(error?.localizedDescription)
                }
            })
        }
        
    }
    
    
   // MARK: - BioMetric Api call -
    
    func biometric() {
        
        hideKeyboard()
        showProgressHUD()
        
        let parameter = [ApiKey.slug:Storage.is_screen_lock_slug]
        DataManager.getApiResponse(parameter, methodName: .biometric) { json, error  in
            dismissProgressHUD()
            if apiStatus(json) {
                let data = json.user_data
                Storage.slug = data.slug
                makeToast(apiMessage(json))
                if data["is_verified"].intValue == 0 {
                    self.presentItem = PresentItem(content: AnyView(VerifyView(verify_email: email, email_validate_string: data.email_validate_string, page_name: "account_verify")))
                }else {
                    saveStorage(data)
                    Storage.login = "yes"
                    rootView()?.view.window?.rootViewController = UIHostingController(rootView: NavigationView { TabBarView() })
                }
            }
            else {
                makeToast(apiMessage(json))
            }
        }
    }
   
    func validLoginForm() {
        
        email_error_msg = email.isEmpty ? Messages.enterEmail : ""
        pass_error_msg = password.isEmpty ? Messages.enterPassword : ""
        
        if email.isEmpty {
            email_error_msg = Messages.enterEmail
        } else if isValidEmail(email) {
            email_error_msg = Messages.enterValidEmail
        }
    
        if email_error_msg == "" &&  pass_error_msg == "" {
            callLoginApi()
        }
    }
    
    //MARK: - User login api call -
    
    func callLoginApi() {
        
        hideKeyboard()
        
        if ValidationClass().loginForm(email: email, password: password) {
            
            showProgressHUD()
            let parameter = [ApiKey.email:email, ApiKey.password :password]
            
            DataManager.getApiResponse(parameter, methodName: .login) { json, error  in
               dismissProgressHUD()
                
                if apiStatus(json) {
                    
                    let data = json.user_data
                    Storage.slug = data.slug
                    makeToast(apiMessage(json))
                    
                    if data["is_verified"].intValue == 0 {
                        self.presentItem = PresentItem(content: AnyView(VerifyView(verify_email: email, email_validate_string: data.email_validate_string, page_name: "account_verify")))
                    } else {
                        saveStorage(data)
                        Storage.login = "yes"
                        rootView()?.view.window?.rootViewController = UIHostingController(rootView: NavigationView { TabBarView() })
                    }
                    
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
    //MARK: - Verification Type List Api Call -
    
    func getVerificationTypeList() {
        DataManager.getApiResponse([:], methodName: .getVerificationTypeList) { json, error in
            
        }
    }
    
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}

func isValidEmail(_ EmailStr:String) -> Bool {
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
    let range = EmailStr.range(of: emailRegEx, options:.regularExpression)
    let result = range != nil ? true : false
    return !result
}
/*
 //
 //  RegisterView.swift
 //  Moneydrop
 //
 //  Created by Gipl on 08/12/22.
 //

 import SwiftUI
 import SDWebImageSwiftUI
 import SDWebImage
 import AVFoundation

 struct RegisterView: View {
     @Environment(\.presentationMode) var presentationMode
     
     @State var first_error_msg = ""
     @State var last_error_msg = ""
     @State var dial_error_msg = ""
     @State var phone_error_msg = ""
     @State var company_error_msg = ""
     @State var email_error_msg = ""
     @State var pass_error_msg = ""
     @State var confirm_error_msg = ""
     @State var state_error_msg = ""
     @State var city_error_msg = ""
     @State var address_error_msg = ""
     @State var country_error_msg = ""
     @State var nationality_error_msg = ""
     @State var upload_id_type_error  = ""
     @State var verification_type_msg  = ""
     @State var passport_driving_no_msg = ""
     @State var pass_upload_copy_error = ""
     @State var driving_upload_error = ""
     @State var selfie_image_error = ""
     @State var national_id_countries_error = ""
     
     @State var first_name                   =   ""
     @State var last_name                    =   ""
     @State var email                        =   ""
     @State var phone                        =   ""
     @State var dial_code                    =   "+91"
     @State var password                     =   ""
     @State var confirm_password             =   ""
     @State var passport_driving_no          =   ""
     @State var address                      =   ""
     @State var country                      =   ""
     @State var state                        =   ""
     @State var city                         =   ""
     
     @State var showPassword                 =   false
     @State var confirmShowPassword          =   false
     @State var presentItem                  :   PresentItem<AnyView>?
     @State var shetPresentItem              :   PresentItem<AnyView>?
     
     @State var verificationlist             =   [KeyValueModel]()
     @State var selectedDoc                  =   KeyValueModel(id: "", value: "")
     
     @State var nationalityCountryList       =   [KeyValueModel]()
     @State var selectedNationalityCountry   =   KeyValueModel(id: "", value: "")
     
     @State var countrylist                  =   [KeyValueModel]()
     @State var selectedCountry              =   KeyValueModel(id: "", value: "")
     
     @State var statelist                    =   [KeyValueModel]()
     @State var selectedState                =   KeyValueModel(id: "", value: "")
     
     @State var citylist                     =   [KeyValueModel]()
     @State var selectedCity                 =   KeyValueModel(id: "", value: "")
     
     @State var frontUIimage                 =   UIImage()
     @State var backUIimage                  =   UIImage()
     @State var selfieImage                  =   UIImage()
     
     
     @State var  showActionSheet             =   false
     @State var  showActionSheet1            =   false
     @State var  showPermissionError         =   false
     @State var  showCameraPicker            =   false
     @State var  showCameraPhotoLibrary      =   false
     
     @State var frontImageValidation         =   ""
     @State var backImageValidation          =   ""
     @State var selfieImageValidation        =   ""
     
     @State var national_id_countries        =   [JSON]()
     @State var dl_passport_countries        =   [JSON]()
     
     @State var upload_id_type               =   ""
     @State var referral_code                =   ""
     @State var capture_consent              =   false
     
     @State var dob                          =   Date()
     
     @State private var datePickerIdentifier = UUID()
     
     var body: some View {
         
         NavigationView{
             
             VStack{
                 
                 ScrollView(.vertical, showsIndicators: false) {
                     
                     VStack(alignment: .leading, spacing: 0) {
                         Text("Welcome")
                             .customFont(.headingBrandon, 60)
                         Text("Start creating account")
                             .customFont(.medium, 16)
                     }
                     .foregroundColor(Color.black)
                     .frame(maxWidth: .infinity, alignment: .leading)
                     .padding(.top, 95)
                     
                     LazyVStack(alignment: .leading, spacing: 0) {
                         
                         CustomTextFieldWithLabel(title: "First Name & Other Names", placeholder: "Enter your full given names", text: $first_name, star: true, errorMsg: $first_error_msg)
                         
                         CustomTextFieldWithLabel(title: "Last Name", placeholder: "Enter last name", text: $last_name,  star: true, errorMsg: $last_error_msg)
                         CustomTextFieldWithLabel(title: "Email", placeholder: "Enter your valid email", text: $email,  keyboard: .emailAddress, star: true, errorMsg: $email_error_msg)
                         
                         HStack(spacing: 0) {
                             
                             Text("D.O.B").customFont(.semibold, 15)
                             Text("*")
                                 .foregroundColor(Color.redColor)
                                 .customFont(.semibold, 15)
                             
                             Spacer()
                             DatePicker("", selection: $dob, in: ...Calendar.current.date(byAdding: .year, value: -18, to: Date())!, displayedComponents: .date)
                                 .id(datePickerIdentifier)
                                 .datePickerStyle(.compact)
                                 .labelsHidden()
                         }
                         .customFont(.regular, 15)
                         .foregroundColor(Color.blackTxtColor)
                         .frame(height: 40)
                         .overlay(
                             Rectangle().fill(Color.greenColor).frame(height: 1)
                                 .frame(maxWidth: .infinity).offset(y:7)
                             ,alignment: .bottomLeading
                         )
                         .frame(height: 70)
                         
                         NumberTextFieldViewWithLabel(title: "Phone Number", placeholder: "Enter your valid phone number", dial_code: $dial_code, text: $phone, star: true, errorMsg: $phone_error_msg)
                      
                         CustomTextFieldWithLabel(title: "Password",placeholder: "Password" , text: $password, isSecure : !showPassword, errorMsg: $pass_error_msg, rightView: AnyView (
                             
                             Button(action: {
                                 showPassword.toggle()
                             }, label: {
                                 Image(systemName:   showPassword ? "eye.slash" : "eye.fill")
                             })
                         ))
                         
                         CustomTextFieldWithLabel(title: "Confirm Password", placeholder: "Confirm Password" , text: $confirm_password, isSecure : !confirmShowPassword, errorMsg: $confirm_error_msg, rightView: AnyView (
                             
                             Button(action: {
                                 confirmShowPassword.toggle()
                             }, label: {
                                 Image(systemName:  confirmShowPassword ? "eye.slash" : "eye.fill")
                             })
                             
                         ))
                         
                     }
                     
                     Group {
                         
                         LazyVStack(alignment: .leading, spacing: 0) {
                             
                             VStack(alignment: .leading, spacing: 10) {
                                 
                                 Menu {
                                     if countrylist.isEmpty {
                                         
                                         Text("Record not found")
                                         
                                     } else {
                                         ForEach (countrylist) { i in
                                             
                                             Button(action: {
                                                 
                                                 selectedCountry.id      = i.id
                                                 selectedCountry.value   = i.value
                                                 
                                                 selectedNationalityCountry.id    = i.id
                                                 selectedNationalityCountry.value = i.value
                                                 
                                                 selectedState.id        = ""
                                                 selectedState.value     = ""
                                                 selectedCity.id         = ""
                                                 selectedCity.value      = ""
                                                 selectedDoc.id          = ""
                                                 selectedDoc.value       = ""
                                                 
                                                 passport_driving_no     = ""
                                                 frontImageValidation    = ""
                                                 backImageValidation     = ""
                                                 
                                                 statelist   = []
                                                 citylist    = []
                                                 getStateList()
                                                 
                                                 //MARK: - Check selected country, upload document type -
                                                 
                                                 if dl_passport_countries.contains(JSON(rawValue: selectedCountry.id)!) {
                                                     upload_id_type = "dl_passport_countries"
                                                 }
                                                 else if national_id_countries.contains(JSON(rawValue: selectedCountry.id)!) {
                                                     upload_id_type  = "national_id_countries"
                                                 }
                                                 else {
                                                     upload_id_type  = "upload_document"
                                                 }
                                                 
                                                 print(upload_id_type)
                                                 
                                             }, label: {
                                                 Text(i.value)
                                                 if selectedCountry.id == i.id {
                                                     Image(systemName: "checkmark")
                                                 }
                                             })
                                         }
                                     }
                                 } label: {
                                     
                                     DropDownFieldWithLabel(title: "Country", text: .constant(selectedCountry.value != "" ? selectedCountry.value  : "Select country") , star: true, is_error: $country_error_msg)
                                    
                                 }
                             }
                             .frame(height: 80, alignment: .leading)
                             .foregroundColor(Color.blackTxtColor)
                             
                             VStack(alignment: .leading, spacing: 10) {
           
                                 Menu {
                                     if nationalityCountryList.isEmpty {
                                         Text("Record not found")
                                     } else {
                                         ForEach (nationalityCountryList) { i in
                                             
                                             Button(action: {
                                                 
                                                 selectedNationalityCountry.id    = i.id
                                                 selectedNationalityCountry.value = i.value
                                                 
                                                 selectedDoc.id          = ""
                                                 selectedDoc.value       = ""
                                                 
                                                 passport_driving_no     = ""
                                                 frontImageValidation    = ""
                                                 backImageValidation     = ""
                                                 
                                                 //MARK: - Check selected country, upload document type -
                                                 
                                                 if dl_passport_countries.contains(JSON(rawValue: selectedNationalityCountry.id)!) {
                                                     upload_id_type = "dl_passport_countries"
                                                 }
                                                 else if national_id_countries.contains(JSON(rawValue: selectedNationalityCountry.id)!) {
                                                     upload_id_type  = "national_id_countries"
                                                 }
                                                 else {
                                                     upload_id_type  = "upload_document"
                                                 }
                                                 
                                                 print(upload_id_type)
                                                 
                                             }, label: {
                                                 Text(i.value)
                                                 if selectedNationalityCountry.id == i.id {
                                                     Image(systemName: "checkmark")
                                                 }
                                             })
                                         }
                                     }
                                 } label: {
                                     
                                     DropDownFieldWithLabel(title: "Document Issuing Country", text: .constant(selectedNationalityCountry.value != "" ? selectedNationalityCountry.value : "Select document issuing country") , star: true, is_error: $nationality_error_msg)
                                 }
                             }
                             .frame(height: 80, alignment: .leading)
                             .foregroundColor(Color.blackTxtColor)
                             
                             
                             VStack(alignment: .leading, spacing: 10) {

                                 Menu {
                                     if statelist.isEmpty {
                                         Text("Record not found")
                                     } else {
                                         ForEach (statelist) { i in
                                             Button(action: {
                                                 selectedState.id        = i.id
                                                 selectedState.value     = i.value
                                                 selectedCity.id         = ""
                                                 selectedCity.value      = ""
                                                 getCityList()
                                             }, label: {
                                                 Text(i.value)
                                                 if selectedState.id == i.id {
                                                     Image(systemName: "checkmark")
                                                 }
                                             })
                                         }
                                     }
                                 } label: {
                                     
                                     DropDownFieldWithLabel(title: "State", text: .constant(selectedNationalityCountry.value != "" ? selectedState.value : "Select state") , star: true, is_error: $state_error_msg)
                                 }
                         
                             }
                             .frame(height: 80, alignment: .leading)
                             .foregroundColor(Color.blackTxtColor)
                             
                             
                             VStack(alignment: .leading, spacing: 10) {
                            
                                 Menu {
                                     if citylist.isEmpty {
                                         Text("Record not found")
                                     } else {
                                         ForEach (citylist) { i in
                                             Button(action: {
                                                 selectedCity.id = i.id
                                                 selectedCity.value = i.value
                                             }, label: {
                                                 Text(i.value)
                                                 if selectedCity.id == i.id {
                                                     Image(systemName: "checkmark")
                                                 }
                                             })
                                         }
                                     }
                                 } label: {
                                     
                                     DropDownFieldWithLabel(title: "City", text: .constant(selectedCity.value != "" ?  selectedCity.value : "Select city") , star: true, is_error: $city_error_msg)
                                 }
 //
                             }
                             .frame(height: 80, alignment: .leading)
                             .foregroundColor(Color.blackTxtColor)
                             
                         }
                         
                         CustomTextFieldWithLabel(title: "Address", placeholder: "Enter address here", text: $address, star: true, errorMsg: $address_error_msg)
                             .frame(height: 80, alignment: .leading)
                             .foregroundColor(Color.blackTxtColor)
                         
                     }
                     
                     LazyVStack(alignment: .leading, spacing: 0) {
                         
                         if selectedNationalityCountry.id != "" {
                             
                             Group {
                                 
                                 //MARK: - upload Passport / Driving -
                                 
                                 if upload_id_type == "dl_passport_countries" {
                                     
                                     VStack(alignment: .leading, spacing: 10) {
                                        
                                         Menu {
                                             if verificationlist.isEmpty {
                                                 Text("Record not found")
                                             } else {
                                                 ForEach (verificationlist) { i in
                                                     
                                                     Button(action: {
                                                         
                                                         selectedDoc.id = i.id
                                                         selectedDoc.value = i.value
                                                         print(i.id)
                                                         passport_driving_no = ""
                                                         frontImageValidation = ""
                                                         backImageValidation = ""
                                                     }, label: {
                                                         Text(i.value)
                                                         if selectedDoc.id == i.id {
                                                             Image(systemName: "checkmark")
                                                         }
                                                     })
                                                 }
                                             }
                                             
                                         } label: {
                                             
         DropDownFieldWithLabel(title: "Verification Type Here", text: .constant(selectedDoc.value != "" ? selectedDoc.value  : "Select type") , star: true, is_error: $verification_type_msg)
                                             
                                         }
                                     
                                     }
                                     .frame(height: 80, alignment: .leading)
                                     .foregroundColor(Color.blackTxtColor)
                                     
                     CustomTextFieldWithLabel(title: selectedDoc.id == "" ? "Passport no / Driving License no" : selectedDoc.id == "passport" ? "Passport no" : "Driving License no", placeholder: "Enter details here", text: $passport_driving_no, star: true, errorMsg: $passport_driving_no_msg )
                                     
                                 }
                                 
                                 VStack(alignment: .leading, spacing: 0) {
                                     
                                     VStack(alignment: .leading, spacing: 15) {
                                         
                                         HStack( alignment: .top, spacing:0) {
                                             
                                             if upload_id_type != "dl_passport_countries" {
                                                 
                                                 Text( upload_id_type == "national_id_countries" ? "Please upload national id" : "Please upload document")
                                                 
                                             } else {
                                                 
                                                 if selectedDoc.id != "" {
                                                     Text(selectedDoc.id == "passport" ? "Please upload a copy of passport" : "Please upload front picture of license")
                                                 }
                                                 else {
                                                     Text("Please upload passport / driving license")
                                                 }
                                                 
                                             }
                                             Text("*").foregroundColor(Color.redColor)
                                             Spacer()
                                             Button {
                                                 hideKeyboard()
                                                 showActionSheet.toggle()
                                             } label: {
                                                 Image(systemName: "plus")
                                                     .padding(.vertical, 5)
                                                     .frame(maxWidth: .infinity)
                                             }
                                             .frame(width: 50)
                                             .background(Color.yellowColor)
                                             .foregroundColor(.black)
                                             .cornerRadius(5)
                                             .customFont(.bold, 16)
                                             
                                         }
                                         .multilineTextAlignment(.leading)
                                         .customFont(.semibold, 14)
                                         
                                         if !frontImageValidation.isEmpty {
                                             Image(uiImage: frontUIimage)
                                             .resizable()
                                             .scaledToFit()
                                             .frame(width: 130, height: 130)
                                             .clipped()
                                             .cornerRadius(8)
                                             
                                         }
                                         
                                     }
                                     .clipped()
                                     .padding(.top, 5)
                                     .padding(.vertical, 10)
                                     .foregroundColor(Color.blackTxtColor)
                                     .overlay(
                                         Rectangle().fill( pass_upload_copy_error != "" ? Color.red : Color.greenColor).frame(height: 1)
                                             .frame(maxWidth: .infinity).offset(y:7)
                                         , alignment: .bottomLeading
                                     )
                                   
                                     VStack(spacing: 0) {
                                                
                                                if pass_upload_copy_error != "" {
                                                    
                                                    Text(pass_upload_copy_error )
                                                        .customFont(.regular, 13)
                                                        .foregroundColor(.red)
                                                        .fixedSize(horizontal: false, vertical: true)
                                                    .offset(y:10)
                                                    
                                                }
                                            }
                                     
                                     .actionSheet(isPresented: $showActionSheet, content: {
                                         
                                         ActionSheet(title: Text(""), message: nil, buttons: [.default(Text("Camera"), action: {
                                             
                                             AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                                                 
                                                 if granted {
                                                     
                                                     self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .camera) { (image) in
                                                         self.frontUIimage = image
                                                         frontImageValidation = "1"
                                                     }))
                                                     
                                                 } else {
                                                     showPermissionError.toggle()
                                                 }
                                             })
                                         }), .default(Text("Photo Library"), action: {
                                             
                                             self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .photoLibrary) { (image) in
                                                 self.frontUIimage = image
                                                 frontImageValidation = "1"
                                             }))
                                             
                                             
 //                                             self.shetPresentItem = PresentItem(content: AnyView(MediaPicker(showsCrop: .rectangle(ratio: 1), completion: { image,image_name  in
 //                                                 self.frontUIimage = image
 //                                                frontImageValidation = "1"
 //                                             })))
                                             
                                         }), .cancel(Text("Cancel"))])
                                     })
                                     
                                     //MARK: - upload back copy of driving license -
                                     
                                     if upload_id_type == "dl_passport_countries" && selectedDoc.id == "driving_license"  {
                                         
                                         VStack(alignment: .leading, spacing: 10) {
                                             
                                             HStack( alignment: .top, spacing:0) {
                                                 Text("Please upload back copy of license")
                                                 Text("*").foregroundColor(Color.redColor)
                                                 Spacer()
                                                 Button {
                                                     hideKeyboard()
                                                     showActionSheet1.toggle()
                                                 } label: {
                                                     Image(systemName: "plus")
                                                         .padding(.vertical, 5)
                                                         .frame(maxWidth: .infinity)
                                                 }
                                                 .frame(width: 50)
                                                 .background(Color.yellowColor)
                                                 .foregroundColor(.black)
                                                 .cornerRadius(5)
                                                 .customFont(.bold, 16)
                                                 
                                             }
                                             .multilineTextAlignment(.leading)
                                             .customFont(.semibold, 14)
                                             if !backImageValidation.isEmpty {
                                                 
                                                 Image(uiImage: backUIimage)
                                                 .resizable()
                                                 .scaledToFit()
                                                 .frame(width: 130, height: 130)
                                                 .clipped()
                                                 .cornerRadius(8)
                                                 
 //                                                VStack{
 //                                                    Image(uiImage: backUIimage)
 //                                                        .resizable()
 //                                                        .scaledToFill()
 //                                                        .frame(width: 200, height: 130)
 //                                                }
 //                                                .frame(height: 130)
 //                                                .clipped()
                                             }
                                         }
                                         .clipped()
                                         .padding(.top, 15)
                                         .padding(.vertical, 10)
                                         .foregroundColor(Color.blackTxtColor)
                                         .overlay(
                                             Rectangle().fill(driving_upload_error != "" ? Color.red : Color.greenColor).frame(height: 1)
                                                 .frame(maxWidth: .infinity).offset(y:7)
                                             , alignment: .bottomLeading
                                         )
                                      VStack(spacing: 0) {
                                                 
                                                 if driving_upload_error != "" {
                                                     
                                                     Text(driving_upload_error )
                                                         .customFont(.regular, 13)
                                                         .foregroundColor(.red)
                                                         .fixedSize(horizontal: false, vertical: true)
                                                     .offset(y:10)
                                                     
                                                 }
                                             }
                                         .actionSheet(isPresented: $showActionSheet1, content: {
                                             
                                             ActionSheet(title: Text(""), message: nil, buttons: [.default(Text("Camera"), action: {
                                                 
                                                 AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                                                     
                                                     if granted {
                                                         
                                                         self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .camera) { (image) in
                                                             self.backUIimage = image
                                                             backImageValidation = "1"
                                                         }))
                                                         
                                                         
 //                                                         self.shetPresentItem = PresentItem(content: AnyView(MediaPicker(showsCrop: .rectangle(ratio: 1), completion: { image,image_name  in
 //                                                             self.backUIimage = image
 //                                                             backImageValidation = "1"
 //                                                         })))
                                                        
                                                         
                                                     } else {
                                                         showPermissionError.toggle()
                                                     }
                                                 })
                                             }), .default(Text("Photo Library"), action: {
                                                 
                                                 self.presentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .photoLibrary) { (image) in
                                                     self.backUIimage = image
                                                     backImageValidation = "1"
                                                 }))
 //                                                self.shetPresentItem = PresentItem(content: AnyView(MediaPicker(showsCrop: .rectangle(ratio: 1), completion: { image,image_name  in
 //                                                    self.backUIimage = image
 //                                                    backImageValidation = "1"
 //                                                })))
                                                 
                                             }),  .cancel(Text("Cancel"))])
                                         })
                                         
                                     }
                                 }
                             }
                         }
                         
                         VStack(alignment: .leading, spacing: 10) {
                             
                             HStack( alignment: .top, spacing:0) {
                                 
                                 Text("Please take a selfie")
                                 Text("*").foregroundColor(Color.redColor)
                                 Spacer()
                                 Button {
                                     hideKeyboard()
                                     AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { (granted: Bool) in
                                         
                                         if granted {
                                             
                                             self.shetPresentItem = PresentItem(content: AnyView(MediaPicker(showsCrop: .rectangle(ratio: 1), completion: { image,image_name  in
                                                 self.selfieImage = image
                                                  selfieImageValidation = "1"
                                             })))
                                             
 //                                            self.shetPresentItem = PresentItem(content: AnyView(ImagePicker(sourceType: .camera) { (image) in
 //                                                self.selfieImage = image
 //                                                selfieImageValidation = "1"
 //                                            }))
                                             
                                         } else {
                                             showPermissionError.toggle()
                                         }
                                     })
                                 } label: {
                                     Label("Take Selfie", systemImage: "camera")
                                         .frame(maxWidth: .infinity)
                                 }
                                 .frame(width: 150, height: 40)
                                 .background(Color.yellowColor)
                                 .foregroundColor(.black)
                                 .cornerRadius(5)
                                 .customFont(.bold, 16)
                                 
                             }
                             .multilineTextAlignment(.leading)
                             .customFont(.semibold, 14)
                             
                             if !selfieImageValidation.isEmpty {
                                 Image(uiImage: selfieImage)
                                     .resizable()
                                     .scaledToFit()
                                     .frame(width: 130, height: 130)
                                     .clipped()
                                     .cornerRadius(8)
                             }
                         }
                         .clipped()
                         .padding(.top, 15)
                         .padding(.vertical, 10)
                         .foregroundColor(Color.blackTxtColor)
                         .overlay(
                             Rectangle().fill(selfie_image_error != "" ? Color.red : Color.greenColor).frame(height: 1)
                                 .frame(maxWidth: .infinity).offset(y:5)
                             , alignment: .bottomLeading
                         )
                         .padding(.bottom, 10)
                         
                         if selfie_image_error != "" {
                             
                             Text(selfie_image_error)
                                 .customFont(.regular, 13)
                                 .foregroundColor(.red)
                                 .fixedSize(horizontal: false, vertical: true)
                                 //.offset(y:-5)
                                 
                         }
                         
                         CustomTextField(title: "Referral Code", placeholder: "Enter referral code", text: $referral_code,  star: false)
                         
                         HStack (alignment: .top){
                             
                             Button {
                                 capture_consent.toggle()
                             } label: {
                                 Image(capture_consent ? "checkbox-checked" : "checkbox")
                             }
                             
                             Text("I confirm that I am authorised to provide the personal details and I consent to the information being checked with the document issuer or official holder via third party systems for the purpose of confirming my identity.")
                                 .customFont(.semibold, 14)
                                 .foregroundColor(Color.black)
                                 .lineLimit(nil)
                             //.fixedSize(horizontal: false, vertical: true)
                             
                            
                             
                             
                         }
                         .padding(.top, 25)
                         
                     }
                     .alert(isPresented: $showPermissionError, content: {
                         Alert(title: Text("Money Drop"), message: Text("You have not allowed access to your contacts. Kindly allow from setting option of your device."), primaryButton: Alert.Button.cancel(), secondaryButton: Alert.Button.default(Text("OK"), action: {
                             rootVC.self?.openSettings()
                         }))
                     })
                     
                     VStack(spacing: 15) {
                         Button {
                             validateSignupForm()
                         } label: {
                             Text("REGISTER NOW")
                                 .frame(maxWidth: .infinity)
                         }
                         .yellowButton()
                         HStack(spacing: 0) {
                             Text("By signing, I agree to the ")
                                 .foregroundColor(Color.blackTxtColor)
                             NavigationLink(destination: CMSView(slug: "terms-conditions")) {
                                 Text("Terms and Conditions.").foregroundColor(Color.redColor)
                             }
                         }
                         .customFont(.regular, 14)
                     }
                     .padding(.vertical, 60)
                     
                     HStack(spacing:0) {
                         Text("Already have an account? ")
                             .foregroundColor(Color.blackTxtColor)
                         Button {
                             presentationMode.wrappedValue.dismiss()
                         } label: {
                             Text("Log in.")
                                 .foregroundColor(Color.textGreen)
                                 .customFont(.medium, 14)
                         }
                     }
                     .customFont(.regular, 14)
                     .padding(.vertical)
                 }
             }
             .onTapGesture {
                 hideKeyboard()
             }
             .sheet(item: $shetPresentItem, content: { item in
                 item.content
             })
             .fullScreenCover(item: $presentItem) { item in
                 item.content
             }
             .padding(.horizontal)
             .padding(.horizontal, 10)
             .edgesIgnoringSafeArea(.top)
             .navigationBarHidden(true)
             .onAppear{
                 getVerificationTypeList()
                 getCountryList()
             }
         }
     }
     
     
     func validateSignupForm() {
         
         first_error_msg            = first_name.isEmpty ? Messages.enterFirstName : ""
         last_error_msg             = last_name.isEmpty ? Messages.enterLastName : ""
         dial_error_msg             = dial_code.isEmpty ? Messages.selectDialCode : ""
         phone_error_msg            = phone.isEmpty ? Messages.enterPhoneNumber : ""
         email_error_msg            = email.isEmpty ? Messages.enterEmail : ""
         pass_error_msg             = password.isEmpty ? Messages.enterPassword : ""
         address_error_msg          = address.isEmpty ?  Messages.enterAddress : ""
         country_error_msg          = selectedCountry.id.isEmpty ? Messages.selectCountry : ""
         state_error_msg            = selectedState.id.isEmpty ? Messages.selectState : ""
         city_error_msg             = selectedCity.id.isEmpty ? Messages.selectCity : ""
         verification_type_msg      = selectedDoc.id.isEmpty ? Messages.selectVerification : ""
         nationality_error_msg      = selectedNationalityCountry.id.isEmpty ? Messages.selectNationalityCountry : ""
         passport_driving_no_msg    = selectedDoc.id.isEmpty ? "Please enter passport/driving License no" : ""
         pass_upload_copy_error     = selectedDoc.id.isEmpty ? "Please upload passport/driving License " : "" //
         driving_upload_error       = selectedDoc.id.isEmpty ? "Please upload passport/driving License" : ""
         selfie_image_error         = selfieImageValidation.isEmpty ? "Please take a selfie." : ""
     
         
         //--
         
         if upload_id_type == "dl_passport_countries" {
             
             if selectedDoc.id.isEmpty {
                 
                 verification_type_msg  = "Please select verification type."
                 
             }  else if passport_driving_no.isEmpty {
                 
                 if selectedDoc.id == "passport" {
                     
                     passport_driving_no_msg =   "Please enter passport no."
                     
                 } else {
                     passport_driving_no_msg = "Please enter driving license no."
                 }
             }   else if frontImageValidation.isEmpty {
                 
                 if selectedDoc.id == "passport" {
                     pass_upload_copy_error = "Please select a copy of passport."
                 }
                 else {
                     pass_upload_copy_error = "Please select front copy of license."
                 }
                 
             }  else if backImageValidation.isEmpty && selectedDoc.id == "driving_license" {
                 
                 driving_upload_error = "Please select back copy of license."
             }
         }
     
             
         if password != confirm_password  {
             confirm_error_msg = "Password and confirm password doesn't match."
         } else if confirm_password .isEmpty {
             confirm_error_msg = "Enter confirm password."
         } else {
             confirm_error_msg = ""
         }
         //--
         if first_error_msg == "" && last_error_msg == "" &&  dial_error_msg  == "" && email_error_msg == "" && pass_error_msg == "" && confirm_error_msg == "" && address_error_msg == "" &&  country_error_msg == "" &&  state_error_msg == "" &&   city_error_msg == "" &&  nationality_error_msg == "" &&   verification_type_msg == "" && passport_driving_no_msg == "" &&  driving_upload_error == "" &&  pass_upload_copy_error  == "" &&  selfie_image_error == "" {
             
             print("success")
             user_register()
         }
     }
     
     
     //MARK: - User register api call -
     
     func user_register() {
         
         hideKeyboard()
         
         var imageArr = [[String: Any]]()
         
         if upload_id_type == "dl_passport_countries" {
             
             //MARK: - Passport -
             
             if selectedDoc.id == "passport" {
                 
                 if let data = frontUIimage.jpegData(compressionQuality: 0.1) {
                     var image           =   [String: Any]()
                     image["imagename"]  =   "passport_image"
                     image["ext"]        =   "png"
                     image["imagedata"]  =   data
                     imageArr.append(image)
                 }
                 
             }
             
             //MARK: - Driving License -
             
             else {
                 
                 //MARK: - Front -
                 
                 if let data = frontUIimage.jpegData(compressionQuality: 0.1) {
                     var image           =   [String: Any]()
                     image["imagename"]  =   "dl_image_1"
                     image["ext"]        =   "png"
                     image["imagedata"]  =   data
                     imageArr.append(image)
                 }
                 
                 //MARK: - Back -
                 
                 if let data = backUIimage.jpegData(compressionQuality: 0.1) {
                     var image           =   [String: Any]()
                     image["imagename"]  =   "dl_image_2"
                     image["ext"]        =   "png"
                     image["imagedata"]  =   data
                     imageArr.append(image)
                 }
             }
             
         } else {
             
             //MARK: - National / Upload ID -
             
             if let data = frontUIimage.jpegData(compressionQuality: 0.1) {
                 var image           =   [String: Any]()
                 image["imagename"]  =   upload_id_type == "national_id_countries" ? "national_id" : "upload_document"
                 image["ext"]        =   "png"
                 image["imagedata"]  =   data
                 imageArr.append(image)
             }
         }
         
         if let data = selfieImage.jpegData(compressionQuality: 0.1) {
             var image           =   [String: Any]()
             image["imagename"]  =   "upload_selfie"
             image["ext"]        =   "png"
             image["imagedata"]  =   data
             imageArr.append(image)
         }
         
         //MARK: - Registration Validation and API call -
         
         if ValidationClass().registerForm(self) {
             
             //MARK: - Upload document validation -
             
             if upload_id_type == "dl_passport_countries" {
                 
                 if selectedDoc.id.isEmpty {
                     makeToast(Messages.selectVerification)
                     return
                 }
                 else if passport_driving_no.trimmingCharacters(in: .whitespaces).isEmpty {
                     if selectedDoc.id == "passport" {
                         makeToast(Messages.enterPassportDetails)
                     } else {
                         makeToast(Messages.enterDrivingDetails)
                     }
                     return
                 }
                 else if frontImageValidation.isEmpty {
                     if selectedDoc.id == "passport" {
                         makeToast(Messages.selectPassportCopy)
                     } else {
                         makeToast(Messages.selectFrontCopyOfLicense)
                     }
                     return
                 }
                 else if backImageValidation.isEmpty && selectedDoc.id == "driving_license" {
                     makeToast(Messages.selectBackCopyOfLicense)
                     return
                 }
                 
             } else {
                 
                 //MARK: - Toast For National Id and Document -
                 
                 if frontImageValidation.isEmpty {
                     makeToast(upload_id_type == "national_id_countries" ? "Please select national ID." : "Please select document.")
                     return
                 }
             }
             
             if selfieImageValidation.isEmpty {
                 makeToast("Please take a selfie.")
                 return
             }
             
             if !capture_consent {
                 makeToast("Please confirm the consent for your personal information.")
                 return
             }
             
             var parameter = [String: Any]()
             
             
             if upload_id_type == "dl_passport_countries" {
                 
                 //MARK: - Request for driving and passport -
                 
                 parameter = [ApiKey.first_name: first_name.trimWhitespaces(),
                              ApiKey.last_name: last_name.trimWhitespaces(),
                              ApiKey.email: email.trimWhitespaces(),
                              ApiKey.dial_code: dial_code,
                              ApiKey.phone: phone.trimWhitespaces(),
                              ApiKey.password: password,
                              ApiKey.confirm_password: confirm_password,
                              ApiKey.verification_type: selectedDoc.id,
                              ApiKey.passport_driving_no: passport_driving_no.trimWhitespaces(),
                              ApiKey.country: selectedCountry.id,
                              ApiKey.state: selectedState.id,
                              ApiKey.city: selectedCity.id,
                              ApiKey.address_one: address.trimWhitespaces(),
                              ApiKey.referral_code : referral_code.trimWhitespaces(),
                              ApiKey.nationality_country : selectedNationalityCountry.id,
                              ApiKey.capture_consent: capture_consent,
                              ApiKey.dob: dob.getDate1()
                 ]
             } else {
                 
                 //MARK: - Request for national and document Id -
                 
                 parameter = [ApiKey.first_name: first_name.trimWhitespaces(),
                              ApiKey.last_name: last_name.trimWhitespaces(),
                              ApiKey.email: email.trimWhitespaces(),
                              ApiKey.dial_code: dial_code,
                              ApiKey.phone: phone.trimWhitespaces(),
                              ApiKey.password: password,
                              ApiKey.confirm_password: confirm_password,
                              ApiKey.country: selectedCountry.id,
                              ApiKey.state: selectedState.id,
                              ApiKey.city: selectedCity.id,
                              ApiKey.address_one: address.trimWhitespaces(),
                              ApiKey.referral_code : referral_code.trimWhitespaces(),
                              ApiKey.nationality_country : selectedNationalityCountry.id,
                              ApiKey.capture_consent: capture_consent,
                              ApiKey.dob: dob.getDate1()
                 ]
             }
             
             showProgressHUD()
             
             DataManager.getApiFileResponse(parameter, images: imageArr, methodName: .signUp) { json, error in
                 
                 dismissProgressHUD()
                 if apiStatus(json) {
                     
                     makeToast(apiMessage(json))
                     Storage.slug = json.slug
                     
                     //MARK:  - Send Verify view -
                     
                     self.presentItem = PresentItem(content: AnyView(VerifyView(verify_email: email, email_validate_string: json.validateString, page_name: "account_verify")))
                     
                 } else {
                     makeToast(apiMessage(json))
                 }
             }
             
         }
     }
     
     //MARK: - Document Issuing Country API -
     
     func nationalityCountryAPI() {
         
         showProgressHUD()
         
         DataManager.getApiResponse([:], methodName: .getCountryList) { json, error in
             
             dismissProgressHUD()
             
             if apiStatus(json) {
                 
                 self.national_id_countries = json["national_id_countries"].arrayValue
                 self.dl_passport_countries = json["dl_passport_countries"].arrayValue
                 
             }else {
                 makeToast(apiMessage(json))
             }
         }
         
     }
     
     //MARK: - getCountryList List Api Call -
     
     func getCountryList() {
         
         showProgressHUD()
         
         DataManager.getApiResponse([:], methodName: .getCountryList) { json, error in
             
             dismissProgressHUD()
             
             if apiStatus(json) {
                 
                 self.countrylist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                 self.national_id_countries = json["national_id_countries"].arrayValue
                 self.dl_passport_countries = json["dl_passport_countries"].arrayValue
                 self.nationalityCountryList = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                 
                 selectedState.id        = ""
                 selectedState.value     = ""
                 selectedCity.id         = ""
                 selectedCity.value      = ""
                 statelist = []
                 citylist = []
             } else {
                 makeToast(apiMessage(json))
             }
         }
         
     }
     
     //MARK: - getStateList Api call -
     
     func getStateList() {
         
         showProgressHUD()
         DataManager.getApiResponse([ApiKey.country_id: selectedCountry.id], methodName: .getStateList) { json, error in
             dismissProgressHUD()
             if apiStatus(json) {
                 self.statelist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
             }else {
                 makeToast(apiMessage(json))
             }
         }
     }
     
     //MARK: - getCityList Api call -
     
     func getCityList() {
         
         showProgressHUD()
         DataManager.getApiResponse([ApiKey.country_id: selectedCountry.id, ApiKey.state_id : selectedState.id], methodName: .getCityList) { json, error in
             dismissProgressHUD()
             if apiStatus(json) {
                 self.citylist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
             }else {
                 makeToast(apiMessage(json))
             }
         }
     }
     
     
     //MARK: - Verification Type List Api Call -
     
     func getVerificationTypeList() {
         
         showProgressHUD()
         DataManager.getApiResponse([:], methodName: .getVerificationTypeList) { json, error in
             dismissProgressHUD()
             if apiStatus(json) {
                 self.verificationlist = json["verificationType"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
             }else {
                 makeToast(apiMessage(json))
             }
         }
     }
     
 }

 struct RegisterView_Previews: PreviewProvider {
     static var previews: some View {
         RegisterView()
     }
 }



 */
