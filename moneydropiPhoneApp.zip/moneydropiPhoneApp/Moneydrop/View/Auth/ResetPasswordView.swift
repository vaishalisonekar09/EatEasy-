//
//  ResetPasswordView.swift
//  Moneydrop
//
//  Created by Gipl on 28/12/22.
//

import SwiftUI

struct ResetPasswordView: View {
    
    @State var new_pass_error = ""
    @State var confirm_pass_error = ""
    
    @State var validate_string                  =   ""
    @State var newpassword                      =   ""
    @State var confirmpassword                  =   ""
    @State private var newpasswordHidden        =   false
    @State private var confirmpasswordHidden    =   false
    
    @State var presentItem          :   PresentItem<AnyView>?
    @Environment(\.presentationMode) var presentation
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button {
                    presentation.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
            }
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Reset Password")
                        .customFont(.headingBrandon, 30)
                }
                .foregroundColor(Color.black)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 50)
                
                VStack(spacing: 15) {
                    
                    CustomTextField(title: "New Password", placeholder: "Enter new password", text: $newpassword, star: true, isSecure: !newpasswordHidden, rightImage: newpasswordHidden ? "eye-open" : "eye-close") {
                        newpasswordHidden.toggle()
                    }
                    CustomTextField(title: "Confirm Password", placeholder: "Enter confirm password", text: $confirmpassword, star: true, isSecure: !confirmpasswordHidden, rightImage: confirmpasswordHidden ? "eye-open" : "eye-close") {
                        confirmpasswordHidden.toggle()
                    }
                    
                    Button {
                        resetValidForm()
                    } label: {
                        Text("RESET PASSWORD")
                            .frame(maxWidth: .infinity)
                    }
                    .yellowButton()
                    .padding(.vertical, 50)
                }
            }
        }
        .padding()
        .onTapGesture {
            hideKeyboard()
        }
        .fullScreenCover(item: $presentItem) { item in
            item.content
        }
        
    }
    
    func resetValidForm() {
        
        new_pass_error = new_pass_error.isEmpty ? Messages.enterPassword : ""
        
        if new_pass_error != confirm_pass_error {
            confirm_pass_error = Messages.passwordMatch
        } else if confirm_pass_error.isEmpty {
            confirm_pass_error = Messages.enterConfirmPassword
        } else {
            confirm_pass_error = ""
        }
        
        if new_pass_error  == "" && confirm_pass_error == "" {
            resetPasswordSave()
        }
        
    }
    
    
    //MARK: - Reset password validation with api call -
    
    func resetPasswordSave() {
        hideKeyboard()
        
        if ValidationClass().resetPasswordForm(self) {
            
            let parameter = [ApiKey.validate_string: validate_string,
                             ApiKey.password: newpassword,
                             ApiKey.confirm_password: confirmpassword] as [String : Any]
            showProgressHUD()
            
            DataManager.getApiResponse(parameter, methodName: .resetPasswordSave) { json , error in
                
                dismissProgressHUD()
                
                if apiStatus(json) {
                    makeToast(apiMessage(json))
                    rootView()?.view.window?.rootViewController = UIHostingController(rootView: LoginView())
                } else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
}

struct ResetPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ResetPasswordView()
        }
    }
}
