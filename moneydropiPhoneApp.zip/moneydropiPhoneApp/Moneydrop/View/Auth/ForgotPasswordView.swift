//
//  ForgotPasswordView.swift
//  Moneydrop
//
//  Created by Gipl on 28/12/22.
//

import SwiftUI

struct ForgotPasswordView: View {
    
    @Environment(\.presentationMode) var presentation
    @State var email_error_msg      =   ""
    @State var email                =   ""
    @State var validate_string      =   ""
    @State var presentItem          :   PresentItem<AnyView>?
    
    var body: some View {
        
        VStack{
            
            HStack {
                Button {
                    presentation.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
            }
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Forgot Password")
                        .customFont(.headingBrandon, 30)
                    Text("Please enter your email below, we will send you a verification code on your email.")
                        .customFont(.medium, 16)
                }
                .foregroundColor(Color.black)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 50)
                .padding(.bottom)
                
                VStack(spacing: 10) {
                    
                    CustomTextFieldWithLabel(title: "Email", placeholder: "Enter your valid email", text: $email, fontSize: 16, keyboard: .emailAddress, star: true, disabled: true, errorMsg: $email_error_msg)
                        .padding(.vertical)
                    
                    Button {
                        forgotValidForm()
                    } label: {
                        Text("RESET PASSWORD")
                            .frame(maxWidth: .infinity)
                    }
                    .yellowButton()
                    .padding(.vertical, 30)
                }
            }
        }
        .padding()
        .onTapGesture {
            hideKeyboard()
        }
        .fullScreenCover(item: $presentItem) { item in
            item.content
        }
    }
    
    func forgotValidForm() {
        
        email_error_msg = email.isEmpty ? Messages.enterEmail : ""
        
        if email.isEmpty {
            email_error_msg = Messages.enterEmail
        } else if isValidEmail(email) {
            email_error_msg = Messages.enterValidEmail
        }
        
       if email_error_msg == "" {
            forgotPassword()
        }
    }
    
    
    //MARK: - Forgot Password api call -
    
    func forgotPassword() {
        
        hideKeyboard()
        
        if ValidationClass().ForgotPasswordForm(self) {
            
            let parameter = [ApiKey.email: email] as [String : Any]
            showProgressHUD()
            
            DataManager.getApiResponse(parameter, methodName: .forgotPassword) { json , error in
                
                dismissProgressHUD()
                
                if apiStatus(json) {
                    makeToast(apiMessage(json))
                    Storage.slug = json["slug"].stringValue
                     self.presentItem = PresentItem(content: AnyView(VerifyView(verify_email: email, email_validate_string: json["validate_string"].stringValue, page_name: "forgot_password")))
                } else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
}

struct ForgotPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ForgotPasswordView()
    }
}
