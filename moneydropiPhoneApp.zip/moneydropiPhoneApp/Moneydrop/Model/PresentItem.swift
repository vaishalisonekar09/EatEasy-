//
//  PresentItem.swift
//  Moneydrop
//
//  Created by Gipl on 08/12/22.
//


import SwiftUI

struct PresentItem<Content: View>: Identifiable {
    var id = UUID().uuidString
    var content: Content
}
