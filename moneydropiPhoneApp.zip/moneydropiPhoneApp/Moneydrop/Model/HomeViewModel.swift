//
//  HomeViewModel.swift
//  Moneydrop
//
//  Created by Gipl on 28/02/23.
//

import SwiftUI
import UIKit


class HomeViewModel: NSObject, ObservableObject {
    
    @Published var source_country_id            =   ""
    @Published var received_country_id          =   ""
    @Published var sendAmount                   =   ""
    @Published var recipientAmount              =   ""
    @Published var senderCurrency               =   ""
    @Published var senderCountryFlag            =   ""
    @Published var recipientCurrency            =   ""
    @Published var recipientCountryFlag         =   ""
    @Published var processingFee                =   "10%"
    @Published var total_destination_currency   =   ""
    @Published var exchangeRate                 =   "1"
    @Published var recentactivity               =   [JSON]()
    @Published var amt_send_country             =   true
    @Published var conversion                   =   0
    @Published var api_call_status              =   0
    
    
    //MARK: - Get currency conversion values -
    
    func getCurrencyConversionValue() {
        // cancel previous request
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(getCurrencyConversion), object: nil)
        // schedule new request
        perform(#selector(getCurrencyConversion), with: nil, afterDelay: 0.3)
    }
    
    
    //MARK: - Get currency conversion api call -
    
    @objc func getCurrencyConversion() {
        
        if conversion != 0 {
            
            if (conversion == 1 ? sendAmount : recipientAmount).isEmpty {
                
                makeToast(conversion == 1 ? Messages.enterSentAmount : Messages.enterRecipientAmount);
                
                if conversion == 1 {
                    recipientAmount = ""
                } else {
                    sendAmount = ""
                }
                return
            }
            else if Double(conversion == 1 ? sendAmount : recipientAmount) ?? 0 <= 0 {
                
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                
//              makeToast(conversion == 1 ? Messages.enterCurrectSentAmount : Messages.enterCurrectRecipientAmount);
                
                makeToast(Messages.enterCorrectAmount);
                
                if conversion == 1 {
                    recipientAmount = ""
                } else {
                    sendAmount = ""
                }
                return
            }
        }
        
         let parameter = [
           // ApiKey.initial_amount   : (conversion == 0 ? 1 : (conversion == 2 ? recipientAmount : sendAmount)),
            ApiKey.initial_amount   : (conversion == 2 ? recipientAmount : sendAmount),
            ApiKey.source_currency  : (conversion == 2 ? recipientCurrency:  senderCurrency),
            ApiKey.required_currency: (conversion == 2 ? senderCurrency  : recipientCurrency),
            ApiKey.required_country :  received_country_id //(conversion == 2 ? source_country_id  :  received_country_id)
        ] as [String : Any]
        
        DataManager.getApiResponse(parameter, methodName: .getCurrencyConversion) { json, error in
            
 
            if apiStatus(json) {
                
                // makeToast(apiMessage(json))
                
                self.exchangeRate    = json.per_destination_currency
                
                if self.conversion == 0 {
                    //self.sendAmount = ""
                    self.sendAmount = self.sendAmount
                    self.recipientAmount = json.total_destination_currency
                }
                else if self.conversion == 2 {
                    self.amt_send_country = false
                    self.sendAmount = json.total_destination_currency
                } else {
                    self.amt_send_country = true
                    self.recipientAmount = json.total_destination_currency
                }
               
                //MARK: - Processing fee set -
                
                if json.site_transaction_charges_type == "Percentage" {
                    self.processingFee   = json.site_transaction_charges + "%"
                }
                else {
                    self.processingFee   = json.site_transaction_charges + " AUD"
                }
                self.api_call_status = 1
                
            }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
}
