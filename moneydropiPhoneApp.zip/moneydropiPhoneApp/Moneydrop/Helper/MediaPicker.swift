//
//  MediaPicker.swift
//  Moneydrop
//
//  Created by gipl on 12/12/23.
//

import SwiftUI
import YPImagePicker
import PhotosUI

struct MediaPicker: UIViewControllerRepresentable {
    
    var showsCrop: YPCropType = .none
    
    var completion: ((_ image: UIImage,  _ imageName : String) -> ()) = {_,_  in}
    
    func makeUIViewController(context: Context) -> YPImagePicker {
        var config = YPImagePickerConfiguration()
        config.showsCrop = showsCrop
        
        
        config.colors.cropOverlayColor = UIColor.black.withAlphaComponent(0.5)
        
        let picker = YPImagePicker(configuration: config)
        picker.didFinishPicking { [unowned picker] items, _ in
            if let photo = items.singlePhoto {
                var path = "\(UUID().uuidString).png"
                print(photo)
                self.completion(photo.image, path)
//                let imageName = "\(UUID().uuidString).png"

//                if let imagePath = saveImageToDocumentsDirectory(image: photo.image, imageName: imageName) {
//                                self.completion(photo.image, imagePath.path)
//                            }
            }
            picker.dismiss(animated: true, completion: nil)
        }
    
        return picker
    }
    
    func updateUIViewController(_ uiViewController: YPImagePicker, context: Context) {}
    
    typealias UIViewControllerType = YPImagePicker
    
}
 

func saveImageToDocumentsDirectory(image: UIImage, imageName: String) -> URL? {
    guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
        return nil
    }
    
    let fileURL = documentsDirectory.appendingPathComponent(imageName)
    
    do {
        try image.pngData()?.write(to: fileURL)
        return fileURL
    } catch {
        print("Error saving image: \(error.localizedDescription)")
        return nil
    }
}

