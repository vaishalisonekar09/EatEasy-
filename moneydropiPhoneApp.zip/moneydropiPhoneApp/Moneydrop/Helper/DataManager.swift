//
//  DataManager.swift
//  Mausool
//
//  Created by Gipl on 02/02/22.
//

import SwiftUI
import Foundation
import UIKit
import Alamofire

enum MethodName: String {
    
    case getCountryList
    case getStateList
    case getCityList
    case getVerificationTypeList
    case forgotPassword
    case resetPasswordSave
    case changePassword
    case login
    case logout
    case signUp
    case getUserProfileData
    case updateUserProfileData
    case updateProfileImage
    case saveRecipientUser
    case recipientUserList
    case getFaqList
    case showCms
    case getCurrencyConversion
    case currencyListWithFlag
    case saveContact
    case resendOtp
    case verifyOtp
    case deleteRecipientUser
    case deleteUserAccount
    case getJobList
    case getJobDetail
    case saveApplyJob
    case getMyTransactionHistory
    case getTransactionDetail
    case getRecentActivity
    case moneyTransfer
    case getFinalAmount
    case getTransactionResponce
    case biometric
    case getPayidBankDetails
    case getActiveBankList
    case getActiveCurrencieCountryList
    case checkBeneficiaryCurrency
    case allCurrencyListWithFlag
    case deleteApprovedUserDocument
    case applyCoupon
    case referralSetting
    case getUserBalanceAmountLog
    case  getMonoovaTransStstus
    
}



class DataManager {
    
    class func getVal(_ param:Any!) -> String {
        return "\(param ?? "")"
    }
    
    class func JSONStringify(_ value: [String: Any], prettyPrinted: Bool = false) -> String {
        let options = prettyPrinted ? JSONSerialization.WritingOptions.prettyPrinted : []
        if JSONSerialization.isValidJSONObject(value) {
            if let data = try? JSONSerialization.data(withJSONObject: value, options: options) {
                if let string = String(data: data, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue)) {
                    return string as String
                }
            }
        }
        return ""
    }
    
    class func getApiResponse(_ params : [String : Any],isLoading : Bool = true, methodName: MethodName,  completion : @escaping  ((_ json: JSON, _ error: Error?) -> Void)) {
        
        var deviceToken = Storage.deviceToken
        deviceToken = deviceToken == "" ? "123456" : deviceToken
        print("deviceToken", deviceToken)
        
        //let params = params
        
        var parameterDictionary = [String: Any]()
        parameterDictionary["method_name"]      = methodName.rawValue
        parameterDictionary["device_id"]        = deviceToken
        parameterDictionary["device_token"]     = deviceToken
        parameterDictionary["device_type"]      = "iphone"
        parameterDictionary["api_type"]         = "mobile"
        parameterDictionary["data"]             = params
        
        
        
        let jsonString = JSONStringify(parameterDictionary)
        let plainData = jsonString.data(using: String.Encoding.utf8)
        let base64String = plainData?.base64EncodedString(options: []) ?? ""
        
        let apiPath = Config.API_URL //+"1"
        
#if DEBUG
       // print("JWT Token: ", Storage.token)
        print("REQUESTING: ", apiPath)
       // print("REQ: ", base64String)
        print("PARAMS: ", JSON(parameterDictionary))
#endif
        
        let bodyData = ["req": base64String, "is_crypto": "0"]
        
        let headers: HTTPHeaders = ["Authorization": "Bearer \(Storage.token)"]
        
       // print(headers)
        let request = Alamofire.request(apiPath, method: .post, parameters: bodyData, headers : headers)
        loadDataFromURL(request: request, completion:{(response, error) -> Void in
            completion(response, error)
        })
    }
    
    
    class func getApiFileResponse(_ params : [String : Any], images: [[String: Any]], methodName: MethodName,  completion : @escaping  ((_ json: JSON, _ error: Error?) -> Void)) {
        
        var deviceToken = Storage.deviceToken
        deviceToken = deviceToken == "" ? "123456" : deviceToken
        
        let params = params
        
        var parameterDictionary = [String: Any]()
        parameterDictionary["data"] = params
        parameterDictionary["method_name"] = methodName.rawValue
        parameterDictionary["device_id"] = deviceToken
        parameterDictionary["device_token"] = deviceToken
        parameterDictionary["device_type"] = "iphone"
        
        let jsonString = JSONStringify(parameterDictionary)
        let plainData = jsonString.data(using: String.Encoding.utf8)
        let base64String = plainData?.base64EncodedString(options: []) ?? ""
        
#if DEBUG
        // print("JWT Token: ", Storage.token)
        print("REQUESTING: ", Config.API_URL)
        print("PARAMS: ", JSON(parameterDictionary))
#endif
        
        print(base64String)
        print(parameterDictionary)
        
        let bodyData = ["req": base64String, "is_crypto": "0"]
        
        let headers: HTTPHeaders = ["Authorization" : "Bearer \(Storage.token)"]
        
        
        Alamofire.upload(multipartFormData: { (multiPart) in
            for (key, value) in bodyData {
                multiPart.append("\(value)".data(using: .utf8) ?? Data(), withName: key)
            }
            print(images)
            for image in images {
                
                let imageName = image["imagename"] as! String
                let imageExt = image["ext"] as! String
                let imageData = image["imagedata"] as! Data
                
                var mime_type = ""
                
                if imageExt == "png" {
                    mime_type = "image/png"
                } else {
                    mime_type = "video/mov"
                }
                
                multiPart.append(imageData, withName: imageName, fileName: "\(UUID().uuidString).\(imageExt)", mimeType: mime_type)
            }
            print(multiPart)
            
        }, to: URL(string: Config.API_URL)! , headers : headers) { (response) in
            
            switch response {
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    
                    var jsonResult = JSON()
                    
                    if let data = response.data {
                        let cryptoString = String(data: data, encoding: .utf8) ?? ""
                        let base64String = cryptoString
                        
                        let decodedData = Data(base64Encoded: base64String, options: [])
                        
                        var jsonResult = JSON()
                        if let decodedData = decodedData {
                            do {
                                jsonResult = try JSON(data: decodedData)
                                print(jsonResult)
                            } catch {
                                jsonResult = ["status":"error","message": error.localizedDescription]
                                print(jsonResult)
                            }
                        } else {
                            jsonResult = ["status":"error","message": base64String]
                            print(jsonResult)
                        }
                        
                        completion(jsonResult, nil)
                    }
                }
                
            case .failure(let error):
                
                let jsonResult: JSON = ["status":"error", "message": error.localizedDescription]
                print(jsonResult)
                completion(jsonResult, error)
            }
        }
    }
    
    
    
    
    class func randomStringWithLength (_ len : Int) -> NSString {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let randomString : NSMutableString = NSMutableString(capacity: len)
        
        for _ in 0..<len {
            let length = UInt32 (letters.length)
            let rand = arc4random_uniform(length)
            randomString.appendFormat("%C", letters.character(at: Int(rand)))
        }
        return randomString
    }
    
    
    
    class  func loadDataFromURL(request: DataRequest, completion:@escaping (_ response: JSON, _ error: Error?) -> Void) {
        request.responseData { (response) in
            
            switch response.result {
            case .success:
                if let data = response.data {
                    let base64String = String(data: data, encoding: .utf8) ?? "" //cryptoString.aesDecrypt()
                    
                    let decodedData = Data(base64Encoded: base64String, options: [])
                    
                    var jsonResult = JSON()
                    if let decodedData = decodedData {
                        do {
                            jsonResult = try JSON(data: decodedData)
                        } catch {
                            jsonResult = ["status":"error","message": error.localizedDescription]
                        }
                    } else {
                        jsonResult = ["status":"error","message": base64String]
                    }
                    print(jsonResult)
                    completion(jsonResult, nil)
                    
                }
            case .failure(let error):
                
                let jsonResult: JSON = ["status":"error", "message": error.localizedDescription]
                print(jsonResult)
                completion(jsonResult, error)
            }
        }
        
        
    }
}


extension NSMutableData {
    func appendString(_ string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
        append(data!)
    }
}


func activityIndicator() -> UIActivityIndicatorView {
    let activityView = UIActivityIndicatorView(style: .medium)
    activityView.startAnimating()
    return activityView
}



