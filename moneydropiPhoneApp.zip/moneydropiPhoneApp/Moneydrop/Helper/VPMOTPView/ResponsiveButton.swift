//
//  ResponsiveButton.swift
//  Moneydrop
//
//  Created by Gipl on 20/12/22.
//

import Foundation
import UIKit

class ResponsiveButton: UIButton {
    
    internal override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let buttonSize = self.frame.size
        let widthToAdd = (44-buttonSize.width > 0) ? 44-buttonSize.width : 0
        let heightToAdd = (44-buttonSize.height > 0) ? 44-buttonSize.height : 0
        let largerFrame = CGRect(x: 0-(widthToAdd/2), y: 0-(heightToAdd/2), width: buttonSize.width+widthToAdd, height: buttonSize.height+heightToAdd)
        return (largerFrame.contains(point)) ? self : nil
    }
}
