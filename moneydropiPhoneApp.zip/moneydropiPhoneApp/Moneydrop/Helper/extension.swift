//
//  Extension.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI
import ProgressHUD
import AVFoundation
import UIKit
import LocalAuthentication

// MARK:-ProgressHUD
func showProgressHUD() {
    ProgressHUD.show(nil, interaction: false)
}

func dismissProgressHUD() {
    ProgressHUD.dismiss()
}

enum ScreenSize{
    static let SCREEN_HEIGHT: CGFloat = UIScreen.main.bounds.size.height
    static let SCREEN_WIDTH: CGFloat = UIScreen.main.bounds.size.width
}

 
extension UIImage {
    static var no_image            : UIImage { return UIImage(named: "no_image")! }
}

extension Image {
    static var no_image            : Image { return Image("no_image") //.resizable()
    }
}

func emptyView(_ show: Bool = true, message: String = "No Record(s) Found.") -> some View {
    return VStack {
        if show {
            Text(message).font(.subheadline)
        }
    }
}

extension UIImage {
    func resized(withPercentage percentage: CGFloat, isOpaque: Bool = true) -> UIImage? {
        let canvas = CGSize(width: size.width * percentage, height: size.height * percentage)
        let format = imageRendererFormat
        format.opaque = isOpaque
        return UIGraphicsImageRenderer(size: canvas, format: format).image {
            _ in draw(in: CGRect(origin: .zero, size: canvas))
        }
    }
    
    func resized(toWidth width: CGFloat, isOpaque: Bool = true) -> UIImage? {
        let canvas = CGSize(width: width, height: CGFloat(ceil(width/size.width * size.height)))
        let format = imageRendererFormat
        format.opaque = isOpaque
        return UIGraphicsImageRenderer(size: canvas, format: format).image {
            _ in draw(in: CGRect(origin: .zero, size: canvas))
        }
    }
 
}


extension View {
    func timeFormatted(_ totalSeconds: Int) -> String {
        let seconds: Int = totalSeconds % 60
        //let minutes: Int = (totalSeconds / 60) % 60
        //let hours: Int = totalSeconds / 3600
        return "00:"+String(format: "%02d",seconds)
    }
}

 
func rootView() -> UIViewController? {
    let vc = UIApplication.shared.topMostViewController()
    return vc
}

extension UIApplication {
    func topMostViewController() -> UIViewController? {
        return self.keyWindow?.rootViewController?.topMostViewController()
    }
}

var rootVC: UIViewController? {
    guard let scene = UIApplication.shared.connectedScenes.first,
          let sceneDelegate = scene as? UIWindowScene,
          let rootvc = sceneDelegate.windows.first?.rootViewController else { return nil }
    return rootvc
}

extension UIViewController {
    func topMostViewController() -> UIViewController {
        if let presented = self.presentedViewController {
            return presented.topMostViewController()
        }
        
        if let navigation = self as? UINavigationController {
            return navigation.visibleViewController?.topMostViewController() ?? navigation
        }
        
        if let tab = self as? UITabBarController {
            return tab.selectedViewController?.topMostViewController() ?? tab
        }
        return self
    }
    func openSettings(){
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {return}
        if UIApplication.shared.canOpenURL(settingsUrl) {
            UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                print("Settings opened: \(success)")
            })
        }
    }
}

extension UINavigationController {
    open override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        navigationBar.topItem?.backButtonDisplayMode = .minimal
    }
}


func makeToast(_ message: String) {
    DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
        rootView()?.view.makeToast(message: message)
    }
}


func apiStatus(_ dict: JSON) -> Bool {
    let status = dict["status"].stringValue
    return status == "success" ? true : false
}

func apiMessage(_ dict: JSON) -> String {
    
    var messageStr = ""
    
    for message in dict["message"].arrayValue {
        let msg = message["msg"].stringValue
        messageStr = messageStr.appending("\(msg)")
    }
    
    if messageStr == "" {
        messageStr = dict["message"].stringValue
    }
    return messageStr
}
 

extension FloatingPoint {
    var whole: Self { modf(self).0 }
    var fraction: Self { modf(self).1 }
}

extension Binding {
    func onChange(_ handler: @escaping (Value) -> Void) -> Binding<Value> {
        Binding(
            get: { self.wrappedValue },
            set: { newValue in
                self.wrappedValue = newValue
                handler(newValue)
            }
        )
    }
}

//MARK: Using Remove white space
extension String {
    func trimWhitespaces() -> String {
        return trimmingCharacters(in: .whitespaces)
    }
}

extension Double {
    func format(f: String) -> String {
        return String(format: "%\(f)f", self)
    }
    
    var price: String {
        //return String(format: "%.2f", self)
        let decimal = String(format: "%.2f", self.fraction)
        return df2so(self.whole)+decimal.dropFirst()
    }
   
    
    func df2so(_ price: Double) -> String {
        let numberFormatter = NumberFormatter()
        
        numberFormatter.groupingSeparator = ","
        
        numberFormatter.groupingSize = 3
        
        numberFormatter.usesGroupingSeparator = true
        
        numberFormatter.decimalSeparator = "."
        
        numberFormatter.numberStyle = .decimal
        
        numberFormatter.maximumFractionDigits = 2
        
        return numberFormatter.string(from: NSNumber(value: price)) ?? ""
    }
    
}
