//
//  Color.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI

extension Color {
    
    static var greenColor               :        Color { return Color("greenColor")     }
    static var blackTxtColor            :        Color { return Color("blackTxtColor")  }
    static var redColor                 :        Color { return Color("redColor")       }
    static var yellowColor              :        Color { return Color("yellowColor")    }
    static var lightyellow              :        Color { return Color("lightyellow")    }
    static var lightGray                :        Color { return Color("lightGray")      }
    static var lightGreen               :        Color { return Color("lightGreen")     }
    static var grayTxtColor             :        Color { return Color("grayTxtColor")   }
    static var textGreen                :        Color { return Color("textGreen")      }
    static var lightBlackTxtColor       :        Color { return Color("lightBlackTxtColor")  }
    static var wihteBorder              :        Color { return Color("wihteBorder")         }
    static var listLightGreenColor      :        Color { return Color("listLightGreenColor") }
    static var grayLightColor           :        Color { return Color("grayLightColor") }
}       
        
extension UIColor {
    static var greenColor       :        UIColor { return UIColor(named: "greenColor")!  }
    static var yellowColor      :        UIColor { return UIColor(named: "yellowColor")! }
    static var lightyellow      :        UIColor { return UIColor(named: "lightyellow")! }
    static var lightGray        :        UIColor { return UIColor(named: "lightGray")!   }
}

 
