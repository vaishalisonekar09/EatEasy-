//
//  CountryPickerView.swift
//  Moneydrop
//
//  Created by Gipl on 12/12/22.
//

import SwiftUI

struct CountryPickerView: View {
    
    @Binding var dial_code      : String
    @Binding var countryFlag    : String
    
    @Environment(\.presentationMode) var presentation
    
    @State private var countries        = [JSON]()
    @State private var filter_countries = [JSON]()
    @State private var search_text      = ""
    
    var body: some View {
        VStack(spacing:0) {
            
            HStack{
                Button{
                    presentation.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
            }
            .frame(height: 44)
            .padding(.horizontal)
            .overlay(
                Text("Countries".uppercased()).customFont(.headingBrandon, 20)
            )
            
            Divider()
            
            TextField("Search", text: $search_text)
                .frame(height: 44)
                .overlay(
                    Button(action: {
                        if !search_text.isEmpty {
                            self.search_text = ""
                        }
                    }, label: {
                        Image(systemName: "xmark")
                            .foregroundColor(!search_text.isEmpty ? Color.black : Color.white)
                            .font(.subheadline)
                    })
                    , alignment: .trailing
                )
                .padding(.horizontal)
                .onChange(of: search_text) {  newValue in
                    doSearch()
                }
            
            Divider()
            List{
                
                ForEach(0..<filter_countries.count, id: \.self) { i in
                    Button{
                        dial_code = filter_countries[i].dial_code
                        countryFlag = filter_countries[i].code
                        presentation.wrappedValue.dismiss()
                    } label:{
                        HStack(spacing: 10) {
                            Image(filter_countries[i].code.lowercased())
                                .resizable()
                                .frame(width: 30, height: 25)
                                .scaledToFit()
                            VStack(alignment: .leading, spacing: 4) {
                                Text(filter_countries[i].name)
                                Text(filter_countries[i].dial_code)
                                    .font(.subheadline)
                                    .foregroundColor(Color.black)
                            }
                            Spacer(minLength: 0)
                            
                            if dial_code ==  filter_countries[i].dial_code {
                                Image(systemName: "checkmark")
                            }
                            
                        }
                    }
                }
                
            }.listStyle(.plain)
            
        }.font(.subheadline)
            .foregroundColor(Color.black)
            .onAppear{
                loadData()
            }
    }
    func doSearch() {
        if search_text.isEmpty {
            filter_countries = countries
        }else {
            filter_countries = countries.filter {
                $0.name.range(of: search_text) != nil ||  $0.dial_code.range(of: search_text) != nil
            }
        }
    }
    
    func loadData() {
        guard let url = Bundle.main.url(forResource: "countries", withExtension: "json")
        else{
            print("Json file not found")
            return
        }
        let data = try? Data(contentsOf: url)
        let json = JSON(data ?? Data())
        self.countries = json.arrayValue
        doSearch()
    }
    
}

//struct CountryPickerView_Previews: PreviewProvider {
//    static var previews: some View {
//        CountryPickerView(dial_code: .constant(""))
//    }
//}
