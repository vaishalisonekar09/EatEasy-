//
//  RadioButtonView.swift
//  Moneydrop
//
//  Created by Gipl on 17/02/23.
//

import SwiftUI

struct RadioButtonView: View {
    var isSelected = false
    var title = "Poli Payment"
    var body: some View {
        HStack(spacing: 10) {
            Image(self.isSelected ? "radio-button-filled" : "radio-button")
            Text(self.title)
                .customFont(.regular, 14)
                .foregroundColor(Color.blackTxtColor)
        }
    }
}

struct RadioButtonView_Previews: PreviewProvider {
    static var previews: some View {
        RadioButtonView()
    }
}
