//
//  NumberTextField.swift
//  Moneydrop
//
//  Created by Gipl on 28/02/23.
//

import SwiftUI
import Combine

struct SendAmountTextField: View {
    
    var title               =   ""
    var placeholder         =   ""
    @Binding var text       :   String
    var fontSize            :   CGFloat = 14.0
    var onEditingChanged    :   ((_ : Bool) -> ()) = {_  in }
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 15) {
            
            Text(title).customFont(.semibold, fontSize)
                .foregroundColor(Color.white)
            
            ZStack(alignment: .leading) {
                
                if text.isEmpty {
                    Text(placeholder)
                        .foregroundColor(Color.gray)
                }
                TextField("", text: $text, onEditingChanged: { (isBegin) in
                    onEditingChanged(isBegin)
                })
                .keyboardType(.decimalPad)
                
                .onReceive(Just(text)) { newValue in
                    
                    //MARK: - Dot validation -
                    
                    let components = newValue.components(separatedBy: ".")
                    if components.count > 2 {
                        // More than one dot entered
                        self.text = components[0] + "." + components[1]
                    } else if components.count == 2 && components[1].count > 1 {
                        // Second dot entered
                        return
                    }
                }
            }
             .overlay(
                Rectangle().fill(Color.wihteBorder).frame(height: 1)
                    .frame(maxWidth: .infinity).offset(y:5)
                , alignment: .bottomLeading
             )
        }
        .multilineTextAlignment(.leading)
        .customFont(.regular, 15)
        .frame(maxWidth: .infinity)
        .frame(height: 75)
        .foregroundColor(Color.grayTxtColor)
    }
    
}

 

struct RecipientAmountTextField: View {
    
    var title               =   ""
    var placeholder         =   ""
    @Binding var text       :   String
    var fontSize            :   CGFloat = 14.0
    var onEditingChanged    :   ((_ : Bool) -> ()) = {_  in }
    var body: some View {
        
        VStack(alignment: .leading, spacing: 15) {
            
            Text(title).customFont(.semibold, fontSize)
                .foregroundColor(Color.white)
            
            ZStack(alignment: .leading) {
                
                if text.isEmpty {
                    Text(placeholder)
                        .foregroundColor(Color.gray)
                }
                TextField("", text: $text, onEditingChanged: { (isBegin) in
                    onEditingChanged(isBegin)
                })
                .keyboardType(.decimalPad)
                
                .onReceive(Just(text)) { newValue in
                    
                    //MARK: - Dot validation -
                    
                    let components = newValue.components(separatedBy: ".")
                    
                    if components.count > 2 {
                        // More than one dot entered
                        self.text = components[0] + "." + components[1]
                    } else if components.count == 2 && components[1].count > 1 {
                        // Second dot entered
                        return
                    }
                    
                }
            }
             .overlay(
                Rectangle().fill(Color.wihteBorder).frame(height: 1)
                    .frame(maxWidth: .infinity).offset(y:5)
                , alignment: .bottomLeading
             )
        }
        .multilineTextAlignment(.leading)
        .customFont(.regular, 15)
        .frame(maxWidth: .infinity)
        .frame(height: 75)
        .foregroundColor(Color.grayTxtColor)
    }
}



 
struct DropDownFieldWithLabel: View {
    
    var title           = ""
    var placeholder     = ""
    @Binding var text   : String
    var rightImage      = "down-arrow"
    var star = false
    @Binding var is_error: String

    var body: some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            if !title.isEmpty {
                
                HStack (spacing: 0) {
                    
                    if !title.isEmpty {
                        
                        Text(title)
                    }
                    if star {
                        Text("*")
                            .foregroundColor(Color.redColor)
                    }
                }
                .customFont(.semibold, 14)
                .multilineTextAlignment(.leading)
            }
            HStack {
                
                Text(text.isEmpty ? placeholder : text)
                    .frame(maxWidth: .infinity, alignment: .leading)
                  //  .frame(height: 44)
                
                if rightImage != "" {
                    Image(rightImage)
                }
                
            } .frame(height: 20)
             .foregroundColor(Color.blackTxtColor)
            .overlay(
                Rectangle().fill( is_error != "" ? Color.redColor : Color.greenColor).frame(height: 1)
                        .frame(maxWidth: .infinity).offset(y:7)
                ,alignment: .bottomLeading
            )
            if is_error != "" {
                
                    Text(is_error)
                    .customFont(.regular, 13)
                    .foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }
            
        }  .customFont(.regular, 15)
        .foregroundColor(Color.blackTxtColor)
        .multilineTextAlignment(.leading)

    }
}
