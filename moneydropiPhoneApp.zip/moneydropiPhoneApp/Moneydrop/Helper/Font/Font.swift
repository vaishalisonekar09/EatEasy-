//
//  Font.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI

//MARK: - Font Type
enum CustomFont : String{
    case regular            =       "OpenSans-Regular"
    case medium             =       "OpenSans-Medium"
    case bold               =       "OpenSans-Bold"
    case headingBrandon     =       "Brandon Grotesque Bold"
    case brandonRegular     =       "BrandonGrotesque-Regular"
    case semibold           =       "OpenSans-SemiBold"
    case light              =       "OpenSans-Light"
}

extension ContentSizeCategory {
    var size: CGFloat {
        switch self {
        case .small:
            return 12
        case .medium:
            return 14
        case .large:
            return 16
        case .extraLarge:
            return 20
        default:
            return 14
        }
    }
}

//MARK: - Custom Font Code Here

extension View {
    func customFont(_ font: CustomFont = .regular, _ size: CGFloat = 14) -> some View {
        return self.customFont(font.rawValue, size: size)
    }
    func customFont(_ font: CustomFont = .regular, _ category: ContentSizeCategory = .medium) -> some View {
        return self.customFont(font.rawValue, size: category.size)
    }
    func customFont(_ name: String, size: CGFloat) -> some View {
        return self.font(.custom(name, size: size))
    }
}


func system(size: CGFloat, weight: Font.Weight = .regular, design: Font.Design = .default) -> Font {
    var font = CustomFont.regular.rawValue
    switch weight {
    case .bold: font = CustomFont.bold.rawValue
    case .heavy: font = CustomFont.bold.rawValue
    case .medium: font = CustomFont.regular.rawValue
    case .semibold: font = CustomFont.bold.rawValue
    case .light: font = CustomFont.light.rawValue
    case .ultraLight: font = CustomFont.light.rawValue
    default: break
    }
    return Font.custom(font, size: size)
}


// Create a font with the large title text style.
public var largeTitleFont: Font{
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .largeTitle).pointSize)
}

// Create a font with the title text style
public var title1Font: Font{
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .title1).pointSize)
}


// Create a font with the title text style.
public var title1FontMedium: Font {
    return Font.custom(CustomFont.medium.rawValue, size: UIFont.preferredFont(forTextStyle: .title1).pointSize)
}

/// Create a font with the title text style.
public var title2Font: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .title2).pointSize)
}

 

/// Create a font with the title text style.
public var title2FontMedium: Font {
    return Font.custom(CustomFont.medium.rawValue, size: UIFont.preferredFont(forTextStyle: .title2).pointSize)
}

/// Create a font with the title text style.
public var title3Font: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .title3).pointSize)
}

/// Create a font with the title text style.
public var title3FontMedium: Font {
    return Font.custom(CustomFont.medium.rawValue, size: UIFont.preferredFont(forTextStyle: .title3).pointSize)
}

/// Create a font with the headline text style.
public var headlineFont: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .headline).pointSize)
}


/// Create a font with the headline text style.
public var headlineFontMedium: Font {
    return Font.custom(CustomFont.medium.rawValue, size: UIFont.preferredFont(forTextStyle: .headline).pointSize)
}

/// Create a font with the headline text style.
public var headlineBold: Font {
    return Font.custom(CustomFont.bold.rawValue, size: UIFont.preferredFont(forTextStyle: .headline).pointSize)
}

/// Create a font with the body text style.
public var bodyFont: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .body).pointSize)
}

/// Create a font with the subheadline text style.
public var subheadlineFont: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .subheadline).pointSize)
}

/// Create a font with the subheadline text style.
public var subheadlineFontMedium: Font {
    return Font.custom(CustomFont.medium.rawValue, size: UIFont.preferredFont(forTextStyle: .subheadline).pointSize)
}

public var subheadlineBold: Font {
    return Font.custom(CustomFont.bold.rawValue, size: UIFont.preferredFont(forTextStyle: .subheadline).pointSize)
}

/// Create a font with the callout text style.
public var calloutFont: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .callout).pointSize)
}

/// Create a font with the footnote text style.
public var footnoteFont: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .footnote).pointSize)
}

/// Create a font with the footnote text style.
public var footnoteBold: Font {
    return Font.custom(CustomFont.bold.rawValue, size: UIFont.preferredFont(forTextStyle: .footnote).pointSize)
}

/// Create a font with the caption text style.
public var captionFont: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .caption1).pointSize)
}
/// Create a font with the caption text style.
public var caption2Font: Font {
    return Font.custom(CustomFont.regular.rawValue, size: UIFont.preferredFont(forTextStyle: .caption2).pointSize)
}

struct FontDemo: View {
    var body: some View {
        VStack(spacing: 15) {
            Text("largeTitleFont \(Int(UIFont.preferredFont(forTextStyle: .largeTitle).pointSize))")
                .font(largeTitleFont)
            Text("titleFont1 \(Int(UIFont.preferredFont(forTextStyle: .title1).pointSize))")
                .font(title1Font)
            Text("titleFont2 \(Int(UIFont.preferredFont(forTextStyle: .title2).pointSize))")
                .font(title2Font)
            Text("titleFont3 \(Int(UIFont.preferredFont(forTextStyle: .title3).pointSize))")
                .font(title3Font)
            Text("headlineFont \(Int(UIFont.preferredFont(forTextStyle: .headline).pointSize))")
                .font(headlineFont)
            Text("bodyFont \(Int(UIFont.preferredFont(forTextStyle: .body).pointSize))")
                .font(bodyFont)
            Text("subheadlineFont \(Int(UIFont.preferredFont(forTextStyle: .subheadline).pointSize))")
                .font(subheadlineFont)
            Group {
                Text("calloutFont \(Int(UIFont.preferredFont(forTextStyle: .callout).pointSize))")
                    .font(calloutFont)
                Text("footnoteFont \(Int(UIFont.preferredFont(forTextStyle: .footnote).pointSize))")
                    .font(footnoteFont)
                Text("caption1Font \(Int(UIFont.preferredFont(forTextStyle: .caption1).pointSize))")
                    .font(captionFont)
                Text("caption2Font \(Int(UIFont.preferredFont(forTextStyle: .caption2).pointSize))")
                    .font(captionFont)
            }
        }
    }
}

struct Font_Previews: PreviewProvider {
    static var previews: some View {
        FontDemo()
    }
}
