//
//  CouponsListView.swift
//  AxisVD
//
//  Created by Gipl on 22/09/23.
//

import SwiftUI

struct CouponsListView: View {
    
    var body: some View {
        
        VStack {
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 15) {
                    
                    ForEach(0..<10) { i in
                        Image("coupon")
                            .resizable()
                            .scaledToFit()
                    }
                }
                .padding()
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("COUPON LIST")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                Image("search-white")
            }
        }
    }
    
    func couponRow() -> some View {
        HStack {
            
        }
    }
}

struct CouponsListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            CouponsListView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
