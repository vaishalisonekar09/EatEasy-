//
//  ProfileView.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct ProfileView: View {
    
    var user_profile = true
    
    var body: some View {
        
        ZStack {
            
            Image("profile-bg")
                .resizable()
                .scaledToFill()
                .clipped()
                .overlay(
                    LinearGradient(colors: [Color.clear, Color.black], startPoint: .top, endPoint: .bottom)
                )
            
            VStack {
                
                ScrollView(showsIndicators: false) {
                    
                    VStack {
                        
                        Image("profile")
                            .resizable()
                            .frame(width: 120, height: 120)
                            .padding(.top, SSize.HEIGHT * 0.2)
                        
                        Text("Jesus Bishop")
                            .font(h18Font)
                            .padding(.top, 8)
                        
                        Text("@jorgecutis")
                        
                        if user_profile {
                            
                            HStack(spacing: 15) {
                                
                                Image("profile-chat")
                                
                                Button {
                                    
                                } label: {
                                    
                                    Text("Follow")
                                        .frame(width: 120, height: 45)
                                        .foregroundColor(.white)
                                        .background(Color.blueColor)
                                        .clipShape(Capsule())
                                }

                            }
                            
                            
                        } else {
                            
                            NavigationLink {
                                EditProfileView()
                            } label: {
                                Text("Edit Profile")
                                    .frame(width: 130, height: 45)
                                    .foregroundColor(.white)
                                    .background(Color.blueColor)
                                    .clipShape(Capsule())
                            }
                            .padding(.top)

                        }
                        
                        
                        VStack(alignment: .leading, spacing: 10) {
                            
                            Text("About me")
                                .font(h18Font)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            Text("The availability of low-cost flights and last minute internet deals means that cheap holidays are far easier to come by than they used to be, but it can still take a bit of shopping around to get the best discounts.")
                            
                            Text("Videos")
                                .font(.custom(Nunito.bold, size: 18))
                                .padding(.top)
                            
                            LazyVGrid(columns: [
                                GridItem(.flexible(), spacing: 10),
                                GridItem(.flexible(), spacing: 10),
                                GridItem(.flexible(), spacing: 10)], spacing: 10
                            ) {
                                
                                ForEach(0..<30) { i in
                                    
                                    ZStack {
                                        
                                        Image("wishlist")
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: (SSize.WIDTH-50)/3, height: SSize.WIDTH/3)
                                            .clipped()
                                            .cornerRadius(10)
                                        
                                        Image("play-profile")
                                            .resizable()
                                            .frame(width: 50, height: 50)
                                    }
                                        

                                }
                            }
                        }
                        .padding(.top, 25)
                        
                    }
                    .padding()
                }
            }
            .padding(.top, UIApplication.shared.windows.first?.safeAreaInsets.top)
        }
        .font(p6Font)
        .ignoresSafeArea()
        .navigationBarTitle("", displayMode: .inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if user_profile {
                    Image("more")
                }
            }
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            ProfileView()
        }
    }
}
