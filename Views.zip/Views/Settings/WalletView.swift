//
//  WalletView.swift
//  AxisVD
//
//  Created by Gipl on 21/09/23.
//

import SwiftUI

struct WalletView: View {
    
    var body: some View {
        
        VStack {
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 20) {
                    
                    VStack {
                        Text("AED 2400.00")
                            .font(h28Font)
                        
                        Text("Available Points")
                            .fontWeight(.bold)
                            .foregroundColor(.grayColor)
                    }
                    .padding(.top)
                    
                    HStack(spacing: 15) {
                        
                        VStack {
                            Text("400")
                                .font(h20Font)
                            Text("SVD POINTS")
                        }
                        .frame(maxWidth: .infinity).frame(height: 120)
                        .background(Color.greenColor.opacity(0.6))
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.greenColor, lineWidth: 1))
                        
                        
                        VStack {
                            
                            Spacer(minLength: 0)
                            
                            Text("400")
                                .font(h20Font)
                            
                            Text("VD POINTS")
                            
                            Spacer(minLength: 0)
                            
                            HStack {
                                
                                Image("gift-icon")
                                Text("Lucky Draw")
                                    .font(p3Font)
                            }.foregroundColor(.greenColor)
                            
                        }
                        .padding(5)
                        .frame(maxWidth: .infinity).frame(height: 120)
                        .background(Color.blueColor.opacity(0.6))
                        .cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.blueColor, lineWidth: 1))
                    }
                    .padding(.top, 10)
                    .padding(.horizontal)
                    
                    HStack {
                        
                        VStack(spacing: 5) {
                            
                            Text("VD Cash")
                            
                            Text("Available Point to Redeem")
                                .foregroundColor(.greenColor)
                        }
                        .frame(maxWidth: .infinity)
                        
                        Button {
                            
                        } label: {
                            Text("Redeem Point")
                                .foregroundColor(.white)
                                .modifier(GradientView(55))
                                .frame(width: 120)
                        }
                    }
                    .padding(8)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.2), lineWidth: 1))
                    .padding(.horizontal)
                    
                    buyPoints()
                    
                    previousPurchasedView()
                        .padding(.horizontal)
                }
                
            }
        }
        .font(p4Font)
        .toolbar {
            
            ToolbarItem(placement: .principal) {
                titleView("MY WALLET")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                Image("search-white")
            }
        }
    }
    
    func buyPoints() -> some View {
        
        VStack(alignment: .leading, spacing: 15) {
            
            Text("Buy Points")
                .font(h20Font)
            
            buyPointRow()
            buyPointRow()
        }
        .padding(15).padding(.vertical, 8)
        .background(Color(0x1D1D1D))
        .padding(.top)
        
    }
    
    func buyPointRow() -> some View {
        
        HStack {
            
            VStack(alignment: .leading) {
                Text("$10.00")
                    .fontWeight(.bold)
                Text("You can get 2000 Points")
                Text("View details")
                    .underline()
                    .foregroundColor(.greenColor)
            }
            .padding(.leading, 2)
            .frame(maxWidth: .infinity, alignment: .leading)
            
            Text("Buy now")
                .foregroundColor(.white)
                .modifier(GradientView(55))
                .frame(width: 100)
            
        }
        .padding(8)
        .background(Color.white.opacity(0.1))
        .cornerRadius(8)
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.2), lineWidth: 1))
    }
    
    func previousPurchasedView() -> some View {
        
        VStack(alignment: .leading, spacing: 15) {
            
            Text("Previous Purchased")
                .font(.custom(Nunito.regular, size: 20).bold())
            
            VStack {
                ForEach(0..<10) { i in
                    purchasedRow()
                    Divider()
                }
            }
            //.padding(.top)
        }
    }
    
    func purchasedRow() -> some View {
        
        VStack(alignment: .leading) {
            Text("\(Text("$10").fontWeight(.bold)) 2000 points")
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("Purchase date Aug. 10. 2023")
        }
    }
    
}

struct WalletView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            WalletView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
