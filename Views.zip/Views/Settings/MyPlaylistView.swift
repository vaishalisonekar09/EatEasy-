//
//  MyPlaylistView.swift
//  AxisVD
//
//  Created by Gipl on 18/09/23.
//

import SwiftUI

struct MyPlaylistView: View {
    
    let categories = ["music", "gaming", "education", "animation", "newspaper"]
    
    var body: some View {
        
        VStack {
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 15) {
                    
                    ForEach(0..<categories.count, id: \.self) { i in
                        categoryRow(i: i)
                    }
                    
                }.padding()
            }
            
            HStack {
                
                Text("PLAYLIST")
                    .font(h20Font)
                
                Spacer()
                
                Text("Create new playlist")
                    .foregroundColor(.greenColor)
                    .underline()
            }
            .padding(.horizontal)
            
            ScrollView {
                
                LazyVStack(spacing: 20) {
                    
                    ForEach(0..<4) { i in
                        
                        playlistRow()
                        
                    }
                }
                .padding()
            }
        }
        .navigationBarTitle("", displayMode: .inline)
        .toolbar {
            
            ToolbarItem(placement: .principal) {
                titleView("MY PLAYLIST")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    Image("search-white")
                    NavigationLink(destination: NotificationsView()) {
                        Image("bell")
                    }
                }
            }
        }
        .font(p6Font)
    }
    
    func playlistRow() -> some View {
        
        HStack {
            
            Image("wishlist")
            
            
            VStack {
                
                Text("Music Life")
                
                Text("14 Songs")
                    .foregroundColor(.grayColor)
            }
            
            Spacer()
            
            Image("more")
        }
    }
    
    func categoryRow(i: Int) -> some View {
        
        VStack {
            
            Image("\(categories[i])")
                .frame(width: 65, height: 65)
                .background(i == 0 ? Color.blueColor : Color.greenColor)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.greenColor.opacity(0.6), lineWidth: 1))
                
            Text(categories[i].capitalized)
                .font(p3Font).fontWeight(.medium)
        }
    }
}

struct MyPlaylistView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            MyPlaylistView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
