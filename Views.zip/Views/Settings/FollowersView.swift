//
//  FollowersView.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct FollowersView: View {
    
    @State private var follow = true
    
    var body: some View {
        
        VStack {
            
            HStack(spacing: 15) {
                
                Button {
                    follow = true
                } label: {
                    Text("FOLLOW")
                        .frame(maxWidth: .infinity).frame(height: 40)
                        .background(follow ? Color.greenColor.opacity(0.6) : Color.btnBgColor)
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12).stroke(follow ? Color.greenColor : Color.btnBgColor, lineWidth: 1)
                        )
                }
                
                Button {
                    follow = false
                } label: {
                    Text("UNFOLLOW")
                        .frame(maxWidth: .infinity).frame(height: 40)
                        .background(follow ? Color.btnBgColor : Color.greenColor.opacity(0.6))
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12).stroke(follow ? Color.btnBgColor : Color.greenColor, lineWidth: 1)
                        )
                }
            }
            .padding([.horizontal, .top])
            
            ScrollView {
                
                LazyVStack(spacing: 15) {
                    
                    ForEach(0..<200) { i in
                        
                        followRow()
                        
                        Divider()
                    }
                }
                .padding()
            }
        }
        .font(p5Font)
        .modifier(BlackBackgroundModifier())
        .navigationBarTitle("", displayMode: .inline)
        .foregroundColor(.white)
        .toolbar {
            
            ToolbarItem(placement: .principal) {
                titleView("FOLLOWERS")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    Image("search-white")
                    NavigationLink(destination: NotificationsView()) {
                        Image("bell")
                    }
                }
            }
        }
    }
    
    func followRow() -> some View {
        
        var followBtn: some View {
            Text("FOLLOW")
                .font(p1Font)
                .frame(width: 80, height: 25)
                .background(Color.greenColor)
                .clipShape(Capsule())
        }
        
        var unfollowBtn: some View {
            
            HStack {
                Image("add-contest")
                Text("UNFOLLOW")
            }
            .font(p1Font)
            .frame(width: 105, height: 25)
            .background(Color.btnBgColor)
            .clipShape(Capsule())
        }
        
        return HStack(spacing: 15) {
            
            NavigationLink(destination: {
                ProfileView()
            }, label: {
                Image("profile")
                    .resizable()
                    .frame(width: 60, height: 60)
                
                VStack(alignment: .leading, spacing: 4) {
                    
                    Text("Alejandro Hicks")
                    
                    Text("120 Followers")
                        .font(p4Font)
                        .foregroundColor(.grayColor)
                }
            })
            
            Spacer(minLength: 0)
            
            if follow {
                followBtn
            } else {
                unfollowBtn
            }
        }
    }
    
}

struct FollowersView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FollowersView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
