//
//  EditProfileView.swift
//  AxisVD
//
//  Created by Gipl on 20/09/23.
//

import SwiftUI

struct EditProfileView: View {
    
    @State private var profile_image = UIImage(named: "profile")
    @State private var username = "Ariella Bradley"
    @State private var email = "ariella.bradley@gmail.com"
    @State private var phone = "+65 39879 343"
    @State private var gender = "Male"
    @State private var dob = "16/04/1988"
    @State private var location = "Australia"
    @State private var about_us = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."
    
    @State private var presentItem: PresentItem?
    
    var body: some View {
        
        ZStack(alignment: .top) {
            
            Image("bg-overlay")
                .resizable()
                .scaledToFit()
                .ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 20) {
                    
                    ZStack(alignment: .bottomTrailing) {
                        
                        Image(uiImage: profile_image ?? UIImage())
                            .resizable()
                            .frame(width: 140, height: 140)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.greenColor, lineWidth: 1))
                            .padding(.top, 25)
                        
                        Button {
                            self.presentItem = PresentItem(MediaPicker(completion: { image in
                                self.profile_image = image
                            }))
                        } label: {
                            Image("camera")
                        }

                    }
                    
                    Text("Change profile photo")
                        
                    
                    LineTextField(title: "Full Name", placeholder: "Enter Full Name", text: $username)
                        .padding(.top)
                    
                    LineTextField(title: "Email", placeholder: "Enter Email", text: $email)

                    LineTextField(title: "Phone", placeholder: "Enter Phone", text: $phone)

                    LineTextField(title: "Gender", placeholder: "Select Gender", text: $gender)
                    
                    LineTextField(title: "Date Of Birth", placeholder: "Select Date of birth", text: $dob)
                    
                    LineTextField(title: "Location", placeholder: "Enter Location", text: $location)

                    LineTextEditor(title: "About Us", placeholder: "About Us", text: $about_us)
                    
                    HStack(spacing: 20) {
                        
                        Text("Cancel")
                            .frame(maxWidth: .infinity).frame(height: 55)
                            .background(Color.greenColor.opacity(0.6))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12).stroke(Color.greenColor, lineWidth: 1)
                            )
                        
                        Button {
                            
                        } label: {
                            Text("Save")
                                .modifier(GradientView(55))
                        }
                    }.padding()
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("EDIT PROFILE")
            }
        }
        .font(p6Font)
        .fullScreenCover(item: $presentItem) { item in
            AnyView(item.view)
        }
    }
}

struct EditProfileView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            EditProfileView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
