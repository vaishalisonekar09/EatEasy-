//
//  SignupView.swift
//  AxisVD
//
//  Created by Gipl on 11/09/23.
//

import SwiftUI

struct SignupView: View {
    
    @State private var presentItem: PresentItem?
    
    @State private var email             = ""
    @State private var full_name         = ""
    @State private var mobile_number     = ""
    @State private var referral_code     = ""
    @State private var country           = ""
    @State private var password          = ""
    @State private var confirm_password  = ""
    @State var show_password             = false
    @State var confm_password            = false
    @State private var showCountryPicker = false
    @State private var country_name      = ""
   
    @Environment(\.presentationMode) var presentation
    
    var body: some View {
        
        ScrollView(showsIndicators: false) {
            
            VStack(spacing: 13) {
                
                Image("logo")
                    .padding(.top, 20)
                    .frame(maxWidth: .infinity)
                
                VStack(spacing: 5) {
                    
                    Text("GREAT!!")
                        .font(h28Font)
                        .foregroundColor(.greenColor)
                        .padding(.top)
                    
                    Text("Start creating account on \(Text("Axis VD").fontWeight(.bold)), let me help.")
                        .multilineTextAlignment(.center)
                }
                
                Group {
                    
                    CustomTextField(title: "Email", placeholder: "Your Email Address", text: $email, keyboardType: .emailAddress)
                        .padding(.top, 3)
                    
                    CustomTextField(title: "Full Name", placeholder: "Your Full Name", text: $full_name)
                    
                    CustomTextField(title: "Mobile Number", placeholder: "Your Mobile Number", text: $mobile_number, keyboardType: .phonePad)
                    
                    CustomTextField(title: "Apply Referral Code (If Any)", placeholder: "Enter Referral Code", text: $referral_code, is_required: false)
                    
                    Button {
                        self.presentItem = PresentItem(CountryPickerView(country_name: $country_name))
                    } label: {
                        CustomTextField(title: "Country", placeholder: "Select Country", text: $country_name, rightView: AnyView(Image("drop-down")), is_dropdown: true)
                    }
                    
                    CustomTextField(title: "Password", placeholder: "Enter Your Password", text: $password, isSecure: !show_password, rightView: AnyView(
                        Button(action: {
                            show_password.toggle()
                        }, label: {
                            Image(show_password ? "eye-show": "eye-off")
                        })
                    ))
                    
                    CustomTextField(title: "Confirm Password", placeholder: "Retype It Again", text: $confirm_password, isSecure: !confm_password, rightView: AnyView(
                        Button(action: {
                            confm_password.toggle()
                        }, label: {
                            Image(confm_password ? "eye-show": "eye-off")
                        })))
                }
                
                Button {
                    //self.presentItem = PresentItem(TabBarView())
                    Storage.login = true
                } label: {
                    Text("Sign up")
                        .modifier(GradientView())
                    
                }
                .padding(.top,20)
                
                Text("By clicking Sign Up, you agree to our \(Text("Terms and Conditions.").foregroundColor(.greenColor))")
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                HStack {
                    
                    Rectangle()
                        .fill(Color.borderColor)
                        .frame(height: 1)
                    
                    Text("OR")
                        .font(h16Font)
                    
                    Rectangle()
                        .fill(Color.borderColor)
                        .frame(height: 1)
                    
                }.padding([.horizontal], 37)
                    .padding(.top, 18)
                
                HStack(spacing: 30) {
                    
                    Button {
                        //self.presentItem = PresentItem(TabBarView())
                        Storage.login = true
                    } label: {
                        Image("facebook")
                    }
                    
                    Button {
                        Storage.login = true
                        //self.presentItem = PresentItem(TabBarView())
                    } label: {
                        Image("google")
                    }
                }
                .padding(.top, 10)
                
                HStack(spacing: 3) {
                    
                    Text("Already have an account?")
                    
                    Button {
                        presentation.wrappedValue.dismiss()
                    } label: {
                        Text("Log in.")
                            .foregroundColor(Color.greenColor)
                    }
                }
                .padding(.top, 27)
            }
            .padding()
        }
        .foregroundColor(.white)
        .font(p6Font)
        .onTapGesture {
            hideKeyboard()
        }
        .modifier(AuthBaseModifier())
        .fullScreenCover(item: $presentItem) { item in
            AnyView(item.view)
        }
    }
    
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}
