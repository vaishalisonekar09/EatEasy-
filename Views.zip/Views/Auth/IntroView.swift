//
//  IntroView.swift
//  AxisVD
//
//  Created by Gipl on 26/09/23.
//

import SwiftUI
import SwiftUIIntrospect

struct IntroView: View {
    
    @State private var presentItem: PresentItem?
    @State private var selection = 0
    @StateObject var viewModel = CarouselViewModel()

    var body: some View {
        
        VStack {
            
            Image("logo")
                .padding(.top, 40)
            
            Text("A FULL FLEDGED\nVIDEO ENTERAINMENT")
                .font(h28Font)
                .multilineTextAlignment(.center)
                .padding(.top)
                .foregroundColor(.greenColor)
            
            Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")
                .multilineTextAlignment(.center)
                .padding(.top, 1)
            
            HStack(spacing: 25) {
                
                ForEach(viewModel.data) { data in
                    
                    Image(data.img)
                        .resizable()
                        .offset(x: viewModel.x)
                        .frame(width: UIScreen.main.bounds.width - 100, height: data.show ? SSize.HEIGHT * 0.4 + 60 : SSize.HEIGHT * 0.4)
                        .highPriorityGesture(
                            DragGesture()
                                .onChanged({ value in
                                    print("onChanged: ", value.location.x)
                                    if value.translation.width > 0 {
                                        viewModel.x = value.location.x
                                    } else {
                                        viewModel.x = value.location.x - viewModel.screen
                                    }
                                })
                                .onEnded({ value in
                                    print("onEnded: ", value.location.x)
                                    if value.translation.width > 0 {
                                        if value.translation.width > ((viewModel.screen - 80) / 2) && Int(viewModel.count) != viewModel.getMid() {
                                            viewModel.count += 1
                                            viewModel.updateHeight(value: Int(viewModel.count))
                                            viewModel.x = (viewModel.screen + 15) * viewModel.count
                                        } else {
                                            viewModel.x = (viewModel.screen + 15) * viewModel.count
                                        }
                                    } else {
                                        if -value.translation.width > ((viewModel.screen - 80) / 2) && -Int(viewModel.count) != viewModel.getMid() {
                                            viewModel.count -= 1
                                            viewModel.updateHeight(value: Int(viewModel.count))
                                            viewModel.x = (viewModel.screen + 15) * viewModel.count
                                        } else {
                                            viewModel.x = (viewModel.screen + 15) * viewModel.count
                                        }
                                    }
                                })
                        )
                }
            }
            .padding(.top)
            
            HStack {
                
                Button {
                    self.presentItem = PresentItem(LoginView())
                } label: {
                    Text("Skip")
                        .font(p6Font.bold())
                }
                
                Spacer()
                
                slider(0)
                
                slider(1)
                
                slider(2)
                
                Spacer()
                
                Button {
                    //viewModel.updateHeight(value: viewModel.data.first {$0.show}?.id ?? 0 + 1)
                    //viewModel.count += 1
                    self.presentItem = PresentItem(LoginView())
                } label: {
                    Image("intro-icon")
                }

            }
            .padding()
        }
        .animation(.spring())
        .font(p4Font)
        .foregroundColor(.white)
        .fullScreenCover(item: $presentItem) { item in
            AnyView(item.view)
        }
        .onAppear {
            viewModel.data[viewModel.getMid()].show = true
        }
    }
    
    func slider(_ tag: Int) -> some View {
        
        Capsule()
            .frame(width: 20, height: 6)
            .foregroundColor(viewModel.data.first {$0.show}?.id ?? 0 == tag ? .greenColor : .white)
    }
}

struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
