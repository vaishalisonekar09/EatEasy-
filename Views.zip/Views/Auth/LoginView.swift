//
//  LoginView.swift
//  AxisVD
//
//  Created by Gipl on 11/09/23.
//

import SwiftUI

struct LoginView: View {
    
    @State private var email            = ""
    @State private var password         = ""
    @State private var show_password   = false
    @State private var presentItem: PresentItem?
    
    var body: some View {
        
        ScrollView(showsIndicators: false) {
            
            VStack(spacing: 15) {
                
                Image("logo")
                    .padding(.top, 20)
                    .frame(maxWidth: .infinity)
                
                VStack(spacing: 7) {
                    
                    Text("HELLO AGAIN!!")
                        .font(h28Font)
                        .foregroundColor(.greenColor)
                        .padding(.top)
                    
                    Text("Welcome to \(Text("Axis VD").fontWeight(.bold)), Please Login to continue.")
                        .multilineTextAlignment(.center)
                }
                
                CustomTextField(title: "Email", placeholder: "Your Email", text: $email, keyboardType: .emailAddress)
                    .padding(.top, 19)
                
                CustomTextField(title: "Password", placeholder: "Your Password", text: $password, isSecure: !show_password, rightView: AnyView(
                    Button(action: {
                        show_password.toggle()
                    }, label: {
                        Image(show_password ? "eye-show": "eye-off")
                    })
                ))
                
                Text("Forgot Password?")
                    .foregroundColor(.greenColor)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Button {
                    Storage.login = true
                } label: {
                    Text("Log in")
                        .modifier(GradientView())
                }
                .padding(.top)
                
                HStack {
                    Rectangle()
                        .fill(Color.borderColor)
                        .frame(height: 1)
                    
                    Text("OR")
                        .font(h16Font)
                    
                    Rectangle()
                        .fill(Color.borderColor)
                        .frame(height: 1)
                }
                .padding(30)
                
                HStack(spacing: 30) {
                    
                    Button {
                        self.presentItem = PresentItem(TabBarView())
                    } label: {
                        Image("facebook")
                    }

                    Button {
                        self.presentItem = PresentItem(TabBarView())
                    } label: {
                        Image("google")
                    }
                    
                }
                
                HStack(spacing: 3) {
                    
                    Text("Don’t have an account?")
                    
                    Button {
                        self.presentItem = PresentItem(SignupView())
                    } label: {
                        Text("Sign up.")
                            .foregroundColor(Color.greenColor)
                    }
                }
                .padding(.top)
            }
            .padding()
        }
        .fullScreenCover(item: $presentItem, content: { item in
            AnyView(item.view)
        })
        .foregroundColor(.white)
        .font(p6Font)
        .onTapGesture {
            hideKeyboard()
        }
        .modifier(AuthBaseModifier())
        
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
