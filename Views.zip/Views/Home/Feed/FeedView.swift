//
//  FeedView.swift
//  AxisVD
//
//  Created by Gipl on 21/09/23.
//

import SwiftUI

struct FeedView: View {
    
    var body: some View {
        
        VStack {
            
            ScrollView {
                
                LazyVStack(spacing: 0) {
                    
                    ForEach(0..<200) { i in
                        feedRow()
                        Rectangle()
                            .fill(Color(0x232323))
                            .frame(height: 8)
                            
                    }
                }
            }
            
        }
        .navigationBarTitle("", displayMode: .inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("WHATS NEW")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack(spacing: 15) {
                    Image("search-white")
                    NavigationLink(destination: NotificationsView()) {
                        Image("bell")
                    }
                }
            }
        }
        .foregroundColor(.white)
    }
    
    func feedRow() -> some View {
        
        VStack(spacing: 15) {
            
            HStack {
                
                NavigationLink(destination: {
                    ProfileView()
                }, label: {
                    Image("profile")
                        .resizable()
                        .frame(width: 50, height: 50)
                    
                    VStack(alignment: .leading) {
                        Text("Christina Kennedy")
                        Text("2 hours ago")
                            .foregroundColor(.grayColor)
                            .font(p3Font)
                    }
                })
                
                Spacer(minLength: 0)
                
                Image("more")
            }
            
            Text("\(Text("#relax, #travel").foregroundColor(.greenColor))\nThe state of Utah in the United States is home to lots of beautiful National Parks, & Bryce Canyon National Park ranks as three of the most magnificent")
                //.font(p5Font)
            
            Image("banner")
                .resizable()
                .scaledToFill()
                .frame(height: 120)
                .clipped()
                .cornerRadius(8)
            
            HStack {
                
                HStack {
                    Image("unlike")
                    Text("1125")
                }
                Spacer(minLength: 0)
                //HStack {
                //    Image("liked")
                //    Text("348")
                //}
                Spacer(minLength: 0)
                HStack {
                    Image("comment")
                    Text("348")
                }
                Spacer(minLength: 0)
                HStack {
                    Image("star")
                    Text("743")
                }
                Spacer(minLength: 0)
                HStack {
                    Image("share")
                    Text("743")
                }
            }
            .foregroundColor(Color(0x9A9A9A))
            .font(p4Font)
        }
        .padding()
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FeedView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
