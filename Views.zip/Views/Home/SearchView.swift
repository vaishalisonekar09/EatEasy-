//
//  SearchView.swift
//  AxisVD
//
//  Created by Gipl on 19/09/23.
//

import SwiftUI

struct SearchView: View {
    
    @State private var search = ""
    
    var body: some View {
        
        VStack(spacing: 15) {
            
            HStack(spacing: 10) {
                
                Image("search-gray")
                
                ZStack(alignment: .leading) {
                    
                    if search.isEmpty {
                        Text("Search")
                            .foregroundColor(.grayColor)
                    }
                    
                    TextField("Search", text: $search)
                        .frame(height: 48)
                }
            }
            .padding(.horizontal, 12)
            .background(Color(0x182123))
            .cornerRadius(12)
            .padding([.horizontal, .top])
            
            HStack {
                
                Text("RECENT SEARCH")
                    .font(h20Font)
                
                Spacer()
                
                Text("Clear all")
                    .foregroundColor(.greenColor)
            }
            .padding(.horizontal)
            .padding(.top, 10)
            
            ScrollView {
                
                LazyVStack(spacing: 15) {
                    
                    ForEach(0..<200) { i in
                        searchRow()
                        Divider()
                    }
                }
                .padding()
                
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("SEARCH")
            }
        }
    }
    
    func searchRow() -> some View {
        
        HStack(spacing: 15) {
            
            Image("profile")
            
            Text("Alejandro Hicks")
            
            Spacer()
            
            Text("FOLLOW")
                .font(p1Font)
                .frame(width: 80, height: 25)
                .background(Color.greenColor)
                .clipShape(Capsule())
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            SearchView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
