//
//  SideMenuView.swift
//  AxisVD
//
//  Created by Gipl on 26/09/23.
//

import SwiftUI

struct SideMenuView: View {
    
    @Binding var selection: String?
    @Binding var showMenu: Bool
    
    @State private var current_page = "home"

    var body: some View {
        
        VStack(alignment: .leading) {
            
            
            Button {
                withAnimation {
                    self.showMenu.toggle()
                    self.current_page = "profile"
                    DispatchQueue.main.asyncAfter(deadline: .now()+0.5) {
                        self.selection = "profile"
                    }
                }
            } label: {
                
                HStack {
                    
                    Image("profile")
                    
                    VStack(alignment: .leading) {
                        
                        Text("Ariella Bradley")
                            .font(h16Font)
                        
                        Text("View profile")
                            .foregroundColor(.grayColor)
                    }
                    
                    Spacer()
                    
                    Image("arrow-icon")
                }
            }
            .padding()
            .padding(.top, UIApplication.shared.windows.first?.safeAreaInsets.top)
            
            Divider()
            
            ScrollView(showsIndicators: false) {
                
                VStack {
                    
                    sliderRow("slider-home", title: "Home", slug: "home")
                    sliderRow("slider-playlist", title: "My Playlist", slug: "playlist")
                    sliderRow("slider-library", title: "Categories", slug: "library")
                    sliderRow("slider-coins", title: "My Reward Points", slug: "coins")
                    sliderRow("slider-reference", title: "Refer Friends", slug: "reference")
                    //sliderRow("slider-voucher", title: "Coupons", slug: "voucher")
                    sliderRow("slider-wallet", title: "My Wallet", slug: "wallet")
                    sliderRow("slider-recent", title: "My Activities", slug: "recent")
                    sliderRow("slider-recent", title: "Follow / Unfollow", slug: "follow_unfollow")
                    sliderRow("slider-settings", title: "Settings", slug: "settings")
                }
                .padding([.horizontal, .top])
            }
            
            Button {
                Storage.login = false
            } label: {
                Text("Log out")
                    .modifier(GradientView())
                    .frame(width: SSize.WIDTH * 0.5)
            }
            .padding([.horizontal, .bottom])
            .padding()
        }
        .foregroundColor(.white)
        .navigationBarTitle("", displayMode: .inline)
    }
    
    func sliderRow(_ icon: String, title: String, slug: String) -> some View {
        
        Button {
            
            withAnimation {
                self.showMenu.toggle()
                self.current_page = slug
                DispatchQueue.main.asyncAfter(deadline: .now()+0.5) {
                    self.selection = slug
                }
            }
        } label: {
            
            HStack(spacing: 15) {
                
                Image(icon)
                    .frame(width: 44, height: 44)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                
                Text(title)
                    .font(p6Font).fontWeight(.medium)
                
                Spacer(minLength: 0)
                
                if current_page == slug {
                    Image("arrow-icon")
                }
            }
            .padding()
            .frame(width: 250)
            .background(current_page == slug ? Color.blueColor : Color.clear)
            .cornerRadius(10)
            
        }
        
    }
}

struct SideMenuView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        //NavigationView {
        SideMenuView(selection: .constant(""), showMenu: .constant(true))
        //}
    }
}
