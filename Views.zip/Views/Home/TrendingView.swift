//
//  TrendingView.swift
//  AxisVD
//
//  Created by Gipl on 25/09/23.
//

import SwiftUI

struct TrendingView: View {
    
    var body: some View {
        
        VStack {
            
            ScrollView {
                
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                    
                    ForEach(0..<300) { i in
                        feedRow()
                    }
                }
                .padding(12)
            }
        }
        .font(p5Font)
        .foregroundColor(.white)
        .navigationBarTitle("", displayMode: .inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("TRENDING")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack(spacing: 15) {
                    Image("search-white")
                    NavigationLink(destination: NotificationsView()) {
                        Image("bell")
                    }
                }
            }
        }
    }
    
    func feedRow() -> some View {
        
        VStack(alignment: .leading) {
            NavigationLink(destination: {
                ProfileView()
            }, label: {
                HStack {
                    
                    Image("profile")
                        .resizable()
                        .frame(width: 35, height: 35)
                    
                    VStack(alignment: .leading) {
                        Text("Joel Jacobs")
                        Text("2 hours ago")
                            .foregroundColor(.grayColor)
                    }
                    
                    Spacer(minLength: 0)
                }
            })
            .padding([.horizontal, .top], 10)
            
            Image("audio")
                .resizable()
                .scaledToFit()
            
            Text("\(Text("#relax, #travel").foregroundColor(.greenColor))\nBryce Canyon A Stunning Us Travel Destination")
                .padding(.horizontal, 10)
            
            HStack {
                HStack {
                    Image("unlike")
                    Text("1125")
                }
                Spacer(minLength: 0)
                HStack {
                    Image("comment")
                    Text("348")
                }
            }
            .padding([.horizontal, .bottom], 10)
            
        }
        .background(Color(0x232323))
        .cornerRadius(8)
    }
}

struct TrendingView_Previews: PreviewProvider {
    static var previews: some View {
        
        NavigationView {
            TrendingView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
