//
//  ReelCommentView.swift
//  AxisVD
//
//  Created by Gipl on 16/10/23.
//

import SwiftUI

struct ReelCommentView: View {
    
    @State private var comment = ""
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            Text("COMMENTS (548)")
                .font(h18Font)
                .padding(.horizontal)
                .padding(.top, 35)
            
            ScrollView {
                
                VStack(spacing: 15) {
                    ForEach(0..<20) { i in
                        commentRow()
                        Divider()
                    }
                }
                .padding()
            }
            
            HStack(spacing: 15) {
                
                HStack {
                    Image("smile")
                    TextField("Send your message…", text: $comment)
                        .frame(height: 44)
                        .environment(\.colorScheme, .light)
                }
                .padding(.horizontal)
                .background(Color.white)
                .clipShape(Capsule())
                
                Image("send")
            }
            .padding(20)
            .background(Color.greenColor.opacity(0.2).edgesIgnoringSafeArea(.bottom))
        }
    }
    
    func commentRow() -> some View {
        
        HStack(alignment: .top, spacing: 15) {
            
            Image("profile")
                .resizable()
                .frame(width: 50, height: 50)
            
            VStack(alignment: .leading) {
                
                HStack(spacing: 15) {
                    
                    Text("@girth342")
                        .font(p5Font)
                    
                    Image("verfiy")
                    
                    Spacer(minLength: 0)
                }
                
                Text("Nunc congue nunc dolor, non commodo an odio suscipit sit amet ut sit amet elit.")
                    .multilineTextAlignment(.leading)
            }
        }
        .font(p5Font)
    }
}
//
//#Preview {
//    ReelCommentView()
//}
