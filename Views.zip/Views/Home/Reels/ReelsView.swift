//
//  ReelsView.swift
//  AxisVD
//
//  Created by Gipl on 21/09/23.
//

import SwiftUI
import SwiftUIIntrospect

struct ReelsView: View {
    
    @State var y: CGFloat = 10000
    @Environment(\.presentationMode) var presentationMode
    @State private var showCommentView = false
    
    var body: some View {
        
        VStack {
                            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 0) {
                    
                    ForEach(0..<100, id: \.self) { i in
                        
                        ReelsRow(index: i, showCommentView: $showCommentView)
                            .id(i)
                            .gesture(DragGesture().onEnded({ value in
                                print("onEnded: ", value.location)
                            }))
                            
                    }
                }
            }
            .introspect(.scrollView, on: .iOS(.v15, .v16, .v17)) { sv in
                sv.isPagingEnabled = true
            }
        }
        .ignoresSafeArea()
        .sheet(isPresented: $showCommentView, content: {
            ReelCommentView()
                .presentationDragIndicator(.visible)
                .presentationDetents([.medium, .large])
        })
        .toolbar {
            
            ToolbarItem(placement: .navigationBarLeading) {
                
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName: "xmark")
                        .font(h18Font)
                }

            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    
                    HStack {
                        
                        Image("eye-show")
                            .renderingMode(.template)
                        
                        Text("6.5 M")
                    }
                    .font(p4Font)
                    .frame(width: 90, height: 35)
                    .background(Color.greenColor)
                    .clipShape(Capsule())
                    .foregroundColor(.white)
                    
                    Image("more")
                }
            }
        }
        .font(p4Font)
        .foregroundColor(.white)
        .navigationBarTitle("", displayMode: .inline)
    }
    
}

struct ReelsView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            ReelsView()
        }
    }
}

struct ReelsRow: View {
    
    var index: Int
    @Binding var showCommentView: Bool
    
    var body: some View {
        
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            
            Image("reels")
                .resizable()
                .scaledToFill()
                .frame(height: SSize.HEIGHT)
                .clipped()
            
            VStack(alignment: .trailing, spacing: 0) {
                
                Spacer()
                
                VStack(spacing: 15) {
                    actionImage("unlike", count: "2.3M")
                    //actionImage("liked", count: "2.3M")
                    Button(action: {
                        showCommentView.toggle()
                    }, label: {
                        actionImage("comment", count: "589")
                    })
                    actionImage("star", count: "743")
                    actionImage("share", count: "\(index)")
                }
                .padding(.horizontal)
                
                VStack(spacing: 15) {
                    
                    HStack(spacing: 15) {
                        NavigationLink(destination: {
                            ProfileView()
                        }, label: {
                            Image("profile")
                                .resizable()
                                .frame(width: 50, height: 50)
                            
                            VStack(alignment: .leading) {
                                Text("Fletch Skinner")
                                    .font(p6Font)
                                    .fontWeight(.medium)
                                Text("20 Followers")
                                    .font(p3Font)
                                    .fontWeight(.medium)
                            }
                        })
                        
                        Spacer(minLength: 0)
                        
                        Text("Follow")
                            .font(p4Font)
                            .frame(width: 80, height: 35)
                            .background(Color.greenColor)
                            .clipShape(Capsule())
                            .foregroundColor(.white)
                    }
                    
                    Text("Best Pop Songs 2019 - Adele, Maroon 5, Ed Sheeran, Shawn Mendes, Ariana Grande")
                        .fontWeight(.medium)
                }
                .padding()
                .padding(.top)
                .padding(.bottom, UIApplication.shared.windows.first?.safeAreaInsets.bottom)
                .background(
                    LinearGradient(colors: [Color.clear, Color.black.opacity(0.5)], startPoint: .top, endPoint: .bottom)
                        .edgesIgnoringSafeArea(.bottom)
                )
                
            }
        }
        
    }
    
    func actionImage(_ icon: String, count: String) -> some View {
        
        VStack(spacing: 5) {
            Image(icon)
                .renderingMode(.template)
                .resizable()
                .scaledToFit()
                .frame(width: 25, height: 25)
            Text(count)
                .font(p4Font)
                .fontWeight(.medium)
        }
        .foregroundColor(.white)
    }
}
