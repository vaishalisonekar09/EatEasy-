//
//  ChatView.swift
//  AxisVD
//
//  Created by Gipl on 25/09/23.
//

import SwiftUI

struct ChatView: View {
    
    @State private var message = ""
    @State private var messages = [""]
    
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            ScrollView(showsIndicators: false) {
                
                LazyVStack(spacing: 25) {
                    ForEach(0..<20) { i in
                        
                        if i % 2 == 0 {
                            leftView()
                        } else {
                            rightView()
                        }
                    }
                }
                .padding()
            }
            
            Rectangle()
                .fill(Color.greenColor)
                .frame(height: 2)
                
            HStack(spacing: 15) {
                
                HStack {
                    Image("smile")
                    TextField("Send your message…", text: $message)
                        .frame(height: 44)
                        .environment(\.colorScheme, .light)
                }
                .padding(.horizontal)
                .background(Color.white)
                .clipShape(Capsule())
                
                Image("send")
            }
            .padding(20)
            .background(Color.greenColor.opacity(0.2).edgesIgnoringSafeArea(.bottom))
            
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            
            ToolbarItem(placement: .principal) {
                NavigationLink(destination: {
                    ProfileView()
                }, label: {
                    HStack(spacing: 15) {
                        
                        Image("profile")
                            .resizable()
                            .frame(width: 35, height: 35)
                        
                        Text("Ingredia Nutrisha")
                            .font(p6Font)
                            .foregroundColor(.white)
                    }
                })
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                Image("more")
            }
        }
    }
    
    func leftView() -> some View {
        
        HStack {
            
            Text("Fusce convallis metus a ante")
                .multilineTextAlignment(.leading)
                .padding(10)
                .background(Color.greenColor.opacity(0.3))
                .cornerRadius(8, corners: [.bottomLeft, .bottomRight, .topRight])
                
            Spacer(minLength: SSize.WIDTH * 0.3)
        }
        
    }
    
    func rightView() -> some View {
        HStack {
            Spacer(minLength: SSize.WIDTH * 0.3)
            Text("Suspendisse potenti 😂 ")
                .multilineTextAlignment(.trailing)
                .padding(10)
                .background(Color.blueColor.opacity(0.3))
                .cornerRadius(8, corners: [.bottomLeft, .bottomRight, .topLeft])
                
                //.overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.blueColor, lineWidth: 1))
        }
    }
    
}

struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ChatView()
        }
    }
}
