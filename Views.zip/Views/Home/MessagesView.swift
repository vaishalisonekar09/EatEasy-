//
//  MessagesView.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct MessagesView: View {
    
    @State private var search = ""
    
    var body: some View {
        
        VStack {
            
            HStack(spacing: 10) {
                
                Image("search-gray")
                
                ZStack(alignment: .leading) {
                    
                    if search.isEmpty {
                        Text("Search")
                            .foregroundColor(.grayColor)
                    }
                    
                    TextField("Search", text: $search)
                        .frame(height: 48)
                }
            }
            .padding(.horizontal, 12)
            .background(Color(0x182123))
            .cornerRadius(12)
            .padding([.horizontal, .top])
            
            ScrollView {
                
                LazyVStack {
                    
                    ForEach(0..<200) { i in
                        
                        NavigationLink {
                            ChatView()
                        } label: {
                            messageRow()
                        }

                        Divider()
                    }
                    
                }.padding()
            }
        }
        .navigationBarTitle("", displayMode: .inline)
        .modifier(BlackBackgroundModifier())
        .font(p4Font)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            
            ToolbarItem(placement: .principal) {
                titleView("MESSAGES")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    
                    Image("search-white")
                    
                    Image("new-message")
                }
            }
        }
        .onTapGesture {
            hideKeyboard()
        }
    }
    
    func messageRow() -> some View {
        
        HStack {
            
            Image("profile")
                .resizable()
                .frame(width: 55, height: 55)
            
            HStack {
                
                VStack(alignment: .leading, spacing: 0) {
                    
                    Text("Dominic Ement")
                        .foregroundColor(.white)
                    
                    Text("In lacinia aliquet ex vel facilisis")
                    
                }
                
                Spacer()
                
                VStack(alignment: .trailing) {
                    
                    Text("09:50 pm")
                    
                    Text("2")
                        .padding(6)
                        .background(Color.redColor)
                        .clipShape(Circle())
                        .foregroundColor(.white)
                }
            }
            
        }.foregroundColor(.grayColor)
            
    }
}

struct MessagesView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            MessagesView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
