//
//  LibraryView.swift
//  AxisVD
//
//  Created by Gipl on 28/09/23.
//

import SwiftUI

struct LibraryView: View {
    
    let categories = ["music", "gaming", "education", "animation", "newspaper"]
    
    var followBtn: some View {
        Text("FOLLOW")
            .font(p1Font)
            .frame(width: 80, height: 25)
            .background(Color.greenColor)
            .clipShape(Capsule())
    }
    
    var unfollowBtn: some View {
        
        HStack {
            Image("add-contest")
            Text("UNFOLLOW")
        }
        .font(p1Font)
        .frame(width: 105, height: 25)
        .background(Color.btnBgColor)
        .clipShape(Capsule())
    }
    
    var body: some View {
        
        VStack {
            
            ScrollView(.horizontal, showsIndicators: false) {
                
                HStack(spacing: 15) {
                    
                    ForEach(0..<categories.count, id: \.self) { i in
                        categoryRow(i: i)
                    }
                    
                }.padding()
            }
            
            ScrollView(showsIndicators: false) {
                
                VStack {
                    
                    HStack {
                        
                        Text("THROWBACK")
                            .font(h20Font)
                        
                        Spacer()
                        
                        HStack {
                            Text("View all")
                                
                            Image(systemName: "chevron.right")
                        }
                        .font(p4Font)
                        .foregroundColor(.grayColor)
                    }
                    .padding(.top, 8)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(0..<20) { i in
                                audioRow()
                            }
                        }
                    }
                    
                    HStack {
                        
                        Text("ROCK")
                            .font(h20Font)
                        
                        Spacer()
                        
                        HStack {
                            Text("View all")
                                
                            Image(systemName: "chevron.right")
                        }
                        .font(p4Font)
                        .foregroundColor(.grayColor)
                    }
                    .padding(.top, 8)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(0..<20) { i in
                                audioRow()
                            }
                        }
                    }
                    
                    HStack {
                        
                        Text("ROCK")
                            .font(h20Font)
                        
                        Spacer()
                        
                        HStack {
                            Text("View all")
                                
                            Image(systemName: "chevron.right")
                        }
                        .font(p4Font)
                        .foregroundColor(.grayColor)
                    }
                    .padding(.top, 8)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(0..<20) { i in
                                audioRow()
                            }
                        }
                    }
                    
                }
                .padding()
            }
        }
        .navigationBarTitle("", displayMode: .inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("CATEGORIES")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    
                    Image("search-white")
                    
                    NavigationLink {
                        NotificationsView()
                    } label: {
                        Image("bell")
                    }

                }
            }
        }
    }
    
    func categoryRow(i: Int) -> some View {
        
        VStack {
            
            Image("\(categories[i])")
                .frame(width: 65, height: 65)
                .background(i == 0 ? Color.blueColor : Color.greenColor)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.greenColor.opacity(0.6), lineWidth: 1))
            
            Text(categories[i].capitalized)
                .font(p3Font).fontWeight(.medium)
        }
    }
    
    func audioRow() -> some View {
        
        VStack(alignment: .leading) {
            
            ZStack(alignment: Alignment(horizontal: .trailing, vertical: .bottom)) {
                
                Image("audio")
                Image("play")
                    .padding(.bottom, -15)
                    .padding(.trailing)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Toucan Die")
                
                HStack {
                    Image("unlike")
                    Text("1125")
                    
                    Image("comment")
                    Text("250")
                }
                .foregroundColor(Color(0x919191))
                .font(h16Font)
            }
            
            .padding([.horizontal, .bottom], 10)
        }
        .background(Color.btnBgColor)
        .cornerRadius(8)
    }
}


struct LibraryView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            LibraryView()
        }
    }
}
