//
//  HomeView.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct HomeView: View {
    
    @State private var search = ""
    @State private var selection: String?
    @State private var pager_selection = 0
    @State private var showMenu = false
    @State private var presentItem: PresentItem?

    var body: some View {
        
        ZStack(alignment: Alignment(horizontal: .leading, vertical: .top)) {
            
            SideMenuView(selection: $selection, showMenu: $showMenu)
                .frame(width: SSize.WIDTH * 0.7)
                .ignoresSafeArea()
            
            NavigationView {
                mainView()
                    .background(NavigationLink(destination: ProfileView(user_profile: false), tag: "profile", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: MyPlaylistView(), tag: "playlist", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: LibraryView(), tag: "library", selection: $selection) { EmptyView() })
                    //.background(NavigationLink(destination: CouponsListView(), tag: "coins", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: MyPlaylistView(), tag: "reference", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: CouponsListView(), tag: "voucher", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: WalletView(), tag: "wallet", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: RecentView(), tag: "recent", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: FollowersView(), tag: "follow_unfollow", selection: $selection) { EmptyView() })
                    .background(NavigationLink(destination: AddVideoDetailsView(), tag: "add-video", selection: $selection) { EmptyView() })
                
            }.offset(x: showMenu ? SSize.WIDTH * 0.7 : 0)
                .rotationEffect(.init(degrees: showMenu ? 5 : 0))
        }
    }
    
    func slider(_ tag: Int) -> some View {
        
        Capsule()
            .frame(width: self.pager_selection == tag ? 20 : 10, height: 6)
            .foregroundColor(self.pager_selection == tag ? .greenColor : .white)
    }
    
    func mainView() -> some View {
        
        VStack {
            
            searchView()
                .padding()
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 15) {
                    
                    VStack {
                        
                        TabView(selection: $pager_selection) {
                            Image("banner")
                                .tag(0)
                            Image("banner")
                                .tag(1)
                            Image("banner")
                                .tag(2)
                        }
                        .frame(height: SSize.WIDTH * 0.45)
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                        
                        HStack(spacing: 5) {
                            slider(0)
                            
                            slider(1)
                            
                            slider(2)
                        }
                    }
                    
                    HStack {
                        
                        Text("WHATS NEW")
                            .font(h20Font)
                        
                        Spacer()
                        
                        NavigationLink {
                            FeedView()
                        } label: {
                            HStack {
                                Text("View all")
                                    
                                Image(systemName: "chevron.right")
                            }
                            .font(p4Font)
                            .foregroundColor(.grayColor)
                        }

                    }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(0..<20) { i in
                                playlistRow()
                            }
                        }
                    }
                    
                    HStack {
                        
                        Text("TRENDING VIDEO")
                            .font(h20Font)
                        
                        Spacer()
                        
                        NavigationLink {
                            TrendingView()
                        } label: {
                            HStack {
                                Text("View all")
                                    
                                Image(systemName: "chevron.right")
                            }
                            .font(p4Font)
                            .foregroundColor(.grayColor)
                        }
                    }
                    .padding(.top, 8)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(0..<20) { i in
                                audioRow()
                            }
                        }
                    }
                    
                    HStack {
                        
                        Text("TRENDING IMAGE")
                            .font(h20Font)
                        
                        Spacer()
                        
                        NavigationLink {
                            TrendingView()
                        } label: {
                            HStack {
                                Text("View all")
                                    
                                Image(systemName: "chevron.right")
                            }
                            .font(p4Font)
                            .foregroundColor(.grayColor)
                        }
                    }
                    .padding(.top, 8)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(0..<20) { i in
                                imageRow()
                            }
                        }
                    }
                    
                }
                .padding()
            }
        }
        .modifier(BlackBackgroundModifier())
        .navigationBarTitle(Text(""), displayMode: .inline)
        .toolbar {
            
            ToolbarItem(placement: .navigationBarLeading) {
                
                HStack(spacing: 15) {
                    
                    Button {
                        //presentItem = PresentItem(SideMenuView(showMenu: $showMenu))
                        withAnimation {
                            showMenu.toggle()
                        }
                    } label: {
                        Image("menus")
                    }
                    
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 35)
                }
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    
                    Button {
                        self.presentItem = PresentItem(MediaPicker(completion: { image in
                            self.selection = "add-video"
                        }))
                    } label: {
                        Image("video-camera")
                    }

                    
                    NavigationLink(destination: NotificationsView()) {
                        Image("bell")
                    }
                    
                }
            }
        }
        .font(p6Font)
        .foregroundColor(.white)
        .fullScreenCover(item: $presentItem) { item in
            AnyView(item.view)
        }
    }
    
    func searchView() -> some View {
        HStack {
            Image("search-gray")
            TextField("Search Videos, Images", text: $search)
                
            //Image("filter")
        }
        .frame(height: 48)
        .padding(.leading, 15).padding(.trailing, 8)
        .background(Color.white.opacity(0.1))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.4), lineWidth: 1))
    }
    
    func audioRow() -> some View {
        
        VStack(alignment: .leading) {
            
            ZStack(alignment: Alignment(horizontal: .trailing, vertical: .bottom)) {
                Image("audio")
                Image("play")
                    .padding(.bottom, -15)
                    .padding(.trailing)
            }
                
            
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Toucan Die")
                
                HStack {
                    Image("unlike")
                    Text("1125")
                    
                    Image("comment")
                    Text("250")
                }
                .foregroundColor(Color(0x919191))
                .font(h16Font)
            }
            
            .padding([.horizontal, .bottom], 10)
        }
        .background(Color.btnBgColor)
        .cornerRadius(8)
    }
    
    func playlistRow() -> some View {
        
        ZStack(alignment: .bottom) {
            
            Image("wishlist")
                .resizable()
                .scaledToFill()
                .frame(width: 140, height: 170)
                .clipped()
            
            NavigationLink(destination: {
                ProfileView()
            }, label: {
                HStack {
                    Image("profile")
                        .resizable()
                        .frame(width: 30, height: 30)
                    Text("Thomas Curtis")
                        .font(p2Font)
                    Spacer(minLength: 0)
                }
            })
            .padding(8)
            .background(
                LinearGradient(colors: [.black.opacity(0.3), .clear], startPoint: .bottom, endPoint: .top)
            )
            
        }
        .cornerRadius(8)
    }
    
    func imageRow() -> some View {
        
        VStack(alignment: .leading) {
            
            Image("wishlist")
                .resizable()
                .scaledToFit()
                .frame(height: 150)
                
            
        }
        .background(Color.btnBgColor)
        .cornerRadius(8)
    }
    

}

struct HomeView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            HomeView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
