//
//  VideoSuccessView.swift
//  AxisVD
//
//  Created by Gipl on 18/09/23.
//

import SwiftUI

struct VideoSuccessView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        ZStack(alignment: .top) {
            
            Color.bgColor.ignoresSafeArea()
            
            Image("hurray")
                .resizable()
                .scaledToFill()
                .frame(width: SSize.WIDTH, height: SSize.HEIGHT * 0.5)
                .ignoresSafeArea()
                
            VStack {
                
                Text("Hurray!!")
                    .font(.custom(Poppins.bold, size: 40))
                    
                Image("tick")
                    .padding(.top, SSize.WIDTH * 0.2)
                
                Text("Your video has been uploaded")
                    .font(p6Font)
                
                Text("SUCCESSFULLY")
                    .font(h20Font)

                Spacer()
                
                HStack(spacing: 15) {
                    
                    Button {
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        Text("Back to Home")
                            .frame(maxWidth: .infinity).frame(height: 48)
                            .background(Color.greenColor.opacity(0.6))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12).stroke(Color.greenColor, lineWidth: 1)
                            )
                    }
                    
                    Button {
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        Text("Add more video")
                            .modifier(GradientView(48))
                    }
                    
                }.padding()
                
            }.padding(.top, SSize.WIDTH * 0.25)
                
        }
        
    }
}

struct VideoSuccessView_Previews: PreviewProvider {
    static var previews: some View {
        VideoSuccessView()
    }
}
