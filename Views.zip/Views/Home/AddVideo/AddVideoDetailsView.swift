//
//  AddVideoDetailsView.swift
//  AxisVD
//
//  Created by Gipl on 18/09/23.
//

import SwiftUI

struct AddVideoDetailsView: View {
    
    @State var media_name = "IMG_\(Int.random(in: 100...999))"+".png"

    @State private var title                = ""
    @State private var description          = ""
    @State private var language             = ""
    @State private var category             = ""
    @State private var sub_category         = ""
    @State private var video_type           = "promotional"
    @State private var promotional_amount   = ""
    @State private var button_type          = ""
    @State private var button_link          = ""
    
    @State private var presentItem: PresentItem?
    
    @Environment(\.presentationMode) var presentationMode
    
    
    var body: some View {
        
        VStack {
            
            ScrollView(showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 20) {
                    
                    Group {
                        
                        LineTextField(title: "Media", placeholder: "File Name", text: $media_name, rightView: AnyView(Button(action: {
                            presentItem = PresentItem(MediaPicker(completion: { image in
                                self.media_name = "IMG_\(Int.random(in: 100...999))"+".png"
                            }))
                            
                        }, label: {
                            AnyView(Text("Change").foregroundColor(.greenColor))
                        })), isDropDown: true)
                        
                        LineTextField(title: "Video Title", placeholder: "Add Title", text: $title)
                        
                        LineTextEditor(title: "Video Description", placeholder: "Add Description", text: $description)
                        
                        Menu {
                            
                            ForEach(0..<4) { i in
                                
                                Button {
                                    self.language = "Language \(i+1)"
                                } label: {
                                    
                                    HStack {
                                        
                                        Text("Language \(i+1)")
                                        
                                        if self.language == "Language \(i+1)" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }

                            }
                        } label: {
                            LineTextField(title: "Select Language", placeholder: "Select Language", text: $language, rightView: AnyView(Image("drop-down-white")), isDropDown: true)
                        }

                        Menu {
                            
                            ForEach(0..<4) { i in
                                
                                Button {
                                    self.category = "Category \(i+1)"
                                } label: {
                                    
                                    HStack {
                                        
                                        Text("Category \(i+1)")
                                        
                                        if self.category == "Category \(i+1)" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }

                            }
                        } label: {
                            LineTextField(title: "Select Category", placeholder: "Select Category", text: $category, rightView: AnyView(Image("drop-down-white")), isDropDown: true)
                        }
                        
                        Menu {
                            
                            ForEach(0..<4) { i in
                                
                                Button {
                                    self.sub_category = "Sub-Category \(i+1)"
                                } label: {
                                    
                                    HStack {
                                        
                                        Text("Sub-Category \(i+1)")
                                        
                                        if self.sub_category == "Sub-Category \(i+1)" {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }

                            }
                        } label: {
                            LineTextField(title: "Select Sub-Category", placeholder: "Select Sub-Category", text: $sub_category, rightView: AnyView(Image("drop-down-white")), isDropDown: true)
                        }
                    }
                    
                    VStack(alignment: .leading) {
                        
                        Text("Select Video Type")
                            .font(h16Font.bold())
                        
                        HStack {
                            Button {
                                video_type = "regular"
                            } label: {
                                HStack {
                                    Image(video_type == "regular" ? "radio-active" : "radio")
                                    Text("Regular")
                                }
                            }

                            Button {
                                video_type = "promotional"
                            } label: {
                                HStack {
                                    Image(video_type == "promotional" ? "radio-active" : "radio")
                                    Text("Promotional")
                                }
                            }
                            .padding(.horizontal, 25)

                        }
                        .foregroundColor(.borderColor)
                        
                    }
                    .padding(.horizontal)
                    
                    LineTextField(title: "Select Promotional Amount", placeholder: "Enter Amount", text: $promotional_amount, rightView: AnyView(Text("Check Balance").foregroundColor(.greenColor)))
                    
                    Menu {
                        
                        ForEach(0..<4) { i in
                            
                            Button {
                                self.button_type = "Button Type \(i+1)"
                            } label: {
                                
                                HStack {
                                    
                                    Text("Button Type \(i+1)")
                                    
                                    if self.button_type == "Button Type \(i+1)" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }

                        }
                    } label: {
                        LineTextField(title: "Select Button Type", placeholder: "Select Button Type", text: $button_type, rightView: AnyView(Image("drop-down-white")), isDropDown: true)
                    }
                    
                    Menu {
                        
                        ForEach(0..<4) { i in
                            
                            Button {
                                self.button_link = "Link \(i+1)"
                            } label: {
                                
                                HStack {
                                    
                                    Text("Link \(i+1)")
                                    
                                    if self.button_link == "Link \(i+1)" {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }

                        }
                    } label: {
                        LineTextField(title: "Button Link To", placeholder: "Please Select", text: $button_link, rightView: AnyView(Image("drop-down-white")), isDropDown: true)
                    }
                    
                    HStack(spacing: 15) {
                        
                        Button {
                            presentationMode.wrappedValue.dismiss()
                        } label: {
                            Text("Cancel")
                                .frame(maxWidth: .infinity).frame(height: 55)
                                .background(Color.greenColor.opacity(0.6))
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12).stroke(Color.greenColor, lineWidth: 1)
                                )
                        }
                        
                        Button {
                            //presentationMode.wrappedValue.dismiss()
                            self.presentItem = PresentItem(VideoSuccessView())
                        } label: {
                            Text("Submit")
                                .modifier(GradientView(55))
                        }
                    }.padding()
                    
                }
                .padding(.top, 30)
            }
        }
        .fullScreenCover(item: $presentItem, content: { item in
            AnyView(item.view)
        })
        .foregroundColor(.white)
        .font(p6Font)
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("ADD DETAILS")
            }
        }
    }
}

struct AddVideoDetailsView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            AddVideoDetailsView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
