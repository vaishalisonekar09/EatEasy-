//
//  RecentView.swift
//  AxisVD
//
//  Created by Gipl on 22/09/23.
//

import SwiftUI

struct RecentView: View {
    
    //let categories = ["music", "gaming", "education", "animation"]
    //let categories = ["music", "gaming", "education", "animation"]
    
    @State private var category = "history"
    
    var body: some View {
        
        VStack {
            
            ScrollView(showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 15) {
                    
                    Text("RECENT VIEW")
                        .font(h18Font)
                        .padding([.horizontal, .top])
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack(spacing: 15) {
                            
                            ForEach(0..<10) { i in
                                audioRow()
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    HStack(spacing: 15) {
                        Spacer(minLength: 0)
                        categoryRow(icon: "history", title: "History")
                        Spacer(minLength: 0)
                        categoryRow(icon: "myvideos", title: "My Videos")
                        Spacer(minLength: 0)
                        categoryRow(icon: "superlike", title: "Superlike")
                        Spacer(minLength: 0)
                        categoryRow(icon: "liked-white", title: "Liked")
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 50)
                    
                    HStack {
                        Text("PLAYLIST \(Text("(Recently Added)").font(p2Font).foregroundColor(.grayColor))")
                            .font(h18Font)
                        
                        Spacer()
                        
                        HStack(spacing: 4) {
                            Image("add-list")
                            Text("New Playlist")
                                .foregroundColor(.greenColor)
                        }
                    }
                    .padding(.horizontal)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack(spacing: 15) {
                            ForEach(0..<30) { i in
                                playlistRow()
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
        }
        .foregroundColor(.white)
        .navigationBarTitle("", displayMode: .inline)
        .toolbar {
            
            ToolbarItem(placement: .principal) {
                titleView("LIBRARY")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                
                HStack(spacing: 15) {
                    
                    Image("search-white")
                    NavigationLink(destination: NotificationsView()) {
                        Image("bell")
                    }
                }
            }
        }
    }
    
    
    func audioRow() -> some View {
        
        VStack(alignment: .leading) {
            ZStack(alignment: Alignment(horizontal: .trailing, vertical: .bottom)) {
                
                Image("audio")
                Image("play")
                    .padding(.bottom, -15)
                    .padding(.trailing)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Toucan Die")
                
                HStack {
                    Image("unlike")
                    Text("1125")
                    
                    Image("comment")
                    Text("250")
                }
                .foregroundColor(Color(0x919191))
                .font(h16Font)
            }
            
            .padding([.horizontal, .bottom], 10)
        }
        .background(Color.btnBgColor)
        .cornerRadius(8)
    }
    
    func categoryRow(icon: String, title: String) -> some View {
        
        VStack {
            
            Button(action: {
                
                category = icon
                
            }, label: {
                
                Image(icon)
                    .frame(width: 65, height: 65)
                    .background(icon == category ? Color.blueColor : Color.greenColor)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.greenColor.opacity(0.6), lineWidth: 1))
            })
            
            Text(title)
                .font(p3Font).fontWeight(.medium)
        }
    }
    
    func playlistRow() -> some View {
        
        ZStack(alignment: .bottom) {
            
            Image("wishlist")
                .resizable()
                .scaledToFill()
                .frame(width: 140, height: 170)
                .clipped()
            NavigationLink(destination: {
                ProfileView()
            }, label: {
                HStack {
                    Image("profile")
                        .resizable()
                        .frame(width: 30, height: 30)
                    Text("Thomas Curtis")
                        .font(p2Font)
                    Spacer(minLength: 0)
                }
            })
            .padding(8)
            .background(
                LinearGradient(colors: [.black.opacity(0.3), .clear], startPoint: .bottom, endPoint: .top)
            )
        }
        .cornerRadius(8)
    }
}

struct RecentView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            RecentView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
