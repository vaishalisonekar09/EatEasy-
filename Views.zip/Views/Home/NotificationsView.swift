//
//  NotificationsView.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct NotificationsView: View {
    
    var body: some View {
        
        VStack {
            
            ScrollView {
                
                LazyVStack(spacing: 0) {
                    
                    ForEach(1..<200) { i in
                        notificationRow()
                        Divider()
                    }
                    
                }.padding()
            }
        }
        .modifier(BlackBackgroundModifier())
        .toolbar {
            ToolbarItem(placement: .principal) {
                titleView("NOTIFICATIONS")
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                Image("search-white")
            }
        }
    }
    
    func notificationRow() -> some View {
        
        HStack(alignment: .top, spacing: 15) {
            Image("mask")
                .resizable()
                .frame(width: 50, height: 50)
            
            VStack(alignment: .leading, spacing: 5) {
                
                Text("Congratulations!!")
                    .font(h16Font)
                
                Text("you have been selected for free trial of gym for 10 days")
                    .foregroundColor(.grayColor)
                    .font(p6Font)
                
                Text("08:36 pm")
                    .foregroundColor(.grayColor)
                    .font(p6Font)
                
            }
        }
        .padding(.vertical, 12)
    }
}

struct NotificationsView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        NavigationView {
            NotificationsView()
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}
