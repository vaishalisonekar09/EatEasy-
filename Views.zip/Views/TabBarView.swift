//
//  TabBarView.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct TabBarView: View {
    
    @State private var selection = "home"
    @State private var presentItem: PresentItem?
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            if selection == "home" {
                HomeView()
            }
            
            if selection == "library" {
                NavigationView {
                    RecentView()
                }
            }

            if selection == "player" {
                NavigationView {
                    ReelsView()
                }
            }
            
            if selection == "messages" {
                NavigationView {
                    MessagesView()
                }
            }
            
            if selection == "profiles" {
                NavigationView {
                    ProfileView(user_profile: false)
                }
            }
            
            HStack(alignment: .bottom) {
                
                Button {
                    selection = "home"
                } label: {
                    tabRow(selection == "home" ?  "home-active" : "home-white", title: "Home")
                        .foregroundColor(selection == "home" ? .blueColor : .white)
                }
                
                Button {
                    selection = "library"
                } label: {
                    tabRow(selection == "library" ? "library-active" : "library", title: "Library")
                        .foregroundColor(selection == "library" ? .blueColor : .white)
                }
                
                Button {
                    //self.selection = "player"
                    self.presentItem = PresentItem(NavigationView { ReelsView() })
                } label: {
                    Image("player-tab")
                        .resizable()
                        .frame(width: 55, height: 55)
                }
                .padding(.top, -25)
                .offset(y: -25)
                
                Button {
                    selection = "messages"
                } label: {
                    tabRow(selection == "messages" ? "messages-active" : "messages", title: "Messages")
                        .foregroundColor(selection == "messages" ? .blueColor : .white)
                }
                
                Button {
                    selection = "profiles"
                } label: {
                    tabRow(selection == "profiles" ?  "profiles-active" : "profiles", title: "Profiles")
                        .foregroundColor(selection == "profiles" ? .blueColor : .white)
                }
            }
            .padding(.top, 10)
            .padding(.horizontal)
            .background(Color.bgColor.edgesIgnoringSafeArea(.bottom))
            .shadow(color: Color.blueColor, radius: 3)
            
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .font(p3Font)
        .fullScreenCover(item: $presentItem) { item in
            AnyView(item.view)
        }
        
    }
    
    func tabRow(_ image: String, title: String) -> some View {
        
        VStack(spacing: 4) {
            Image(image)
            Text(title)
        }
        .frame(maxWidth: .infinity)
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView()
    }
}
