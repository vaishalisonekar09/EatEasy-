//
//  CarouselViewModel.swift
//  AxisVD
//
//  Created by Gipl on 09/10/23.
//

import SwiftUI

class CarouselViewModel: ObservableObject {
    
    @Published var data = [
        Card(id: 0, img: "intro1", name: "Jill 1", show: false),
        Card(id: 1, img: "intro2", name: "Jill 2", show: false),
        Card(id: 2, img: "intro3", name: "Jill 3", show: false)
    ]
    
    @Published var x: CGFloat = 0
    @Published var count: CGFloat = 0
    @Published var screen = UIScreen.main.bounds.width - 100

    func getMid() -> Int {
        return data.count / 2
    }
    
    func updateHeight(value: Int) {
        var id: Int
        if value < 0 {
            id = -value + getMid()
        } else {
            id = getMid() - value
        }
        
        for i in 0..<data.count {
            data[i].show = false
        }
        
        data[id].show = true
    }
}

struct Card: Identifiable {
    var id: Int
    var img: String
    var name: String
    var show: Bool
}
