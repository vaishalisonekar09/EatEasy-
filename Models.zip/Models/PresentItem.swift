//
//  PresentItem.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

struct PresentItem: Identifiable {
    let id = UUID().uuidString
    let view: any View
    
    init(_ view: any View) {
        self.view = view
    }
}
