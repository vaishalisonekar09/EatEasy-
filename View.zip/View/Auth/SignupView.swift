//
//  LoginView.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct SignupView: View {
    
    @State private var first_name = ""
    @State private var last_name = ""
    @State private var phone_number = ""
    @State private var company_name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPass = ""
    
    @Environment(\.presentationMode) var presentation
    
    @State var first_error_msg = ""
    @State var last_error_msg = ""
    @State var number_error_msg = ""
    @State var company_error_msg = ""
    @State var email_error_msg = ""
    @State var pass_error_msg = ""
    @State var confirm_error_msg = ""


    
    var body: some View {
        
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 8) {
                    
                        Image("monogram-logo")
                            .padding(.top,40)
                        
                        HStack {
                            Text("CREATE")
                                .font(h34RegularFont)
                            
                            Text("ACCOUNT")
                                .font(h34RegularFont).bold()
                                .foregroundColor(.yellowColor)
                        }
                    
                    Text("Enter your information below to Login")
                        .font(m7Font)
                    
                    VStack(spacing : 20) {
                        
                        CustomTextField(placeholder: "First Name", text: $first_name, errorMsg: $first_error_msg)
                        CustomTextField(placeholder: "Last Name", text: $last_name, errorMsg: $last_error_msg)
                        CustomTextField(placeholder: "Contact Number", text: $phone_number , keyboardType: .phonePad, errorMsg: $number_error_msg)
                        CustomTextField(placeholder: "Company Name", text: $company_name, errorMsg: $company_error_msg)
                        CustomTextField(placeholder: "Email Id", text: $email , keyboardType: .emailAddress, errorMsg: $email_error_msg)
                        CustomTextField(placeholder: "Password", text: $password, errorMsg: $pass_error_msg)
                        CustomTextField(placeholder: "Confirm Password", text: $confirmPass, errorMsg: $confirm_error_msg)
                       
                    }.padding(.top, 30)
                        .padding(.horizontal)
                    
                    Button{
                        validateSignupForm()
                        
                    }label: {
                        Text("Signup")
                            .modifier(WhiteModifier())
                    }.padding(.top)
                        .padding(.horizontal)
                    
                }.padding()
            
        }.background(Color.greenColor.ignoresSafeArea())
            .foregroundColor(.white)
            .onTapGesture {
                hideKeyboard()
            }
    }
    
    
    func validateSignupForm(){
        
        first_error_msg      = first_name.isempty ? "Enter first name." : ""
        last_error_msg       = last_name.isempty ? "Enter last name." : ""
        number_error_msg     = phone_number.isempty ? "Enter contact number." : ""
        company_error_msg    = company_name.isempty ? "Enter company name." : ""
        email_error_msg      = email.isempty ? "Enter email." : ""
        pass_error_msg       = password.isempty ? "Enter password." : ""
        
        if password != confirmPass {
            confirm_error_msg = "Password and confirm password doesn't match."
        }else if confirmPass.isempty {
            confirm_error_msg = "Enter confirm password."
        }else{
            confirm_error_msg = ""
        }
        
        if first_error_msg == "" && last_error_msg == "" && number_error_msg == "" && company_error_msg == "" && email_error_msg == "" && pass_error_msg == "" && confirm_error_msg == "" {
            print("success")
            signUpCalling()
            
        }
    }
    
    func signUpCalling(){
           
           let parameter = [ApiKey.first_name : first_name,
                            ApiKey.last_name : last_name,
                            ApiKey.phone_number : phone_number,
                            ApiKey.email : email,
                            ApiKey.company_name : company_name,
                            ApiKey.password : password,
                            ApiKey.confirm_password : confirmPass]
           
           showProgressHUD()
           DataManager.getApiResponse(parameter, methodName: .signupUser) { json, error in
               dismissProgressHUD()
               makeToast(apiMessage(json))
               if apiStatus(json) {
                   DispatchQueue.main.asyncAfter(deadline: .now()+1) {
                       presentation.wrappedValue.dismiss()
                   }
               }
           }
       }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView()
    }
}
