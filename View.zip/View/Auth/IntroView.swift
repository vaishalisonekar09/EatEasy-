//
//  IntroView.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct IntroView: View {
    
    @State private var presentItem: PresentItem?

    var body: some View {
        
        ZStack(alignment: .bottom)  {
            
            VStack {
                
                Image("bg-overlay")
                    .resizable()
                    .ignoresSafeArea()
            }
            
            VStack(spacing: 20) {
                Text("Reach Out & Touch Jewelry")
                    .font(h36BoldFont)
                
                Text("Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam")
                    .font(m6Font)
                
                Button{
                    self.presentItem = PresentItem(LoginView())
                }label: {
                   Text("Get Started")
                        .modifier(WhiteModifier())
                        .padding([.top, .horizontal],25)
                        
                }
                
            }.padding()
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                
        }.fullScreenCover(item: $presentItem) { item in
            AnyView(item.view)
        }
    }
}

struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
