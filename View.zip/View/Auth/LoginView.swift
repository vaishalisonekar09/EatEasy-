//
//  LoginView.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct LoginView: View {
    
    @State private var mobile = "9876987600"
    @State private var password = "System@123"
    
    @State private var presentItem : PresentItem?
    @State private var show_password = false
    
    @State var mobileErrorMsg = ""
    @State var passErrorMsg = ""

    
    var body: some View {
        
        VStack {
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 5) {
                    
                    Image("monogram-logo")
                        .padding(.top,40)
                        
                    
                    Text("WELCOME TO")
                        .font(h34RegularFont)
                    
                    Text("KAPISH JEWELS")
                        .font(h34RegularFont).bold()
                        .foregroundColor(.yellowColor)
                        .padding(-15)
                    
                    Text("Enter your information below to Login")
                        .font(m7Font)
                        .padding(.top,15)
                    
                    VStack(spacing : 20) {
                        
                        CustomTextField(placeholder: "Enter Your Number", text: $mobile , keyboardType: .phonePad, errorMsg : $mobileErrorMsg)
                        
                        CustomTextField(placeholder: "Enter Your Password", text: $password ,errorMsg : $passErrorMsg,  rightView: AnyView(
                            Button(action: {
                                show_password.toggle()
                            },label: {
                                Image(show_password ? "eye-show": "eye-off")
                                
                            })
                        ))
                        
                        HStack{
                            Spacer()
                            
                            Button{
                                
                            }label: {
                                Text("Forgot your password?")
                                    .font(m6Font)
                            }
                        }
                        
                    }.padding(.top, 30)
                    
                    Button{
                       
                        validateLoginForm()
                    }label: {
                        Text("Login")
                            .modifier(WhiteModifier())
                    }.padding(.top,25)
                    
                }.padding(.horizontal,30)
                
            }
            
            HStack(spacing:4){
                Text("Don't have an account?")
                    .font(m6Font)
                
                Button {
                    presentItem = PresentItem(SignupView())
                } label: {
                    Text("Sign Up")
                        .font(m6Font.semibold())
                }
                
                
            }
            
        }.background(Color.greenColor.ignoresSafeArea())
            .foregroundColor(.white)
            .onTapGesture {
                hideKeyboard()
            }
        
            .fullScreenCover(item: $presentItem) { item in
                AnyView(item.view)
            }
    }
    
    
    func validateLoginForm(){
        hideKeyboard()
        
        mobileErrorMsg = mobile.isempty ? "Enter mobile number." : ""
        passErrorMsg   = password.isempty ? "Enter password." : ""
        
        if mobileErrorMsg == "" &&  passErrorMsg == "" {
            loginApiCall()
        }
    }
    
    
    
    
    func loginApiCall(){
        
        let parameter = [ApiKey.phone_number : mobile,ApiKey.password :  password]
        
        showProgressHUD()
        DataManager.getApiResponse(parameter, methodName: .login) { json, error in
            dismissProgressHUD()
            
            makeToast(apiMessage(json))
            
            if apiStatus(json) {
                saveStorage(json.userData)
                Storage.token = json["token"].stringValue
                Storage.login = true
            }
        }
    }
    
    
   
    
    
    
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
