//
//  SideMenu.swift
//  Kapish Jewels
//
//  Created by gipl on 17/10/23.
//

import SwiftUI

struct SideMenu: View {
    
    let width: CGFloat
    let isOpen: Bool
    var menuClose: () -> Void = { }
    
    @State var isSelected      = 0
    @State var isExpandable     = false
    @State private var selection: String?
    
    @State var categoryArr = ["Rings","Earrings","Necklace"]

    
    var body: some View {
        
        ZStack {
            GeometryReader { _ in
                EmptyView()
            }
            .background(Color.greenColor.opacity(0.5))
            .opacity(self.isOpen ? 1.0 : 0.0)
            .onTapGesture {
                
                self.menuClose()
            }
            
            /***********Side Menu view**************/
            HStack {
                
                VStack {
                    
                    VStack {
                        
                        Image("avatar")
                            .resizable()
                            .frame(width: 90,height: 90)
                            .clipped()
                            .padding(.top,65)
                        
                        Text("Christina Bishop")
                            .font(m8Font.medium())
                            .frame(maxWidth: .infinity)
                        
                    }
                        
                    
                    Divider()
                        .overlay(Color.white)
                        .padding([.horizontal,.top],25)
                    
                    ScrollView(showsIndicators: false) {
                        
                        VStack(spacing: 0) {
                            
                            Button {
                                isSelected = 0
                                self.menuClose()
                            }label: {
                                Text("Home")
                                    .frame(height: 55)
                                    .frame(maxWidth : .infinity)
                                    .background(isSelected == 0 ? Color.bgGreenColor : Color.clear)
                            }
                            
                            Button {
                                isSelected = 1
                                selection = "wishlist"
                                self.menuClose()
                            }label: {
                                    
                                Text("Wishlist")
                                    .frame(height: 55)
                                    .frame(maxWidth : .infinity)
                                    .background(isSelected == 1 ? Color.bgGreenColor : Color.clear)
                            }
                            
                            
                            Button {
                                withAnimation {
                                    isExpandable.toggle()
                                }
                                
                            }label: {
                                HStack(spacing : 20) {
                                    
                                    Text("Categories")
                                    Image(systemName: isExpandable ? "minus" : "plus")
                                    
                                }.frame(height: 55)
                                    .frame(maxWidth : .infinity)
                            }
                            
                            
                            if isExpandable {
                                
                                VStack {
                                    ForEach(0..<categoryArr.count, id: \.self) { i in
                                        
                                        Button {
                                            selection = "product-list"
                                            self.menuClose()

                                        } label: {
                                            Text(categoryArr[i])
                                                .frame(height: 50)
                                                .frame(maxWidth : .infinity)
                                        }
                                    }
                                }
                            }
                            
                            
                            
                            
                        }
                    }.padding(.top,30)
                        .font(montserrat(size: 20,weight: .medium))
                        .foregroundColor(Color.white)
                    
                    Divider()
                        .overlay(Color.white)
                        .padding(.horizontal,25)
                        .padding(.bottom , 10)
                    
                    
                    Button {
                        Storage.login = false
                    }label: {
                        Text("Logout")
                            .modifier(YellowModifier())
                        
                            
                    }.padding(.horizontal,30)
                        .padding(.bottom , 40)
                    
                }.background(Color.greenColor)
                    .foregroundColor(.white)
                    .frame(width: self.width)
                    .background(Color.white)
                    .offset(x: self.isOpen ? 0 : -self.width)
                
                Spacer()
                
            }.background(NavigationLink(destination: WishlistView(), tag: "wishlist", selection: $selection) { EmptyView() })
                .background(NavigationLink(destination: ProductListView(), tag: "product-list", selection: $selection) { EmptyView() })
        }
        
        .ignoresSafeArea(.all)
        
    }
}





struct SideMenu_Previews: PreviewProvider {
    static var previews: some View {
        SideMenu(width: 300, isOpen: true )
    }
}
