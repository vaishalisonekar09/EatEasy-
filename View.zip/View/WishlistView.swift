//
//  CartView.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct WishlistView: View {
    
    var body: some View {
    
        VStack {
            
            Divider()
                .overlay(Color.borderColor)
            
            
            ScrollView(showsIndicators: false) {
                
                ForEach(0..<3) { i in
                    WishlistRow()
                }
            }
            
        }.padding()
            .navigationBarTitle("", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    titleView("Wishlist")
                }
            }
    }
}

struct WishlistView_Previews: PreviewProvider {
    static var previews: some View {
        
        NavigationView {
            WishlistView()
        }
        
    }
}



struct WishlistRow : View {
    
    @State var is_like = true
    
    var body: some View {
        
        VStack {
            
            HStack(alignment: .top, spacing: 10) {
                
                Image("ring").resizable()
                    .frame(width: 60,height: 60)
                    .overlay(RoundedRectangle(cornerRadius: 0).stroke(Color.borderColor, lineWidth: 0.5))
               
                
                VStack(alignment: .leading,spacing: 8) {
                    Text("Couple Gold Ring")
                        .font(h16Font)
                    
                    Text("₹130.50")
                        .font(m2Font.semibold())
                }
                
                Spacer(minLength: 0)
                
                Button {
                    is_like.toggle()
                }label: {
                    Image(is_like ? "like" : "unlike")
                }
                
                
                
            }.padding(.vertical,10)
                .foregroundColor(.textBlackColor)
            
            Divider().foregroundColor(.dividerColor)
        }
            
    }
}


struct WishlistRow_Previews: PreviewProvider {
    static var previews: some View {
        WishlistRow()
    }
}
