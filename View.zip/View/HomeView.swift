//
//  HomeView.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct HomeView: View {
    
    @State private var selection: String?
    
    @State var category_list = [JSON]()
    @State var category_image_url = ""
    
    @State var menuOpen: Bool = false

    
    var body: some View {
        
        NavigationView {
            
            ZStack {
                
                Color.greenColor.ignoresSafeArea()
                
                VStack(spacing : 0) {
                    Divider()
                        .background(NavigationLink(destination: CartView(), tag: "cart", selection: $selection) { EmptyView() })
                        .background(NavigationLink(destination: WishlistView(), tag: "wishlist", selection: $selection) { EmptyView() })
                    
                     ScrollView(showsIndicators: false) {
                        
                        VStack(spacing : 0) {
                            
                            ForEach(0..<category_list.count, id: \.self) { i in
                                
                                ZStack(alignment: .bottom) {
                                    
                                    Image("braclet")
                                        .resizable()
                                    
                                    VStack(spacing : 5) {
                                        Text(category_list[i].name)
                                            .lineLimit(1)
                                            .font(h28RegularFont)
                                        
                                        Text("\(category_list[i].Count) Products")
                                            .font(m5Font)
                                        
                                    }.padding(.bottom)
                                    
                                }.frame(width: SSize.WIDTH , height: 210)
                                    .onTapGesture {
                                        selection = "product-list"
                                    }
                                    .background(NavigationLink(destination: ProductListView(), tag: "product-list", selection: $selection) { EmptyView() })
                                
                                
                            }
                            
                        }
                    }
 
                }.foregroundColor(.white)
                    //.background()
                    .navigationBarTitle(Text(""), displayMode: .inline)
                
                SideMenu(width: SSize.WIDTH-60, isOpen: menuOpen) {
                    withAnimation {
                        menuOpen.toggle()
                    }
                    
                }
                
            }.toolbar {
                
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        menuOpen.toggle()
                    } label: {
                        Image("menu")
                    }
                }
                
                ToolbarItem(placement: .principal) {
                    titleView("Categories", foregroundColor: .white)
                        .foregroundColor(.white)
                }
                
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    
                    HStack {
                        
                        Button {
                            selection = "wishlist"
                        } label: {
                            Image("unlike")
                        }
                        
                        Button {
                            selection = "cart"
                        } label: {
                            Image("cart")
                        }
                        
                    }
                }
            }
            
            .onAppear{
                getCategoryList()
            }
            

        }
        
    }
    
    
    func getCategoryList(){
        
        showProgressHUD()
        DataManager.getApiResponse([:], methodName: .getCategoryList) { json, error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                category_list = json["data"].arrayValue
                category_image_url = json.category_image_url
                
            } else {
                makeToast(apiMessage(json))

            }
        }
    }

    
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
            HomeView()
    }
}


