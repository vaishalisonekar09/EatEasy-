//
//  CartView.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct ProductDetailView: View {
    
    @State private var size_array             = ["4.5","5.5","6.5","7.5"]
    @State private var seletedSize            = "7.5"
    @State private var is_like                = true
    @State var index                 = 0
    
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            Divider()
                .overlay(Color.borderColor)
            
            ScrollView(showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 20) {
                    
                    VStack(alignment: .leading, spacing: 10){
                        
                        Text("Couple Gold Ring")
                            .font(h24RegularFont.medium())
                            .padding(.top, 15)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("₹130.50")
                            .font(m6Font.bold())
                    }
                    
                    
                    VStack(spacing: 20){
                        
                        TabView(selection: $index.animation()) {
                            
                            ForEach(0..<4){ i in
                                
                                Image("ring")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: SSize.WIDTH * 0.6)
                                    .frame(maxWidth: .infinity)
                                
                            }
                        }
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        .frame(height: SSize.WIDTH * 0.6)
                        .overlay(
                            HStack {
                                Button {
                                    is_like.toggle()
                                }label: {
                                    Image(is_like ? "like" : "unlike")
                                }.padding([.top,.trailing])
                                
                            }.padding(5), alignment: .topTrailing)
                        
                        HStack{
                            ForEach(0..<4){ i in
                                
                                Image(i == index ? "dot" : "dot2")
                                    .resizable()
                                    .frame(width: i == index ? 10 : 8, height: i == index ? 10 : 8)
                            }
                        }
                    }
                    
                    /*
                    HStack {
                        Text("Ring Size:")
                        
                        Menu {
                            ForEach(0..<size_array.count , id: \.self) { i in
                                Button {
                                    seletedSize = size_array[i]
                                }label: {
                                    Text(size_array[i])
                                }
                            }
                            
                        } label: {
                            HStack {
                                Text(seletedSize)
                                Image("dropdown")
                            }
                        }
                    }.font(m7Font.medium())
                        .padding(.vertical,10)
                    */
                    
                    
                    VStack(spacing : 10) {
                        
                        NavigationLink{
                            CartView()
                        }label: {
                            Text("Add to Cart")
                                .modifier(GreenModifier())
                        }
                        
                        NavigationLink{
                            CartView()
                        }label: {
                            Text("Add to Enquiry")
                                .modifier(GreenModifier())
                        }
                        
                        Button{
                            
                        }label: {
                            Text("Share with details")
                                .modifier(GreenModifier())
                        }
                        
                        Button{
                            
                        }label: {
                            Text("Share without details")
                                .modifier(GreenModifier())
                        }
                        
                    }.padding(.top)
                    
                    /*
                    Text("Your boyfriend denim just found its match. It’s handcrafted in 14k solid gold. Raw, loose, and bold. Wear it every day – whenever, wherever. This ring is crafted with rose gold and polished by hand for high shine.")
                        .foregroundColor(.borderColor)
                    
                    VStack(alignment: .leading, spacing: 15){
                        attrView("Made in 14k solid gold")
                        attrView("Length: 18 inches")
                    }*/
                    
                    VStack(spacing : 0){
                        attrView("Item", value: "L.Ring")
                        attrView("Item Code", value: "SSR-1683")
                        attrView("Stone com", value: "DIA")
                        attrView("Labour", value: "L-1300")
                        attrView("N W", value: "2.238 KG")
                        attrView("Purity", value: "14k")
                        attrView("DIA Weight", value: "0.08 KG")
                        Group{
                            attrView("DIA Price", value: "Rs. 64.000.00")
                            attrView("CS Weight", value: "-")
                            attrView("CS Price", value: "-")
                            attrView("G W", value: "2.254 KG")
                            attrView("Sold Stock", value: "SOLD")
                        }
                    }.overlay(RoundedRectangle(cornerRadius: 0).stroke(Color.borderColor, lineWidth: 0.5))
                    
                    
                    
                }
                
            }
            
        }.foregroundColor(.black)
            .font(m6Font)
        
            .padding()
            .navigationBarTitle("", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    titleView("Shopping")
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack{
                        NavigationLink {
                            WishlistView()
                        }label: {
                            Image("like-gray")
                        }
                        
                        
                        NavigationLink {
                            CartView()
                        }label: {
                            Image("cart-gray")
                        }
                        
                    }
                }
            }
    }
    
    
   
    
    
    func attrView(_ title:String ,value:String) -> some View{
        HStack(spacing : 0){
            Text(title)
                .frame(width: 150,height: 40)
                .background(Color.lightGrayColor)
                .font(m3Font.medium())
                
            
            Divider()
                
            
            Text(value)
                
                .frame(maxWidth : .infinity)
            
        }.foregroundColor(.black)
            .font(m3Font)
            .frame(height: 40)
            .overlay(
               Divider()
                .frame(height : 1)
                , alignment: .bottom)
        
        
    }
}

struct ProductDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ProductDetailView()
        }
        
    }
}



