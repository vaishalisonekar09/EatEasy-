//
//  ProductListView.swift
//  Kapish Jewels
//
//  Created by gipl on 17/10/23.
//

import SwiftUI

struct ProductListView: View {
    
    @State private var selection : String?
    @State var page                 = 1
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            Divider()
            
            ScrollView(showsIndicators: false) {
                
                VStack(spacing: 0) {
                    
                    ZStack(alignment: .top) {
                        
                        Image("bg dark")
                            .resizable()
                            .frame(height: SSize.WIDTH*0.8)
                            
                        
                        VStack(spacing: 20){
                            
                            Text("Up to 20% Off Summer Sale")
                                .font(h34RegularFont)
                                .padding(.top,20)
                            
                            Text("Grab amazing discounts for the next 15 days")
                                .font(m7Font.light())
                            
                            Button{
                                
                            }label: {
                                Text("Shop now")
                                    .modifier(YellowModifier(40))
                                    .frame(width: 180)
                                    .padding(.top,20)
                            }
                            
                        }.padding()
                        
                    }
                    
//                    HStack {
//                        Spacer()
//                        Image("Filter")
//
//                    }.padding(15)
//                        .background(Color.greenColor)
                    
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                        
                        ForEach(0..<5) { i in
                            ProductRow()
                                .onTapGesture {
                                    selection = "product-detail"
                                }
                                .background(NavigationLink(destination: ProductDetailView(), tag: "product-detail", selection: $selection) { EmptyView() })
                            
                        }
                    }.padding(.horizontal)
                        .padding(.top, 15)
                    
                }
            }.ignoresSafeArea()
            
        }.foregroundColor(.white)
            .onAppear {
                getProductList()
            }

            .navigationBarTitle("", displayMode: .inline)
            .toolbar {
                
                ToolbarItem(placement: .principal) {
                    
                    Text("Rings")
                        .font(montserrat(size: 20,weight: .regular))
                        .foregroundColor(.black)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack{
                        
                        NavigationLink {
                            WishlistView()
                        }label: {
                            Image("unlike")
                        }
                        
                        NavigationLink {
                           FilterView()
                        }label: {
                            Image("Filter")
                                .renderingMode(.template)
                                .foregroundColor(.black)
                        }
                        
                    }
                }
            }//.background(Color.black)
        
    }
}
/*
 {"device_token":"d302PjEVQJ6e0t-3-8Dhq_:APA91bGKmwKkLB5mn5YZlCR3EBMi0w-OGpE2B2MdIUlHnsR1pQWNTQZ6rs7YdHVO4D4kyKwOM6s17N9Zly94Q2eivdC911_eEW0tXQnpbZyPcRcTNasgjz_StOLOkyIJHTh5o69Klo4k","device_type":"android","api_referrer":"mobile","device_id":"123","method_name":"getProductList","data":{"page":"1","user_id":"36","category_id":"10","filter":{}}}
 */


func getProductList() {
    
    let parameter = [ ApiKey.page: "1",
                     ApiKey.user_id: "36",
                     ApiKey.category_id: "10",
                     ApiKey.filter:{}
                   ] as [String : Any]
    
    showProgressHUD()
    DataManager.getApiResponse([:], methodName: .getProductList) { json, error in
        dismissProgressHUD()
        
        if apiStatus(json) {
            
        } else {
            makeToast(apiMessage(json))
        }
        
        
    }
}
    
struct ProductListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ProductListView()
        }
        
    }
}




struct ProductRow: View {
    
    var width = SSize.WIDTH/2-24
    var body: some View {
        
        VStack(spacing: 8){
            Image("neckles")
                .resizable()
                .frame(width: width, height: width*0.9)
            
            Text("Diamond Ring")
                .font(h16Font.bold())
            
            Text("$142.99")
                .font(m2Font)
                .padding(.bottom,8)
            
        }.padding(2)
            .background(Color.lightGreenColor)
            .foregroundColor(.black)
    }
}


struct ProductRow_Previews: PreviewProvider {
    static var previews: some View {
        ProductRow()
    }
}
