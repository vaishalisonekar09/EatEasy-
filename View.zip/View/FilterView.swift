//
//  FilterView.swift
//  Kapish Jewels
//
//  Created by gipl on 31/10/23.
//



import SwiftUI

struct FilterView: View {
    
    var stoneArray = ["Diamond", "Gold", "Ruby", "Sapphire"]
    
    @State private var selectedStones = Set<String>()
    
    @State  var stoneArrayModel       = [StoneModel]()
    
//    var purityArray = ["22k", "24k", "23k", "18k"]
//    @State private var select_purity  = ""
    
    @State var purityArray = [JSON]()
    @State var select_purity = JSON()
       
    @State var selected_max_nw : CGFloat      = 50.0
    @State var selected_min_nw : CGFloat      = 0.0
    
    @State var selected_max_dia : CGFloat     = 50.0
    @State var selected_min_dia : CGFloat     = 0.0
    
    @State var selected_max_price : CGFloat   = 250000
    @State var selected_min_price : CGFloat   = 0
    
    @State var selected_max_wt : CGFloat      = 250000
    @State var selected_min_wt : CGFloat      = 0
    
    var body: some View {
        
        VStack {
            
            Divider()
                .overlay(Color.borderColor)
            
            ScrollView(showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 10) {
                    
                    Text("Stone Com.")
                        .font(m8Font)
                    
                    Menu {
                        
                        ForEach(stoneArrayModel) { stone in
                            
                            Button(action: {
                                if selectedStones.contains(stone.id) {
                                    selectedStones.remove(stone.id)
                                } else {
                                    selectedStones.insert(stone.id)
                                }
                            }) {
                                HStack {
                                    Text(stone.text)
                                    Spacer()
                                    if selectedStones.contains(stone.id) {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                        }
                    } label : {
                        
                        HStack {
                            Text(selectedStones.isEmpty ? "" : selectedStones.joined(separator: ", "))
                                .foregroundColor(Color.black)
                                .font(m8Font)
                            Spacer()
                            Image("dropdown")
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .padding(.horizontal, 10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1))
                    }
                }
                
                VStack(alignment: .leading, spacing: 10) {
                    
                    Text("Purity")
                        .font(m8Font)
                    
                    Menu {
                        
                        ForEach(0..<purityArray.count, id: \.self) { purity in
                            
                            Button(action: {
                                select_purity = purityArray[purity]
                            }) {
                                Text(purityArray[purity].text)
                                
                                if  purityArray[purity].id == select_purity.id {
                                    Image(systemName: "checkmark")
                                }
                            }
                        }
                        
                    } label : {
                        
                        HStack {
                            
                            Text(select_purity.id.isEmpty ? "" : select_purity.text)
                                .foregroundColor(Color.black)
                            
                            Spacer()
                            
                            Image("dropdown")
                            
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .padding(.horizontal, 10)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.dividerColor, lineWidth: 1))
                    }
                    
                } .padding(.top, 10)
                
                VStack(alignment: .leading, spacing: 10) {
                    
                    Text("N.W")//0.0
                    SeekSlider(minValue: 0.0, maxValue: 50.0, selectedMaxValue: $selected_max_nw, selectedMinValue: $selected_min_nw)
                    
                    HStack {
                        
                        Text("\(Float(selected_min_nw))"+" "+"range")
                        Spacer()
                        Text("\(Float(selected_max_nw))"+" "+"range")

                    }
                    .frame(height: 1)
                 
                    
                    Text("DIA.Wt")
                    SeekSlider(minValue: 0.0, maxValue: 50.0, selectedMaxValue: $selected_max_dia, selectedMinValue: $selected_min_dia)
                    
                    HStack {
                        
                        Text("\(Float(selected_min_dia))"+" "+"range")
                        Spacer()
                        Text("\(Float(selected_max_dia))"+" "+"range")

                    }
                    .frame(height: 1)
                       
                    Group {
                        
                        Text("DIA PRICE")//1
                        SeekSlider(minValue: 0, maxValue: 250000, selectedMaxValue: $selected_max_price, selectedMinValue: $selected_min_price)
                        
                        HStack {
                            
                            Text("\(Int(selected_min_price))"+" "+"range")
                            Spacer()
                            Text("\(Int(selected_max_price))"+" "+"range")

                        }
                        .frame(height: 1)
                         
//                        Text("CS Wt.")
//                        SeekSlider(minValue: 1, maxValue: 50, selectedMaxValue: $selected_max_value, selectedMinValue: $selected_min_value)
//                            .frame(height: 1)
                        
                        Text("PRICE")
                        SeekSlider(minValue: 0, maxValue: 250000, selectedMaxValue: $selected_max_wt, selectedMinValue: $selected_min_wt)
                        
                        HStack {
                            
                            Text("\(Int(selected_min_wt))"+" "+"range")
                            Spacer()
                            Text("\(Int(selected_max_wt))"+" "+"range")

                        }
                        .frame(height: 1)
                        
//                        Text("G.W.")
//                        SeekSlider(minValue: 0, maxValue: 50, selectedMaxValue: $selected_max_value, selectedMinValue: $selected_min_value)
//                            .frame(height: 1)
                    }
                    
                } .padding(.top, 8)
                
            }
            
        }.padding()
            .onAppear {
                getFilterList()
            }
            .navigationBarTitle("", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        
                    }, label: {
                        Image("reset")
                    })
                }
                ToolbarItem(placement: .principal) {
                    titleView("Filter")
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    
                    Button(action: {
                        
                    }, label: {
                        Image( "checkmark")
                    })
                    
                }
            }
    }
    
    func getFilterList() {
        
        showProgressHUD()
        DataManager.getApiResponse([:], methodName: .getMasterDropdown) { json, error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                self.purityArray = json["purity"].arrayValue
                
                self.stoneArrayModel = json["stone_com"].arrayValue.filter { $0.id != "" }.map { StoneModel(id: $0.id,  text: $0.text) }
                
              
            } else {
                makeToast(apiMessage(json))
                
            }
        }
    }
    
}

struct FilterView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FilterView()
        }
    }
}
