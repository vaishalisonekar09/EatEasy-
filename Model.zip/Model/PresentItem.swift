//
//  PresentItem.swift
//  Kapish Jewels
//
//  Created by gipl on 16/10/23.
//

import SwiftUI

struct PresentItem: Identifiable {
    let id = UUID().uuidString
    let view: any View
    
    init(_ view: any View) {
        self.view = view
    }
}
