//
//  StoneModel.swift
//  Kapish Jewels
//
//  Created by gipl on 31/10/23.
//

import SwiftUI


struct StoneModel: Identifiable {

    var id  : String
    var text: String
    
    init(id: String, text: String) {
        self.id   = id
        self.text = text
    }
}
