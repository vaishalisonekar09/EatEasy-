//
//  AxisVDApp.swift
//  AxisVD
//
//  Created by Gipl on 04/09/23.
//

import SwiftUI

@main
struct AxisVDApp: App {
    
    @AppStorage("login") var login = false

    var body: some Scene {
        
        WindowGroup {
            if login {
                TabBarView()
                    .navigationBarTitleDisplayMode(.inline)
            } else {
                IntroView()
            }
        }
    }
}
