//
//  ContentView.swift
//  AxisVD
//
//  Created by Gipl on 04/09/23.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
        VStack {
            
            Text("Hello")
            
        }.onAppear {
            for family in UIFont.familyNames {
                print("\(family)")

                for name in UIFont.fontNames(forFamilyName: family) {
                    print("   \(name)")
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
