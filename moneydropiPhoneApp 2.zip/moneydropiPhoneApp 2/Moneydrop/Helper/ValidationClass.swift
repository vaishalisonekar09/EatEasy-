//
//  ValidationClass.swift
//  Moneydrop
//
//  Created by Gipl on 20/12/22.
//

import UIKit
import SwiftUI
import Combine

struct Messages {
    
    static let enterSentAmount                  =   "Please enter send amount."
    static let enterCurrectSentAmount           =   "Please enter correct send amount."
    static let enterRecipientAmount             =   "Please enter recipient amount."
    static let enterCorrectAmount               =   "please enter correct amount."
    static let enterCurrectRecipientAmount      =   "Please enter correct recipient amount."

    static let selectBeneficiary   = "Please select beneficiary."
    static let enterEmail          = "Please enter your email."
    static let enterValidEmail     = "Please enter your valid email."
    static let enterPassword       = "Please enter password."
    static let enterValidPassword  = "Password must have minimum 8 characters and should contain at least one capital & small alphabet,one number,at least one special character."
    
    
  //  static let enterValidPassword  = "Password should include at least one capital & small alphabet,one number,at least one special character.The minimum and maximum length will be between 8 to 15."
    
    static let enterOldPassword                 = "Please enter old password."
    static let enterNewPassword                 = "Please enter new password."
    static let enterFirstName                   = "Please enter your full given names."
    static let enterLastName                    = "Please enter last name."
    static let enterPhoneNumber                 = "Please enter your valid phone number."
    static let enterConfirmPassword             = "Please enter confirm password."
    static let passwordMatch                    = "Password and confirm password doesn't match."
    static let selectVerification               = "Please select verification type."
    static let enterPassportDetails             = "Please enter passport no."
    static let enterDrivingDetails              = "Please enter driving license no."
    static let selectPassportCopy               = "Please select a copy of passport."
    static let selectFrontCopyOfLicense         = "Please select front copy of license."
    static let selectBackCopyOfLicense          = "Please select back copy of license."
    static let enterAddress                     = "Please enter address."
    static let selectCity                       = "Please select city."
    static let selectState                      = "Please select state."
    static let selectCountry                    = "Please select country."
    static let enterOTP                         = "Please enter OTP."
    static let enterValidOTP                    = "Please enter valid OTP."
    static let enterBankIBAN                    = "Please enter bank IBAN."
//    static let selectBankName                   = "Please enter bank name."
    static let selectBankName                    = "Please select bank name."
    static let enterAccountNumber               = "Please enter account/mobile no."
   // static let enterAccountNumber               = "Please enter account number."
    static let enterBic                         = "Please enter BIC."
    static let enterBeneficiaryName             = "Please enter name."
//    static let enterBeneficiaryName             = "Please enter beneficiary name."

    static let enterBeneficiaryEmail            = "Please enter email."
    static let enterBeneficiaryValidEmail       = "Please enter valid email."
    static let enterBeneficiaryPhoneNumber      = "Please enter valid phone number."
    static let enterName                        = "Please enter name."
    static let enterZipcode                     = "Please enter zip code."
    static let enterSubject                     = "Please enter subject."
    static let enterComment                     = "Please enter comment."
    static let selectDialCode                   = "Please select dial code."
    static let enterSwiftCode                   = "Please enter swift code."
    static let enterDescription                 = "Please enter description."
    static let selectToCountry = "Please select country where you would like to send money."
    static let verified_document = "Your document has not been verified yet. Please contact site administrator."
    static let selectNationalityCountry =   "Please select document issuing country."
    static let selectSendingReason      =   "Please select reason for send."
    static let selfieVerify             =   "Your selfie is not verified yet, Please contact to site administrator."

}

fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l <= r
    default:
        return !(rhs < lhs)
    }
}


class ValidationClass: NSObject {
    
    //MARK: - Reset password form validation code below -
    
    func resetPasswordForm(_ obj: ResetPasswordView) -> Bool {
        if obj.newpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterNewPassword)
            return false
        }
        else if validate(password: obj.newpassword) == false{
            makeToast(Messages.enterValidPassword)
            return false
        }
        else if obj.confirmpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterConfirmPassword)
            return false
        } else if obj.newpassword != obj.confirmpassword {
            makeToast(Messages.passwordMatch)
            return false
        } else {
            return true
        }
    }
    
    //MARK: - ContactUs form validation code below -
    
    func ContactUsForm( _ obj : ContactUsView)-> Bool {
        if obj.subject.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterSubject)
            return false
        }
        else if obj.comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            makeToast(Messages.enterComment)
            return false
        }
        else{
            return true
        }
    }
    
    //MARK: - Forgot password form validation code below -
    
    func ForgotPasswordForm( _ obj : ForgotPasswordView)-> Bool {
        if obj.email.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterEmail)
            return false
        }else if isValidEmail(obj.email) {
            makeToast(Messages.enterValidEmail)
            return false
        } else{
            return true
        }
    }
    
    //MARK: - Update profile form validation code below -
    
    func updatedProfileForm(_ obj: ProfileView) -> Bool {
        if obj.first_name.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterFirstName)
            return false
        }
        if obj.last_name.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterLastName)
            return false
        }
        else if obj.email.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterEmail)
            return false
        }
        
        else if isValidEmail(obj.email) {
            makeToast(Messages.enterValidEmail)
            return false
        }
       
        else if obj.dial_code.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.selectDialCode)
            return false
        }
        else if obj.phone_number.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterPhoneNumber)
            return false
        }
        else if obj.address.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterAddress)
            return false
        }
        else if obj.selectedCountry.id.isEmpty {
            makeToast(Messages.selectCountry)
            return false
        }
        else if obj.selectedNationalityCountry.id.isEmpty {
            makeToast(Messages.selectNationalityCountry)
            return false
        }
        else if obj.selectedState.id.isEmpty {
            makeToast(Messages.selectState)
            return false
        }
        else if obj.selectedCity.id.isEmpty {
            makeToast(Messages.selectCity)
            return false
        }
        

        else {
           return true
        }
    }
    
    //MARK: - Update beneficiary form validation code below -
    
    func updateBeneficiaryForm(_ obj: EditBeneficiaryView) -> Bool {
        
        if obj.name.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterBeneficiaryName)
            return false
        }
        else if obj.email.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterBeneficiaryEmail)
            return false
        }
        else if isValidEmail(obj.email) {
            makeToast(Messages.enterBeneficiaryValidEmail)
            return false
        }
        else if obj.dial_code.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.selectDialCode)
            return false
        }
        else if obj.phone_number.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterBeneficiaryPhoneNumber)
            return false
        }
        else if obj.address.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterAddress)
            return false
        }
        else if obj.selectedCountry.id.isEmpty {
            makeToast(Messages.selectCountry)
            return false
        }
        else if obj.selectedState.id.isEmpty {
            makeToast(Messages.selectState)
            return false
        }
        else if obj.selectedCity.id.isEmpty {
            makeToast(Messages.selectCity)
            return false
        }
        else if obj.zip_code.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterZipcode)
            return false
        }
//        else if obj.iban_code.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.enterBankIBAN)
//            return false
//        }
        
        else if obj.selectedBank.id.isEmpty {
            makeToast(Messages.selectBankName)
            return false
        }
//        else if obj.bank_name.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.selectBankName)
//            return false
//        }
        else if obj.account_number.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterAccountNumber)
            return false
        }
//        else if obj.bic_code.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.enterBic)
//            return false
//        }
//        else if obj.swift_code.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.enterSwiftCode)
//            return false
//        }
        else {
           return true
        }
    }
    
    //MARK: - Change password form validation code below -

    func changePasswordForm(_ obj: ChangePasswordView) -> Bool {
        
        if obj.oldpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterOldPassword)
            return false
        } else if obj.newpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterNewPassword)
            return false
        }
        else if validate(password: obj.newpassword) == false{
            makeToast(Messages.enterValidPassword)
            return false
        }
        else if obj.confirmpassword.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterConfirmPassword)
            return false
        } else if obj.newpassword != obj.confirmpassword {
            makeToast(Messages.passwordMatch)
            return false
            
        } else {
            return true
        }
    }
    
    //MARK: - Add beneficiary form validation code below -

    
    func addBeneficiaryForm(_ obj: AddBeneficiaryView) -> Bool {
        if obj.name.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterBeneficiaryName)
            return false
        }
        else if obj.email.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterBeneficiaryEmail)
            return false
        }
        else if isValidEmail(obj.email) {
            makeToast(Messages.enterBeneficiaryValidEmail)
            return false
        }
        else if obj.dial_code.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.selectDialCode)
            return false
        }
        else if obj.phone_number.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterBeneficiaryPhoneNumber)
            return false
        }
        else if obj.address.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterAddress)
            return false
        }
        else if obj.selectedCountry.id.isEmpty {
            makeToast(Messages.selectCountry)
            return false
        }
        else if obj.selectedState.id.isEmpty {
            makeToast(Messages.selectState)
            return false
        }
        else if obj.selectedCity.id.isEmpty {
            makeToast(Messages.selectCity)
            return false
        }
        else if obj.zip_code.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterZipcode)
            return false
        }
//       else if obj.iban_code.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.enterBankIBAN)
//            return false
//        }
        else if obj.selectedBank.id.isEmpty {
            makeToast(Messages.selectBankName)
            return false
        }
//        else if obj.bank_name.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.selectBankName)
//            return false
//        }
        else if obj.account_number.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterAccountNumber)
            return false
        }
//        else if obj.bic_code.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.enterBic)
//            return false
//        }
//        else if obj.swift_code.trimmingCharacters(in: .whitespaces).isEmpty {
//            makeToast(Messages.enterSwiftCode)
//            return false
//        }
        else {
           return true
        }
    }
    
    //MARK: - User register form validation code below -

    
    func registerForm(_ obj : RegisterView)-> Bool {
        if obj.first_name.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterFirstName)
            return false
        }
        if obj.last_name.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterLastName)
            return false
        }
        else if obj.email.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterEmail)
            return false
        }
        else if isValidEmail(obj.email) {
            makeToast(Messages.enterValidEmail)
            return false
        }
        else if obj.dial_code.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.selectDialCode)
            return false
        }
        else if obj.phone.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterPhoneNumber)
            return false
        }
        
        else if obj.password.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterPassword)
            return false
        }
        else if validate(password: obj.password) == false{
            makeToast(Messages.enterValidPassword)
            return false
        }
        else if obj.confirm_password.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterConfirmPassword)
            return false
        }
        else if obj.password != obj.confirm_password {
            makeToast(Messages.passwordMatch)
            return false
        }
        
        else if obj.selectedCountry.id.isEmpty {
            makeToast(Messages.selectCountry)
            return false
        }
        else if obj.selectedNationalityCountry.id.isEmpty {
            makeToast(Messages.selectNationalityCountry)
            return false
        }
        else if obj.selectedState.id.isEmpty {
            makeToast(Messages.selectState)
            return false
        }
        else if obj.selectedCity.id.isEmpty {
            makeToast(Messages.selectCity)
            return false
        }
        else if obj.address.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterAddress)
            return false
        }
        else {
            return true
        }
    }
    
    //MARK: - User login form validation code below -
    
    func loginForm(email: String,password : String)-> Bool {
        if email.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterEmail)
            return false
        }else if isValidEmail(email) {
            makeToast(Messages.enterValidEmail)
            return false
        }else if password.trimmingCharacters(in: .whitespaces).isEmpty {
            makeToast(Messages.enterPassword)
            return false
        }else{
            return true
        }
    }

    //MARK: - URL check valid or not valid code below -

    func validateUrl (_ stringURL : NSString) -> Bool {
        let urlRegEx = "((https|http)://)((\\w|-)+)(([.]|[/])((\\w|-)+))+"
        let predicate = NSPredicate(format:"SELF MATCHES %@", argumentArray:[urlRegEx])
        //let urlTest = NSPredicate.predicateWithSubstitutionVariables(predicate)
        return predicate.evaluate(with: stringURL)
    }
    
 
    func isImageViewBlank(_ imageView:UIImageView)-> Bool{
        
        if imageView.image == UIImage(named: "camera") ||  imageView.image == UIImage(named: "white-logo") || imageView.image == nil {
            return true
        }
        return false
    }
    
    //MARK: - Email valid or not vaild code below -

    func isValidEmail(_ EmailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let range = EmailStr.range(of: emailRegEx, options:.regularExpression)
        let result = range != nil ? true : false
        return !result
    }
    
    //MARK: - Phone number valid or not vaild code below -

    func isValidPhoneNumber(_ PhoneStr:String) -> Bool {
        let phoneRegEx = "[0-9]{10}"
        let range = PhoneStr.range(of: phoneRegEx, options: .regularExpression)
        let result = range != nil ? true : false
        return !result
    }
    
    //MARK: - Password valid or not vaild code below -
    
    func validate(password: String) -> Bool  {
        // let regularExpression = "^(?=.*[0-9])" + "(?=.[a-z])(?=.[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$"
        let regularExpression = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,}"
        
//        let regularExpression = "^(?=.*[a-z])(?=.*\\d)(?=.*[$@#$!%*?&])[A-Za-z\\d$#@$!%*?&]{8,}"
        
        let passwordValidation = NSPredicate.init(format: "SELF MATCHES %@", regularExpression)
        return passwordValidation.evaluate(with: password)
    }
      
}


extension String {
    
    var isPhoneNumber: Bool {
        do {
            let detector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.phoneNumber.rawValue)
            let matches = detector.matches(in: self, options: [], range: NSMakeRange(0, self.count))
            if let res = matches.first {
                return res.resultType == .phoneNumber && res.range.location == 0 && res.range.length == self.count && self.count == 10
            } else {
                return false
            }
        } catch {
            return false
        }
    }
}

