//
//  OTPViewVPM.swift
//  Moneydrop
//
//  Created by Gipl on 20/12/22.
//

import SwiftUI


struct OTPViewVPM: UIViewRepresentable {
    
    @Binding var otp: String
    
     var clearTextFiled: Bool = false
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> VPMOTPView {
        let otpview = VPMOTPView(frame: CGRect(x: 0, y: 0, width: 200, height: 60))
        otpview.otpFieldsCount = 4
        otpview.initializeUI()
        otpview.delegate = context.coordinator
        return otpview
    }
    
    func updateUIView(_ uiView: VPMOTPView, context: Context) {
        
        if clearTextFiled {
            uiView.clearAllTextField()
        }
    }
    
    typealias UIViewType = VPMOTPView
    
    class Coordinator: VPMOTPViewDelegate {
        
        var parent: OTPViewVPM
       
        
        init(_ parent: OTPViewVPM) {
            self.parent = parent
        }
        
        func shouldBecomeFirstResponderForOTP(_ View: VPMOTPView, otpFieldIndex index: Int) -> Bool {
            return true
        }
        
        func enteredOTP(_ View: VPMOTPView, otpString: String) {
            
        }
        
        func hasEnteredAllOTP(hasEntered: Bool) -> Bool {
            print("Has entered all OTP?"+" \(hasEntered)")
            return true
        }
        
        func didChangeOTP(otpString: String) {
            parent.otp = otpString
        }
    }
    
}

struct OTPViewVPM_Previews: PreviewProvider {
    static var previews: some View {
        OTPViewVPM(otp: .constant(""))
    }
}
