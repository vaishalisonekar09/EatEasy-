//
//  NumberTextFieldView.swift
//  Moneydrop
//
//  Created by Gipl on 12/12/22.
//

import SwiftUI

struct NumberTextFieldView: View {
    
    var title                   =   ""
    var placeholder             =   ""
    @Binding var dial_code      :   String
    @Binding var text           :   String
    var fontSize                :   CGFloat = 14.0
    var star                    =   false
    @State var countryFlag      =   ""
    @State private var showCountryPicker = false
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 15) {
            
            HStack(spacing:0) {
                Text(title)
                if star {
                    Text("*").foregroundColor(Color.redColor)
                }
            }
            .customFont(.semibold, fontSize)
            
            HStack(spacing: 15) {
                Button {
                    showCountryPicker.toggle()
                } label: {
                    HStack(spacing: 0) {
                        TextField("+91", text: $dial_code)
                            .customFont(.regular, 14)
                            .multilineTextAlignment(.leading)
                            .disabled(true)
                        Image("down-arrow").renderingMode(.template)
                     }
                    .frame(width: 60, alignment: .leading)
                }
                .overlay(
                    Rectangle().fill(Color.greenColor).frame(height: 1)
                        .frame(maxWidth: .infinity).offset(y:7)
                    , alignment: .bottomLeading
                )
                .fullScreenCover(isPresented: $showCountryPicker) {
                    CountryPickerView(dial_code: $dial_code, countryFlag: $countryFlag)
                }
                
                 ZStack(alignment: .leading) {
                    if text.isEmpty {
                        Text(placeholder)
                      }
                     TextField("", text: $text)
                }
                 .frame(maxWidth: .infinity)
                 .keyboardType(.numberPad)
                
                .overlay(
                    Rectangle().fill(Color.greenColor).frame(height: 1)
                            .frame(maxWidth: .infinity).offset(y:7)
                    ,alignment: .bottomLeading
                )
             }
         }
        .customFont(.regular, 15)
         .multilineTextAlignment(.leading)
        .frame(height: 75, alignment: .leading)
        .foregroundColor(Color.blackTxtColor)
    }
}
 
struct NumberTextFieldViewWithLabel: View {
    
    var title                   =   ""
    var placeholder             =   ""
    @Binding var dial_code      :   String
    @Binding var text           :   String
    var fontSize                :   CGFloat = 14.0
    var star                    =   false
    @State var countryFlag      =   ""
    @State private var showCountryPicker = false
    @Binding var errorMsg           :   String

    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            HStack(spacing:0) {
                
                Text(title)
                if star {
                    Text("*").foregroundColor(Color.redColor)
                }
            }
            .customFont(.semibold, fontSize)
            
            HStack(spacing: 15) {
                Button {
                    showCountryPicker.toggle()
                } label: {
                    HStack(spacing: 0) {
                        TextField("+91", text: $dial_code)
                            .customFont(.regular, 14)
                            .multilineTextAlignment(.leading)
                            .disabled(true)
                        Image("down-arrow").renderingMode(.template)
                     }
                    .frame(width: 60, alignment: .leading)
                }
                .overlay(
                    Rectangle().fill(errorMsg != "" ? Color.redColor : Color.greenColor).frame(height: 1)
                        .frame(maxWidth: .infinity).offset(y:7)
                    , alignment: .bottomLeading
                )
                .fullScreenCover(isPresented: $showCountryPicker) {
                    CountryPickerView(dial_code: $dial_code, countryFlag: $countryFlag)
                }
                
                 ZStack(alignment: .leading) {
                    if text.isEmpty {
                        Text(placeholder)
                      }
                     TextField("", text: $text)
                }
                 .frame(maxWidth: .infinity)
                 .keyboardType(.numberPad)
                
                .overlay(
                    Rectangle().fill(errorMsg != "" ? Color.redColor : Color.greenColor).frame(height: 1)
                            .frame(maxWidth: .infinity).offset(y:7)
                    ,alignment: .bottomLeading
                )
             }
            
            if errorMsg != "" {
                Text(errorMsg)
                    .customFont(.regular, 13)
                    .foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
                    
            }
         }
        .customFont(.regular, 15)
         .multilineTextAlignment(.leading)
        .frame(height: 80, alignment: .leading)
        .foregroundColor(Color.blackTxtColor)
    }
}
 
