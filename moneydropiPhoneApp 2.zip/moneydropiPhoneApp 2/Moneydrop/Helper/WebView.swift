//
//  WebView.swift
//  Moneydrop
//
//  Created by Gipl on 05/01/23.
//
import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    
    let text: String
    @Binding var dynamicHeight: CGFloat

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.bounces = false
        webView.navigationDelegate = context.coordinator
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        var html = """
        <!doctype html>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <html>
            <head>
            <link href='https://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>
                <style>
                    body {
                       font-family: "Open Sans"
                    }
                </style>
            </head>
            <body>
        """
        html += text
        html.append("</body></html>")
        uiView.loadHTMLString(html, baseURL: nil)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        var parent: WebView
        init(_ parent: WebView) {
            self.parent = parent
        }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.documentElement.scrollHeight", completionHandler: { (height, error) in
                DispatchQueue.main.async {
                    self.parent.dynamicHeight = height as! CGFloat
                }
            })
        }
    }
}


