//
//  CustomTextField.swift
//  Moneydrop
//
//  Created by Gipl on 08/12/22.
//

import SwiftUI
import Combine

struct CustomTextField: View {
    
    var title               =   ""
    var placeholder         =   ""
    @Binding var text       :   String
    var fontSize            :   CGFloat = 14.0
    var keyboard            =   UIKeyboardType.default
    var star                =   false
    var isSecure            =   false
    var disabled            =   false
    var rightImage          =   ""
    var rightViewClick      :   () -> () = {}
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 15) {
            
            HStack(spacing:0) {
                Text(title)
                if star {
                    Text("*").foregroundColor(Color.redColor)
                }
            }
             .customFont(.semibold, fontSize)

            ZStack(alignment: .leading) {
                if text.isEmpty {
                    Text(placeholder)
                   }
                
                HStack {
                    if isSecure {
                        SecureField("", text: $text)
                    } else {
                        TextField("", text: $text)
                    }
                    
                    if rightImage != "" {
                        Button {
                            rightViewClick()
                        } label: {
                            Image(rightImage)
                        }.disabled(disabled)
                    }
                }
               // .frame(height: 20)
            }
            .frame(height: 20)
            .overlay(
                Rectangle().fill(Color.greenColor).frame(height: 1)
                        .frame(maxWidth: .infinity).offset(y:7)
                ,alignment: .bottomLeading
            )
        }
        .multilineTextAlignment(.leading)
        .customFont(.regular, 15)
        .frame(height: 75)
        .frame(maxWidth: .infinity)
        .keyboardType(keyboard)
        .foregroundColor(Color.blackTxtColor)
     }
}

struct CustomTextFieldWithLabel: View {
    
    var title               =   ""
    var placeholder         =   ""
    @Binding var text       :   String
    var fontSize            :   CGFloat = 14.0
    var keyboard            =   UIKeyboardType.default
    var star                =   false
    var isSecure            =   false
    var disabled            =   false
  // var rightImage          =   ""
    var rightViewClick      :   () -> () = {}
    @State private var editingChanged = false
    @Binding var errorMsg : String
    var rightView: AnyView?

    var body: some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            HStack(spacing:0) {
                Text(title)
                if star {
                    Text("*").foregroundColor(Color.redColor)
                }
            }
             .customFont(.semibold, fontSize)

            ZStack(alignment: .leading) {
                if text.isEmpty {
                    Text(placeholder)
                   }
                
                HStack {
                    if isSecure {
                        SecureField("", text: $text)
                    } else {
                        TextField("", text: $text) { editingChanged in
                            withAnimation {
                                print(editingChanged)
                                self.editingChanged = editingChanged
                                print(self.editingChanged)
                            }
                        }
                    }
                    if let rightView = self.rightView {
                        rightView
                    }
                 
                }
               // .frame(height: 20)
            }
            .frame(height: 20)
            .overlay(
                Rectangle().fill(errorMsg != "" ? Color.red : Color.greenColor).frame(height: 1)
                        .frame(maxWidth: .infinity).offset(y:7)
                ,alignment: .bottomLeading
            )
            
            if errorMsg != "" {
                Text(errorMsg)
                    .customFont(.regular, 13)
                    .foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
                    
            }
            
        }
        .multilineTextAlignment(.leading)
        .customFont(.regular, 15)
        .frame(height: 80)
        .frame(maxWidth: .infinity)
        .keyboardType(keyboard)
        .foregroundColor(Color.blackTxtColor)
     }
}
 

struct BorderTextFieldWithLabel: View {
    
    var title               =   ""
    var placeholder         =   ""
    @Binding var text       :   String
    var fontSize            :   CGFloat = 14.0
    var keyboard            =   UIKeyboardType.default
    var star                =   false
    var isSecure            =   false
    var disabled            =   false
  // var rightImage          =   ""
    var rightViewClick      :   () -> () = {}
    @State private var editingChanged = false
    @Binding var errorMsg : String
    @State private var is_error1 = false
    @Binding var is_error: Bool

    var rightView: AnyView?

    var body: some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            HStack(spacing:0) {
                Text(title)
                if star {
                    Text("*").foregroundColor(Color.redColor)
                }
            }
             .customFont(.semibold, fontSize)

            ZStack(alignment: .leading) {
                if text.isEmpty {
                    Text(placeholder)
                   }
                
                HStack {
                    if isSecure {
                        SecureField("", text: $text)
                    } else {
                        TextField("", text: $text) { editingChanged in
                            withAnimation {
                                print(editingChanged)
                                self.editingChanged = editingChanged
                                print(self.editingChanged)
                            }
                        }
                    }
                    if let rightView = self.rightView {
                        rightView
                    }
                 
                }
               // .frame(height: 20)
            }
            .frame(height: 20)
            .overlay(
                Rectangle().fill(errorMsg != "" ? Color.red : Color.greenColor).frame(height: 1)
                        .frame(maxWidth: .infinity).offset(y:7)
                ,alignment: .bottomLeading
            )
            if errorMsg != "" && is_error || is_error1 {
                Text(errorMsg)
                    .customFont(.regular, 13)
                    .foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
                    
            }
            
        }
        .multilineTextAlignment(.leading)
        .customFont(.regular, 15)
        .frame(height: 80)
        .frame(maxWidth: .infinity)
        .keyboardType(keyboard)
        .foregroundColor(Color.blackTxtColor)
     }
}
 

