//
//  PaymentCardView.swift
//  Moneydrop
//
//  Created by Gipl on 16/02/23.
//

import SwiftUI
import StripePaymentsUI

struct PaymentCardView: UIViewRepresentable {
    
    @Binding var cardNumber: String
    @Binding var expirationMonth: Int
    @Binding var expirationYear: Int
    @Binding var cvc: String
    let paymentCard = STPPaymentCardTextField()
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }
    
    func makeUIView(context: Context) -> some UIView {
        paymentCard.delegate = context.coordinator
        paymentCard.isUserInteractionEnabled = false
        return paymentCard
    }
    
    
    func updateUIView(_ uiView: UIViewType, context: Context) {
        
    }
    
    class Coordinator: NSObject, STPPaymentCardTextFieldDelegate {
        
        var paymentCard: PaymentCardView
        
        init(_ paymentCard: PaymentCardView) {
            self.paymentCard = paymentCard
        }
        
        func paymentCardTextFieldDidChange(_ textField: STPPaymentCardTextField) {
            
            paymentCard.cardNumber = textField.cardNumber ?? ""
            paymentCard.expirationMonth = textField.expirationMonth
            paymentCard.expirationYear = textField.expirationYear
            paymentCard.cvc = textField.cvc ?? ""
            
        }
        
    }
}

 
