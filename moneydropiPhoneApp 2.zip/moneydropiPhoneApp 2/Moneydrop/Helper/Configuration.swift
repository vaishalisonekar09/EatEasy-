
import SwiftUI

fileprivate enum Configuration {
    
    enum Error: Swift.Error {
        case missingKey, invalidValue
    }
    
    static func value<T>(for key: String) throws -> T where T: LosslessStringConvertible {
        
        guard let object = Bundle.main.object(forInfoDictionaryKey:key) else {
            throw Error.missingKey
        }
        
        switch object {
        case let value as T:
            return value
        case let string as String:
            guard let value = T(string) else { fallthrough }
            return value
        default:
            throw Error.invalidValue
        }
    }
}

class Config {
    
    //MARK: - App mode select -
    
    static let appmode  :  APPMODE = .demo
    
    static var API_URL  : String {
        
        switch Config.appmode {
        case .live :
            return "https://moneydrop.au/api/index"
        case .dev :
            return  "http://moneydrop.dev3.gipl.inet/api/index"
        case .qa    :
            return  "https://moneydrop.stage3.demo321.com/qa/api/index"
        case .demo  :
            return  "https://moneydrop.stage3.demo321.com/api/index"
        case .client :
            return ""
        default:
            return ""
        }
    }
    
    static let shared                   = Config()
    static let APP_NAME                 = "MONEY DROP"
    static let APP_ID                   = "id6449743563"
    
    static let DMY_DATE_FORMATE         = "dd-MM-yyyy"
    static let YMD_DATE_FORMATE         = "yyyy-MM-dd"
    static let YMD_DATE_FORMATE1        = "MMM d, yyyy"
    static let DMY_DATE_FORMATE2        = "dd/MM/yyyy"
    
    
    let dateFormat1                     = "yyyy/MM/dd"
    let dateFormat                      = "dd-MM-yyyy"
    let yearFormat                      = "MMM yyyy"
    let dateTimeFormat                  = "MMM d yyyy, h:mm a"
    
    static var ISO_FORMATE              = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
    static var ISO_FORMATE1             = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    
    static var currency                 : String { "AUD" }
    static var PAGE_LIMIT               = 10
    static let dateTimeFormat           = "yyyy-MM-dd hh:mm a"
    
    //MARK: - Stripe Publish/Secret key -
    
    static var stripePublishableKey     : String {
//        return "pk_live_51MZWR5Adhtl7XRpPO5GECpuAyXlEXL2nxxpve6LtQq9A4vJBgAebtrBLbWZkj6pCyIk8kZr7BkkE62c8n9gw6OqH000KSN5WcM"
        if appmode == .live {
            return "pk_live_51MZWR5Adhtl7XRpPO5GECpuAyXlEXL2nxxpve6LtQq9A4vJBgAebtrBLbWZkj6pCyIk8kZr7BkkE62c8n9gw6OqH000KSN5WcM"
        } else {
            return "pk_test_51MZWR5Adhtl7XRpPWGT0xxHbe4qPteGwB3qYUE4z3sTKvA990wFmxe4mXO5Xyadt9pSRghST7Xs3XPcWKDDo1UMX00wDKApxi8"
        }
    }
    static var stripeSecretKey          : String {
//        return "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"
        if appmode == .live {
            return "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"
        } else {
            return "sk_test_51MdVDhSEF8eZO8yzluyfyMHw7lnfrYP1cdnjrTq2W4s6wIHDM4z3FC7gZAbfBi0OoAAO2bTWkzy8zc9RvY54XbUu001m34lNAD"
        }
    }
    
}


enum APPMODE {
    case dev
    case qa
    case demo
    case client
    case live
}
