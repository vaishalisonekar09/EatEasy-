//
//  PagerView.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI

struct PagerView<Content: View>: View {
    
    let pageCount               : Int
    @Binding var currentIndex   : Int
    let content                 : Content
    init(pageCount: Int, currentIndex: Binding<Int>, @ViewBuilder content: () -> Content) {
        self.pageCount      =   pageCount
        self._currentIndex  =   currentIndex
        self.content        =   content()
    }
    
    @GestureState private var translation: CGFloat = 0
    
    var body: some View {
        
        ZStack (alignment: .top){
            
            GeometryReader { geometry in
                
                HStack(alignment: .top, spacing: 0) {
                    self.content
                        .frame(width: geometry.size.width).clipped()
                }
                .padding(.top)
                .frame(width: geometry.size.width, alignment: .topLeading)
                .frame(maxHeight: .infinity, alignment: .topLeading)
                .offset(x: -CGFloat(self.currentIndex) * geometry.size.width)
                .offset(x: self.translation)
                .animation(.interactiveSpring())
                
                .gesture(
                    DragGesture().updating(self.$translation) { value, state, _ in
                        state = value.translation.width
                    }.onEnded { value in
                        let offset = value.translation.width / geometry.size.width
                        let newIndex = (CGFloat(self.currentIndex) - offset).rounded()
                        self.currentIndex = min(max(Int(newIndex), 0), self.pageCount - 1)
                    }
                )
                
                .overlay(
                    
                    HStack(spacing: 5) {
                        
                        ForEach(0..<pageCount, id: \.self) { i in
                            Image(systemName: "circle.fill")
                                .customFont(.medium, 13)
                                .foregroundColor(currentIndex == i ? .yellowColor  : .white)
                                .onTapGesture {
                                    currentIndex = i
                                }
                        }
                    }
                        .frame(maxWidth: .infinity, alignment: .bottomLeading)
                        .frame(maxHeight: .infinity, alignment: .bottomLeading)
                         .padding(.horizontal, 20)
                         .padding(.bottom, 25)
                    , alignment: .bottomLeading
                )
            }
            .clipped()
        }
    }
}
