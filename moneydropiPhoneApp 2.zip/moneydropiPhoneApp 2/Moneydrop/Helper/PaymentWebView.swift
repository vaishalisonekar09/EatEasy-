//
//  PaymentWebView.swift
//  Moneydrop
//
//  Created by Gipl on 18/01/23.
//

import SwiftUI
import WebKit

struct PaymentWebView: UIViewRepresentable {
    
    @Binding var redirect_url: String
    var completion: ((_ status: String, _ token: String) -> ()) = {_,_  in}
 
    class Coordinator : NSObject, WKNavigationDelegate {
        var completion: ((_ status: String, _ token: String) -> ()) = {_,_  in}

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            
            if let get_url = navigationAction.request.url?.absoluteString {
                
                if get_url.contains("CancelTransaction") {
                    completion("Cancel transaction", "")
                } else if get_url.contains("failed-payment") {
                    completion("Failed transaction", "")
                }
                else if get_url.contains("success-payment/1?") {
                    var parameters: [String: String] = [:]
                    URLComponents(url: URL(string: get_url)!, resolvingAgainstBaseURL: false)?.queryItems?.forEach {
                        parameters[$0.name] = $0.value
                    }
                    completion("Success transaction", parameters["token"] ?? "")
                }
//               else if get_url.contains("success") {
//                   var parameters: [String: String] = [:]
//                   URLComponents(url: URL(string: get_url)!, resolvingAgainstBaseURL: false)?.queryItems?.forEach {
//                       parameters[$0.name] = $0.value
//                   }
//                   completion("Success transaction", parameters["token"] ?? "")
//               }
                print(navigationAction.request.url?.absoluteString)
            }
            decisionHandler(.allow)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
    
  func makeUIView(context: Context) -> WKWebView {
    return WKWebView()
  }
   
  func updateUIView(_ uiView: WKWebView, context: Context) {
    uiView.navigationDelegate = context.coordinator
    context.coordinator.completion = completion
      if let url = URL(string: redirect_url) {
          uiView.load(URLRequest(url: url))
      } else {
          makeToast("Invalid URL")
      }
  }
}



public extension URL {
    
    /// Quick way to obtain query parameter from URL.
    ///
    /// - Parameter tap_queryParameter: Query parameter.
    subscript(tap_queryParameter: String) -> String? {
        
        guard let queryParameters = URLComponents(string: self.absoluteString), let queryItems = queryParameters.queryItems else { return nil }
        guard let queryItem = queryItems.first(where: { $0.name == tap_queryParameter }) else { return nil }
        
        return queryItem.value
    }
    
}
