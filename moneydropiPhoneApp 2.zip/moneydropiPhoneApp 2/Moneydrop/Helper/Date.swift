//
//  Date.swift
//  Moneydrop
//
//  Created by Gipl on 04/01/23.
//

import SwiftUI

extension Date {
    func getDate() -> String {
         let formatter = DateFormatter()
         formatter.dateFormat = Config.DMY_DATE_FORMATE
         let str = formatter.string(from: self)
         return str
     }
     
     func getDate1() -> String {
         let formatter = DateFormatter()
         formatter.dateFormat = Config.DMY_DATE_FORMATE2

         let str = formatter.string(from: self)
         return str
     }
    
}

extension DateFormatter {
    static var gmt: DateFormatter {
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(secondsFromGMT: 3600 * 3)
        return formatter
    }
}

extension String {
    
    func getDate1() -> Date {
        
        let formatter = DateFormatter()
        formatter.dateFormat = Config.DMY_DATE_FORMATE2
        let date = formatter.date(from: self) ?? Date()
        return date
    }
    
    func getDate() -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = Config.DMY_DATE_FORMATE
        let date = formatter.date(from: self) ?? Date()
        return date
    }
    
   //MARK: - This function is used to change date format -
    
    func convertFromISOFormat(_ format: String = Config.YMD_DATE_FORMATE1) -> String {
        if self == "" {
            return ""
        } else {
            let dateFormatterGet = DateFormatter()
            dateFormatterGet.dateFormat = Config.ISO_FORMATE1
            let dateFormatter = DateFormatter()
            dateFormatter.timeStyle = .none
            dateFormatter.dateFormat = format
            let dateObj: Date? = dateFormatterGet.date(from: self)
            
            return dateFormatter.string(from: dateObj!)
        }
    }
}


extension Int {
    func dateFromMilliseconds() -> Date {
        return Date(timeIntervalSince1970: TimeInterval(self)/1000)
    }
}

extension Double {
    
    func getDateStringFromUTC() -> String {
        let date = Date(timeIntervalSince1970: self)
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US")
        dateFormatter.dateStyle = .medium
        return dateFormatter.string(from: date)
    }
    
    func getDateAndTime() -> String {
        let date = Date(timeIntervalSince1970: self)
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US") //en_AU
       // dateFormatter.timeZone = TimeZone(abbreviation: "Australia/Sydney")
        dateFormatter.amSymbol = "AM"
        dateFormatter.pmSymbol = "PM"
        dateFormatter.dateFormat = "dd/MM/yyyy h:mm a"
        return dateFormatter.string(from: date)
    }
    
}

extension Date {

    func get(_ components: Calendar.Component..., calendar: Calendar = Calendar.current) -> DateComponents {
        return calendar.dateComponents(Set(components), from: self)
    }
    func get(_ component: Calendar.Component, calendar: Calendar = Calendar.current) -> Int {
        return calendar.component(component, from: self)
    }
}
