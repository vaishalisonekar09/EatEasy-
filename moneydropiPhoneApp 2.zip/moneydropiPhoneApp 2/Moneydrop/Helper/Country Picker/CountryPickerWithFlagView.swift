//
//  CountryPickerWithFlagView.swift
//  Moneydrop
//
//  Created by Gipl on 02/01/23.
//

import SwiftUI
import SDWebImageSwiftUI

struct CountryPickerWithFlagView: View {
    
    @Binding var currency               : String
    @Binding var selectedCountryFlag    : String
    @Binding var country_id             : String
    var from_country                    : Bool
    
    var callback                        : () -> () = {}
    
    @State var flag_folder_path         = ""
    
    @Environment(\.presentationMode) var presentation
    
    @State private var flagDataShow     = [JSON]()
    @State private var filter_countries = [JSON]()
    @State private var search_text      = ""
    
    var body: some View {
        
        VStack(spacing:0) {
            
            HStack {
                Button {
                    presentation.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
            }
            .frame(height: 44)
            .padding(.horizontal)
            .overlay(
                Text("Countries".uppercased()).customFont(.headingBrandon, 20)
            )
            
            Divider()
            
            TextField("Search", text: $search_text)
                .frame(height: 44)
                .overlay(
                    Button(action: {
                        if !search_text.isEmpty {
                            self.search_text = ""
                        }
                    }, label: {
                        Image(systemName: "xmark")
                            .foregroundColor(!search_text.isEmpty ? Color.black : Color.white)
                            .font(.subheadline)
                    })
                    , alignment: .trailing
                )
                .padding(.horizontal)
                .onChange(of: search_text) {  newValue in
                    doSearch()
                }
            
            Divider()
            
            List{
                
                ForEach(0..<filter_countries.count, id: \.self) { i in
                    Button {
                        currency = filter_countries[i].currency
                        country_id = filter_countries[i].id
                        selectedCountryFlag = flag_folder_path+filter_countries[i].flag_name
                        callback()
                        presentation.wrappedValue.dismiss()
                    } label: {
                        HStack(spacing: 8) {
                            WebImage(url: URL(string: flag_folder_path+filter_countries[i].flag_name))
                                .placeholder{
                                    Image("no_image")
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 35, height: 20)
                                }
                                .resizable()
                                .scaledToFill()
                                .frame(width: 35, height: 20)
                            
                            Text("\(filter_countries[i].country_name)")
                            
                            Text("(\(filter_countries[i].currency))")
                            
                            Spacer(minLength: 0)
                            
                            if country_id ==  filter_countries[i].id {
                                Image(systemName: "checkmark")
                            }
                        }
                    }
                }
                
            }
            .listStyle(.plain)
            
        }
        .customFont(.bold, 15)
        .foregroundColor(Color.black)
        .onAppear{
            flagApicall()
        }
    }
    
    func doSearch() {
        if search_text.isEmpty {
            filter_countries = flagDataShow
        }else {
            filter_countries = flagDataShow.filter {
                $0.id.range(of: search_text.uppercased()) != nil ||  $0.currency.range(of: search_text.uppercased()) != nil
            }
        }
    }
    
    //MARK: - Get Flag api -
    
    func flagApicall() {
        showProgressHUD()
        let parameter = [ApiKey.from_country: from_country] as [String : Any]
        
        DataManager.getApiResponse(parameter, methodName: .currencyListWithFlag) { json, error in
            if apiStatus(json) {
                dismissProgressHUD()
                self.flagDataShow = json["result"].arrayValue
                self.flag_folder_path = json.flag_folder_path
                //print(countries)
                doSearch()
            }
            
        }
    }
    
}

//struct CountryPickerWithFlagView_Previews: PreviewProvider {
//    static var previews: some View {
//        CountryPickerWithFlagView()
//    }
//}
