
import SwiftUI


struct Storage {
    
    @AppStorage("login") static var login                                           =   ""
    @AppStorage("user_type") static var user_type                                   =   ""
    @AppStorage("deviceToken") static var deviceToken                               =   ""
    @AppStorage("boost_type") static var boost_type                                 =   ""
    @AppStorage("slug") static var slug                                             =   ""
    @AppStorage("email") static var email                                           =   ""
    @AppStorage("first_name") static var first_name                                 =   ""
    @AppStorage("last_name") static var last_name                                   =   ""
    @AppStorage("phone_number") static var phone_number                             =   ""
    @AppStorage("image_url") static var image_url                                   =   ""
    @AppStorage("image") static var image                                           =   ""
    @AppStorage("full_name") static var full_name                                   =   ""
    @AppStorage("country") static var country                                       =   ""
    @AppStorage("dial_code") static var dial_code                                   =   "+91"
    @AppStorage("token") static var token                                           =   ""
    @AppStorage("is_screen_lock") static var is_screen_lock                         :   Bool = false
    @AppStorage("is_screen_lock_slug") static var is_screen_lock_slug               =   ""
    @AppStorage("is_document_deleted") static var is_document_deleted               =   0
    @AppStorage("is_document_verify") static var is_document_verify                 =   0
    @AppStorage("is_selfie_verify") static var is_selfie_verify                 =   0
    @AppStorage("my_referrer_code") static var my_referrer_code = ""
    
    
}

//MARK: - Clear save storage data clear -

func clearStorage() {
    Storage.login               =   ""
    Storage.user_type           =   ""
    Storage.image_url           =   ""
    Storage.dial_code           =   ""
    Storage.phone_number        =   ""
    Storage.slug                =   ""
    Storage.country             =   ""
    Storage.token               =   ""
    Storage.full_name           =   ""
    Storage.image               =   ""
    Storage.is_document_deleted =   0
    Storage.is_document_verify  =   0
    Storage.is_selfie_verify    =   0
    Storage.my_referrer_code        =   ""
    
}

//MARK: - User account delete -

func userAccountDelete() {
    Storage.login = ""
    clearStorage()
    Storage.is_screen_lock_slug = ""
    Storage.is_screen_lock = false
    rootView()?.view.window?.rootViewController = UIHostingController(rootView:  LoginView() )
    print("Deleted Account....")
}

//MARK: - Save user data -

func saveStorage(_ user: JSON) {
    Storage.slug                    =     user["slug"].stringValue
    Storage.first_name              =     user["first_name"].stringValue
    Storage.last_name               =     user["last_name"].stringValue
    Storage.full_name               =     user["full_name"].stringValue
    Storage.email                   =     user["email"].stringValue
    Storage.user_type               =     user["user_role_slug"].stringValue
    Storage.image_url               =     user["image_url"].stringValue
    Storage.country                 =     user["country"].stringValue
    Storage.dial_code               =     user["dial_code"].stringValue
    Storage.phone_number            =     user["phone_number"].stringValue
    Storage.token                   =     user["token"].stringValue
    Storage.image                   =     user["image"].stringValue
    Storage.is_document_verify      =     user["is_document_verify"].intValue
    Storage.is_selfie_verify        =     user["is_selfie_verify"].intValue
    Storage.is_document_deleted     =     user["is_document_deleted"].intValue
    Storage.my_referrer_code        =     user["my_referrer_code"].stringValue
    
}


struct ApiKey {
    static let    tid                       =   "tid"
    static let first_name                   =       "first_name"
    static let last_name                    =       "last_name"
    static let email                        =       "email"
    static let dial_code                    =       "dial_code"
    static let phone                        =       "phone"
    static let verification_type            =       "verification_type"
    static let passport_driving_no          =       "passport_driving_no"
    static let country                      =       "country"
    static let state                        =       "state"
    static let city                         =       "city"
    static let address_one                  =       "address_one"
    static let password                     =       "password"
    static let confirm_password             =       "confirm_password"
    static let state_id                     =       "state_id"
    static let country_id                   =       "country_id"
    static let recipient_name               =       "recipient_name"
    static let zip_code                     =       "zip_code"
    static let account_number               =       "account_number"
    static let bank_name                    =       "bank_name"
    static let iban_code                    =       "iban_code"
    static let bic_code                     =       "bic_code"
    static let swift_code                   =       "swift_code"
    static let address                      =       "address"
    static let recipient_user_id            =       "recipient_user_id"
    static var slug                         =       "slug"
    static var cms_slug                     =       "cms_slug"
    static let page_name                    =       "page_name"
    static let validate_string              =       "validate_string"
    static let otp                          =       "otp"
    static let image                        =       "image"
    static let initial_amount               =       "initial_amount"
    static let source_currency              =       "source_currency"
    static let required_currency            =       "required_currency"
    static let transaction_id               =       "transaction_id"
    static let sortBy                       =       "sortBy"
    static let order                        =       "order"
    static let sent_amount                  =       "sent_amount"
    static let sent_currency_code           =       "sent_currency_code"
    static let from_country_code            =       "from_country_code"
    static let received_amount              =       "received_amount"
    static let received_currency_code       =       "received_currency_code"
    static let received_country_code        =       "received_country_code"
    static let recipient_id                 =       "recipient_id"
    static let reason_for_send              =       "reason_for_send"
    static let token                        =       "token"
    static var page                         =       "page"
    static var old_password                 =       "old_password"
    static var new_password                 =       "new_password"
    static let subject                      =       "subject"
    static let mobile                       =       "mobile"
    static let comment                      =       "comment"
    static let stripeToken                  =       "stripeToken"
    static let payment_gateway_type         =       "payment_gateway_type"
    static let description                  =       "description"
    static let receive_currency_code        =       "receive_currency_code"
    static let source_country_id            =       "source_country_id"
    static let received_country_id          =       "received_country_id"
    static let from_country                 =       "from_country"
    static let coupon_code                  =       "coupon_code"
    static let amount_balance               =       "amount_balance"
    static let referral_code                =       "referral_code"
    static let site_transaction_charge_type =       "site_transaction_charge_type"
    static let site_transaction_charge      =       "site_transaction_charge"
    static let site_trans_amount            =       "site_trans_amount"
    static let discounttype                 =       "discounttype"
    static let discount                     =       "discount"
    static let max_discount_allowed         =       "max_discount_allowed"
    static let discounted_amount            =       "discounted_amount"
    static let used_referal_amount          =       "used_referal_amount"
    static let final_amount                 =       "final_amount"
    static let capture_consent              =       "capture_consent"
    static let dob                          =       "dob"
    static let nationality_country          =       "nationality_country"
    static let receive_country_id           =       "receive_country_id"
    static let required_country             =       "required_country"
    
    
    
    
}

extension Notification.Name {
    static let reloadPagerView = Notification.Name("reloadPagerView")
    static let successPayment = Notification.Name("successPayment")
    static let reloadIntrestCollectionView = Notification.Name("reloadIntrestCollectionView")
}
