//
//  ImagePicker.swift
//  Moneydrop
//
//  Created by Gipl on 22/12/22.
//

import SwiftUI
import AVFoundation

struct ImagePicker: UIViewControllerRepresentable {
    
    var sourceType: UIImagePickerController.SourceType = .photoLibrary
    var completion: ((_ image: UIImage) -> ()) = {_  in}
    @State var image: UIImage?
    let controller = UIImagePickerController()

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent : ImagePicker
        init(parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            parent.image = info[.originalImage] as? UIImage
            parent.completion(parent.image ?? UIImage())
            picker.dismiss(animated: true)
         }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }

    func makeUIViewController(context: Context) -> some UIViewController {
        
        controller.allowsEditing = true
        controller.sourceType = sourceType
        controller.delegate = context.coordinator
        
        
        if sourceType == .camera {
            controller.cameraDevice = .front
        }
        return controller
    }

    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }

}
