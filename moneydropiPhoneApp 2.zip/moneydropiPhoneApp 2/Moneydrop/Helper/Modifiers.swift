//
//  Modifiers.swift
//  Moneydrop
//
//  Created by Gipl on 08/12/22.
//

import SwiftUI
import Combine

//MARK: - Yellow Button Modifier -

struct YellowButton: ViewModifier {
    func body(content: Content) -> some View {
        content
            .frame(maxWidth: .infinity)
            .frame(height: 60)
            .background(Color.yellowColor)
            .foregroundColor(.black)
            .cornerRadius(5)
            .customFont(.bold, 16)
    }
}

//MARK: - Shadow Modifier -

struct ShadowModifier: ViewModifier {
    var cornerRadius: CGFloat
    func body(content: Content) -> some View {
        content
            .background(Color.white)
            .cornerRadius(cornerRadius)
            .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}

//MARK: - Gray Shadow Modifier -

struct GrayShadowModifier: ViewModifier {
    var cornerRadius: CGFloat
    func body(content: Content) -> some View {
        content
            .background(Color.white)
            .cornerRadius(cornerRadius)
            .shadow(color: Color.black.opacity(0.3), radius: 5)
    }
}

//MARK: - Corner Radius Modifier -

struct CornerRadiusStyle: ViewModifier {
    var radius: CGFloat
    var corners: UIRectCorner
    struct CornerRadiusShape: Shape {
        var radius = CGFloat.infinity
        var corners = UIRectCorner.allCorners
        func path(in rect: CGRect) -> Path {
            let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            return Path(path.cgPath)
        }
    }
    func body(content: Content) -> some View {
        content
            .clipShape(CornerRadiusShape(radius: radius, corners: corners))
    }
}

extension View {
    
    //MARK: -  Hide Keyboard Extension -
    
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    //MARK: - Yello Button Extension -
    
    func yellowButton() -> some View {
        return self
            .modifier(YellowButton())
    }
    
    //MARK: -  CornerRedius Extension -
    
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        ModifiedContent(content: self, modifier: CornerRadiusStyle(radius: radius, corners: corners))
    }
    
    //MARK: - outer Shadow Extension -
    
    func outerShadow(_ cornerRadius: CGFloat = 10) -> some View {
        return self
            .modifier(ShadowModifier(cornerRadius: cornerRadius))
    }
    
    //MARK: - gray Shadow Extension -
    
    func grayOuterShadow(_ cornerRadius: CGFloat = 10) -> some View {
        return self
            .modifier(GrayShadowModifier(cornerRadius: cornerRadius))
    }
}

//MARK: - ScrollingDisable Modifier -

struct DisableScrollingModifier: ViewModifier {
    var disabled: Bool
    func body(content: Content) -> some View {
        if disabled {
            content
                .simultaneousGesture(DragGesture(minimumDistance: 0))
        } else {
            content
        }
    }
}

extension View {
    
    //MARK: - ScrollingDisable Extension -
    
    func scrollingDisabled(_ disabled: Bool) -> some View {
        modifier(DisableScrollingModifier(disabled: disabled))
    }
}

enum ValidatorType: String {
    case decimal = "^[-]?[\\d]*(?:\\###decimalSeparator###?[\\d]*)?$"
    case number = "^\\d+$"
}


//MARK: - Decimal Validation -

struct DecimalValidator: ViewModifier {
    
    @Binding var number: String
    var validatorType: ValidatorType
    private func validator(newValue: String) {
        let regex: String = validatorType.rawValue.replacingOccurrences(of: "###decimalSeparator###", with: Locale.current.decimalSeparator!)
        
        if newValue.range(of: regex, options: .regularExpression) != nil {
            self.number = newValue
        } else if !self.number.isEmpty {
            self.number = String(newValue.prefix(self.number.count - 1))
        }
    }
    func body(content: Content) -> some View {
        content
            .onReceive(Just(number), perform: validator)
    }
}

extension TextField {
    func validator(value: Binding<String>, type:ValidatorType) -> some View {
        modifier(DecimalValidator(number: value, validatorType: type))
    }
}
