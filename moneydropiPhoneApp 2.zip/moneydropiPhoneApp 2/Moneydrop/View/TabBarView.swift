//
//  TabBarView.swift
//  Moneydrop
//
//  Created by Gipl on 08/12/22.
//

import SwiftUI

struct TabBarView: View {
    
    @State var index = 0
    
    var body: some View {
        
        ZStack(alignment: .bottomLeading) {
            
            if self.index == 0 {
                HomeView()
            }
            
            if self.index == 1 {
                BeneficiariesListView()
            }
            
            if self.index == 2 {
                TransactionsView()
            }
            
            if self.index == 3 {
                ProfileView()
            }
            
            if self.index == 4 {
                SettingView()
            }
            
            CustomTabs(index: self.$index)
            
        }
        .frame(maxWidth: .infinity)
        .ignoresSafeArea(.all, edges: .bottom)
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView()
    }
}

struct CustomTabs : View {
    
    @Binding var index : Int
    
    var body: some View {
        
        HStack {
            
            Button {  self.index = 0  } label: {
                Image( self.index == 0 ? "transfer-selectedTab": "transferTAB")
            }
            Spacer()
            
            Button { self.index = 1 } label: {
                Image(self.index == 1 ? "recipient-selectedtab" : "recipienttab")
            }
            Spacer()
            
            Button { self.index = 2 } label: {
                Image(self.index == 2 ? "recipt-selectedtab" : "recipttab")
            }
            Spacer()
            
            Button {  self.index = 3 } label: {
                Image(self.index == 3 ? "profie-selectedtab" : "profiletab")
            }
            Spacer()
            
            Button {
                self.index = 4
            } label: {
                Image(self.index == 4 ? "setting-selectedtab" : "settingtab")
            }
        }
        .foregroundColor(Color.black)
        .padding(.horizontal, 25)
        .frame(height: 60)
        .frame(maxWidth: .infinity)
        .padding(.bottom, 10)
        .background(Color.white)
        .cornerRadius(20, corners: [.topLeft, .topRight])
        
    }
}
 
 
