//
//  VerifyView.swift
//  Moneydrop
//
//  Created by Gipl on 20/12/22.
//

import SwiftUI

struct VerifyView: View {
    
    @Environment(\.presentationMode) var presentation
    @State var otp                      =   ""
    @State var secondsCount             =   0
    @State var verify_email             =   ""
    @State var email_validate_string    =   ""
    @State var page_name                =   ""
    @State var presentItem              :   PresentItem<AnyView>?
    @State var date                     =   Date().addingTimeInterval(120)
    @State var clearTextFiled           = false
    
    var body: some View {
        
        VStack{
            
            HStack {
                Button {
                    presentation.wrappedValue.dismiss()
                    //rootView()?.dismiss(animated: true, completion: nil)
                } label: {
                    Image("back")
                }
                Spacer()
            }
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(alignment: .leading, spacing: 15) {
                    Text("Enter the 4-digit code which we have sent to below email address.")
                        .customFont(.medium, 16)
                        .foregroundColor(.black)
                        .padding(.top,50)
                    
                    Text(verify_email)
                        .customFont(.regular, 14)
                        .foregroundColor(.black)
                    
                    HStack {
                        Spacer()
                        OTPViewVPM(otp: $otp, clearTextFiled: clearTextFiled)
                            .frame(width: 200, height: 60)
                        Spacer()
                    }
                    
                    VStack(alignment: .leading,spacing: 8) {
                        HStack{
                            Text("Didn't receive code?")
                                .customFont(.regular, 14)
                                .foregroundColor(.black)
                            Spacer()
                            if secondsCount > 0 {
                                Text(timeString(time: TimeInterval(secondsCount)))
                                    .customFont(.regular, 14)
                                    .foregroundColor(.black)
                            }else{
                                Button(action: {
                                    hideKeyboard()
                                    resendOTP()
                                }) {
                                    Text("RESEND")
                                        .customFont(.semibold, 14)
                                        .foregroundColor(.red)
                                    // .frame(maxWidth: .infinity)
                                }
                            }
                        }
                    }
                    .padding(.vertical)
                    
                    Button {
                        verifyOTP()
                    } label: {
                        Text("VERIFY").frame(maxWidth: .infinity)
                    }.yellowButton()
                        .padding(.vertical, 30)
                }
            }
        }
        .onAppear {
            startTimer()
        }
        
        .onTapGesture {
            hideKeyboard()
        }
        .padding()
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
        .fullScreenCover(item: $presentItem) { item in
            item.content
        }
    }
    
    //MARK: - Verify OTP API call -
    
    func verifyOTP() {
        
        hideKeyboard()
        
        if otp.isEmpty {
            makeToast(Messages.enterOTP)
            return
        }
        
        if otp.count != 4 {
            makeToast(Messages.enterValidOTP)
            return
        }
        
        let parameter = [
            ApiKey.validate_string: email_validate_string,
            ApiKey.page_name : page_name,
            ApiKey.otp: otp
        ] as [String : Any]
        
        showProgressHUD()
        DataManager.getApiResponse(parameter, methodName: .verifyOtp) { json , error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                makeToast(apiMessage(json))
                if page_name == "forgot_password" {
                    self.presentItem = PresentItem(content: AnyView(ResetPasswordView(validate_string: email_validate_string)))
                } else {
                    let data = json.userData
                    saveStorage(data)
                    Storage.login = "yes"
                    Storage.image_url = data.image_url
                    rootView()?.view.window?.rootViewController = UIHostingController(rootView: NavigationView { TabBarView() })
                }
            } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    
    //MARK: - Show timer for validate OTP -
    
    func startTimer() {
        secondsCount = Int(date.timeIntervalSince1970-Date().timeIntervalSince1970)
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            startTimer()
        }
    }
    
    //MARK: - Resend OTP API call -
    
    func resendOTP() {
        
        hideKeyboard()
        self.otp = ""
        clearTextFiled = true
        
        DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
            hideKeyboard()
            clearTextFiled = false
        }
        
        let parameter = [ApiKey.validate_string: email_validate_string, ApiKey.page_name : page_name] as [String : Any]
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .resendOtp) { json , error in
           
            dismissProgressHUD()
            
            if apiStatus(json) {
                date = Date().addingTimeInterval(120)
                makeToast(apiMessage(json))
            } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - Time to String -
    
    func timeString(time: TimeInterval) -> String {
        // let hour = Int(time) / 3600
        let minute = Int(time) / 60 % 60
        let second = Int(time) % 60
        // return formated string
        return String(format: "%02i:%02i", minute, second)
    }
    
}

struct VerifyView_Previews: PreviewProvider {
    static var previews: some View {
        VerifyView()
    }
}
