//
//  IntroductionView.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI

struct IntroductionView: View {
    
    var sliderImages = [
        (image: "screen-1", title: "MoneyDrop Transfer is an online service providing fast & reliable money transfer."),
        (image: "screen-2", title: "MoneyDrop Transfer is a remittance online service platform focused on providing fast and reliable money transfer services to countries around the world within seconds."),
        (image: "screen-3", title: "Our exchange rates are the best and most highly competitive in most currencies around the world and are delivered with convenience and customer satisfaction in mind."),
        (image: "screen-4", title: "We pride ourselves on fast and reliable money transfer service, and our system is highly secured."),
        (image: "screen-5", title: "We provide low-cost, efficient, simple, and secured remittance services around the globe.")
    ]
    
    @State var index = 0
    @State var showLoginView = false
    
    var body: some View {
        
        VStack (spacing: 0) {
            
            //MARK: - Slider -
            
            PagerView(pageCount: sliderImages.count, currentIndex: $index) {
                
                ForEach(0..<sliderImages.count, id: \.self) { i in
                    
                    VStack (spacing: 25 ){
                        
                        Image(sliderImages[i].image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: ScreenSize.SCREEN_WIDTH - 100, height: ScreenSize.SCREEN_HEIGHT*0.38)
                        
                        Text(sliderImages[i].title)
                            .fixedSize(horizontal: false, vertical: true)
                            .customFont(.brandonRegular, 27)
                            .lineSpacing(0)
                            .frame(maxWidth: .infinity, alignment: .leading)
                     }
                    .foregroundColor(Color.white)
                    .padding(.horizontal, 20)
                }
            }
            
            Button {
                showLoginView.toggle()
            } label: {
                HStack{
                    Text("GET STARTED")
                    Image("arrow-left")
                }
                 .frame(maxWidth: .infinity)
            }
            .yellowButton()
            .padding(.horizontal, 20)
            .padding(.bottom)
            
        }
        .frame(maxWidth: .infinity)
        .background(Color.greenColor.edgesIgnoringSafeArea(.all))
        .fullScreenCover(isPresented: $showLoginView) {
            LoginView()
        }
     
    }
}

struct IntroductionView_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionView()
    }
}
