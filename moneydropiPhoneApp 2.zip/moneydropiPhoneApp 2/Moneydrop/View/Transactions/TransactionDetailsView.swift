//
//  TransactionDetailsView.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI
 
struct TransactionDetailsView: View {
    
    @Environment(\.presentationMode) var presentationMode
    var transaction_id                  : String
   // @Binding var transaction_id : String
    
    @State var transaction              =   [JSON]()
    @State var sending_reason_detail    =   JSON()
        
    @State var account_number           = ""
    @State var bank_name                = ""
    @State var sent_amount              = "0"
    @State var reference_no             = ""
        
    @State var recipient_name           = ""
    @State var phone_number             = ""
    @State var dial_code                = ""
    @State var email                    = ""
    @State var reason                   = ""
    @State var state_name               = ""
    @State var city_name                = ""
    @State var country_name             = ""
    @State var phonenumber              = ""
    @State var sent_currency_code       = ""
    @State var payment_status           = ""
    @State var transaction_status       = ""
    @State var payment_gateway_type     = ""
    
    @State var trans_id                 = ""
    @State var trans_stage              = ""
    @State var sent_date                = Double()
    @State var received_date            = Double()
    @State var selected                 = "details"
    
    @State var per_destination_currency                 =   ""
    @State var received_country_code                    =   ""
    @State var exchange_sent_currency_code              =   ""
    @State var credit_card_transaction_charge           =   "0"
    @State var credit_card_transaction_charge_type      =   ""
    @State var credit_card_transaction_amount           =   ""
    @State var admin_recieve_currency                   =   ""
    @State var received_currency_code                   =   ""
    @State var received_amount                          =   "0"
    @State var admin_recieve_amount                     =   "0"
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            HStack {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
                Text("Transactions Details".uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            .padding(.horizontal)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack {
                    
                    HStack(spacing:10) {
                        
                        Button {
                            selected = "details"
                        } label: {
                            Text("Details")
                                .frame(maxWidth:.infinity)
                        }
                        .frame(height: 45)
                        .background( selected == "details" ? Color.yellowColor : Color.white)
                        .foregroundColor(.black)
                        .cornerRadius(5)
                        
                        Button {
                            selected = "status"
                        } label: {
                            Text("Status")
                                .frame(maxWidth:.infinity)
                        }
                        .frame(height: 45)
                        .background(selected == "status" ? Color.yellowColor :  Color.white )
                        .foregroundColor(.black)
                        .cornerRadius(5)
                    }
                    .padding(5)
                    .frame(height: 58)
                    .background(Color.wihteBorder)
                    .cornerRadius(5)
                    .customFont(.bold, 16)
                    .padding(.horizontal)
                }
                .padding(.top , 15)
                
                VStack(spacing:0) {
                    
                    VStack(spacing: 15) {
                        
                        //MARK: - Selected payment details -
                        
                        if selected == "details" {
                            
                            VStack{
                                Text("Transaction ID : \(trans_id)")
                                    .customFont(.bold, 14)
                                    .foregroundColor(Color.greenColor)
                                    .padding(.horizontal)
                                    .padding(.vertical, 10)
                            }
                            .frame(maxWidth: .infinity)
                            .background(Color.grayLightColor)
                            
                            VStack(alignment: .leading, spacing: 5) {
                                TransDetailsRow(placeholder: "Name", value: recipient_name)
                                TransDetailsRow(placeholder: "Phone No", value: "(\(dial_code)) \(phone_number)")
                                TransDetailsRow(placeholder: "Email", value: email)
                                TransDetailsRow(placeholder: "City", value: city_name)
                                TransDetailsRow(placeholder: "Country", value: country_name)
                                if !sending_reason_detail.name.isEmpty {
                                    TransDetailsRow(placeholder: "Sending Reason", value: sending_reason_detail.name)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal)
                            
                            VStack {
                                Text("Exchange Rate : 1 \(exchange_sent_currency_code) = \(per_destination_currency) \(received_country_code)")
                                    .customFont(.bold, 14)
                                    .foregroundColor(Color.greenColor)
                                    .padding(.horizontal)
                                    .padding(.vertical, 10)
                            }
                            .frame(maxWidth: .infinity)
                            .background(Color.grayLightColor)
                            
                            VStack(alignment: .leading, spacing: 7) {
                                
                                TransDetailsRow(placeholder: "Account/Mobile No", value: account_number)
                                TransDetailsRow(placeholder: "Bank Name", value: bank_name)
                                
                                if transaction_status != "pending" {
                                    TransDetailsRow(placeholder: "Completion Time", value: "\(received_date.getDateAndTime())")
                                } else {
                                    TransDetailsRow(placeholder: "Completion Time", value: "N/A")
                                }
                                
                                TransDetailsRow(placeholder: "Transaction Time", value: "\(sent_date.getDateAndTime())")
                                
                                TransDetailsRow(placeholder: "Status", value: payment_status.capitalized)
                                
                                if payment_gateway_type == "stripe" {
                                    
                                    TransDetailsRow(placeholder: "Credit Card Transaction Charge", value: "\(credit_card_transaction_charge)%")
                                    
                                    let credit_card_amount = Double(credit_card_transaction_amount)
 
                                    TransDetailsRow(placeholder: "Credit Card Transaction Amount", value: "\(admin_recieve_currency.uppercased()) \(credit_card_amount?.price ?? "0.00")")
                                    TransDetailsRow(placeholder: "Reference No.", value: reference_no)
                                }
 
                                let user_sent_amount = Double(sent_amount)
                                let user_received_amount = Double(received_amount)
                                let user_admin_recieve_amount = Double(admin_recieve_amount)
                                
                                TransDetailsRow(placeholder: "From Amount", value: "\(sent_currency_code) \(user_sent_amount?.price ?? "0.00")")
                                TransDetailsRow(placeholder: "To Amount", value: "\(received_currency_code) \(user_received_amount?.price ?? "0.00")")
                                
                                TransDetailsRow(placeholder: "Total Amount", value: "\(admin_recieve_currency.uppercased()) \(user_admin_recieve_amount!.price)")
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal)
                            .padding(.bottom)
                            
                        } else {
                            
                            //MARK: - Selected payment status -
                            
                            VStack(alignment: .leading, spacing: 5) {
                                
                                if trans_stage == "0" {
                                    if payment_gateway_type == "payid" {
                                        PaymentStatusRow(placeholder: "\(sent_date.getDateStringFromUTC())".uppercased(), value: "Please wait, Once admin confirm your payment.")
                                    }
                                    else {
                                        PaymentStatusRow(placeholder: "\(sent_date.getDateStringFromUTC())".uppercased(), value: "Payment has been cancelled.")
                                    }
                                }
                                
                                else  if trans_stage == "1" {
                                    PaymentStatusRow(placeholder: "\(sent_date.getDateStringFromUTC())".uppercased(), value: "Transfer created")
                                    PaymentStatusRow(placeholder: "\(sent_date.getDateStringFromUTC())".uppercased(), value: "We processed the transfer")
                                }
                                else if trans_stage == "2" {
                                    PaymentStatusRow(placeholder: "\(sent_date.getDateStringFromUTC())".uppercased(), value: "Transfer created")
                                    PaymentStatusRow(placeholder: "\(sent_date.getDateStringFromUTC())".uppercased(), value: "We processed the transfer")
                                    PaymentStatusRow(placeholder: "\(received_date.getDateStringFromUTC())".uppercased(), value: "Transfer successful")
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                        }
                    }
                    .navigationBarHidden(true)
                }
                .grayOuterShadow(5)
                .padding()
            }
        }
        .background(Color.white.ignoresSafeArea())
        .onTapGesture {
            hideKeyboard()
        }
        .onAppear {
            getTransactionDetail()
        }
    }
  
    //MARK: - Get transaction details api call -
    
    func getTransactionDetail() {
        
        showProgressHUD()
        
        DataManager.getApiResponse([ApiKey.slug: Storage.slug, ApiKey.transaction_id: transaction_id], methodName: .getTransactionDetail) { json, error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                let result                          =       json.result
                let exchange_rate                   =       json.result["exchange_rate"]
                
                sending_reason_detail               =       result["sending_reason_detail"]
                
                self.per_destination_currency       =       exchange_rate.per_destination_currency
                self.received_country_code          =       exchange_rate.received_country_code
                self.exchange_sent_currency_code    =       exchange_rate.sent_currency_code
                self.account_number                 =       result.recipient_account_number
                self.payment_status                 =       result.payment_status
                self.transaction_status             =       result.transaction_status
                self.sent_date                      =       result.transaction_time
                self.received_date                  =       result.transaction_completion_time
                self.reason                         =       result.reason
                self.sent_currency_code             =       result.sent_currency_code
                self.bank_name                      =       result.recipient_bank_name
                self.sent_amount                    =       result.sent_amount
                self.reference_no                   =       json["result"].transaction_id
                            
                self.recipient_name                 =       result.recipient_name
                self.phone_number                   =       result.recipient_phone
                self.dial_code                      =       result.recipient_dial_code
                self.email                          =       result.recipient_email
                self.state_name                     =       result.recipient_state
                self.city_name                      =       result.recipient_city
                self.country_name                   =       result.recipient_country
                self.trans_id                       =       result.trans_id
                self.trans_stage                    =       result.trans_stage
                self.payment_gateway_type           =       result.payment_gateway_type
                self.credit_card_transaction_charge         =       result.credit_card_transaction_charge
                self.credit_card_transaction_charge_type    =       result.credit_card_transaction_charge_type
                self.credit_card_transaction_amount         =       result.credit_card_transaction_amount
                self.admin_recieve_currency                 =       result.admin_recieve_currency
                self.received_amount                        =       result.received_amount
                self.received_currency_code                 =       result.recipient_currency_code
                self.admin_recieve_amount                   =       result.admin_recieve_amount

                
             } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
}
 
//MARK: - TransDetails Row -

struct TransDetailsRow: View {
    
    var placeholder, value: String
    
    var body: some View {
        
        HStack(alignment: .firstTextBaseline, spacing: 15) {
            
            VStack {
                Text(placeholder)
                    .customFont(placeholder == "From Amount" || placeholder == "To Amount" || placeholder == "Total Amount" ? .bold : .semibold, 14)
            }
            .frame(width: ScreenSize.SCREEN_WIDTH*0.3 , alignment: .leading)
            
            VStack {
                Text(value)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
        }
        .customFont(placeholder == "From Amount" || placeholder == "To Amount"  || placeholder == "Total Amount" ? .bold : .regular, 14)
        .foregroundColor(placeholder == "From Amount" || placeholder == "To Amount"  || placeholder == "Total Amount" ? Color.yellowColor :  Color.blackTxtColor)
        .frame(maxWidth: .infinity, alignment: .topLeading)
    }
}


//MARK: - PaymentStatus Row -

struct PaymentStatusRow: View {
    
    var placeholder, value: String
    
    var body: some View {
        
        HStack(alignment: .firstTextBaseline, spacing: 20) {
            
            VStack(spacing: 0) {
                Text(placeholder)
                    .customFont(.regular, 14)
                    .foregroundColor(Color.blackTxtColor)
            }
            .frame(width: ScreenSize.SCREEN_WIDTH/3 , alignment: .leading)
            
            VStack(spacing: 0) {
                Text(value)
                    .customFont(.regular, 14)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
        }
        .customFont(.regular, 14)
        .foregroundColor(Color.blackTxtColor)
        .frame(maxWidth: .infinity, alignment: .topLeading)
    }
}


 
