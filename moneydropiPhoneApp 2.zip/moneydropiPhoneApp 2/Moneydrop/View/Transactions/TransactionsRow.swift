//
//  TransactionsRow.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI

struct TransactionsRow: View {
    var index                   : Int
//  @State var index = 0
    var transaction             : TransactionModel
    @State var selection        : String?
    @State var transaction_id   = ""
    
    var body: some View {
        
        if !transaction.recipient_name.isEmpty {
            
            NavigationLink {
                TransactionDetailsView(transaction_id: transaction._id)
            } label: {
                VStack {
                    
                    HStack {
                        
                        ZStack {
                            Circle()
                                .fill(index % 2 == 0 ? Color.yellowColor.opacity(0.3) : Color.listLightGreenColor.opacity(0.3))
                                .frame(width: 45, height: 45, alignment: .center)
                            Text(transaction.recipient_name.prefix(1).uppercased())
                            
                                .customFont(.headingBrandon, 30)
                                .foregroundColor(Color.greenColor)
                        }
                        VStack {
                            
                            HStack {
                                Text(transaction.recipient_name.localizedCapitalized)
                                Spacer()
                                let sent_amount = Double(transaction.sent_amount)
                                Text("\(sent_amount?.price ?? "0.00")")
                            }
                            .customFont(.bold, 15.8)
                            .foregroundColor(Color.black)
                            
                            HStack {
                                Text(transaction.sent_date.getDateStringFromUTC())
                                Spacer()
                                HStack {
                                    Text(transaction.sent_currency_code)
                                    Image(systemName: "arrow.left.arrow.right")
                                        .customFont(.regular, 8)
                                    Text(transaction.received_currency_code)
                                }
                            }
                            .customFont(.regular, 14)
                            .foregroundColor(Color.lightBlackTxtColor)
                        }
                    }
                    .padding(.horizontal, 7)
                    //                NavigationLink(destination: TransactionDetailsView(transaction_id: $transaction_id), tag: "transaction-details", selection: $selection) { EmptyView() }
                }
            }
            .frame(height: 62)
            .frame(maxWidth: .infinity)
            .background(Color.white)
            .outerShadow()
            .onTapGesture {
                // selection = "transaction-details"
                transaction_id = transaction._id
                print(transaction_id)
            }
        }
    }
}

//struct TransactionsRow_Previews: PreviewProvider {
//    static var previews: some View {
//        TransactionsRow(index: 1)
//    }
//}
