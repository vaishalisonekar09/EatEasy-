//
//  SettingView.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI
import SDWebImageSwiftUI
import LocalAuthentication

struct SettingView: View {
    
    @State var logout                   = false
    @State private var alertItem        : AlertItem?
    @State var index                    = 3
    @State var document_delete          =   Storage.is_document_deleted
    
    var body: some View {
        
        VStack {
            
            HStack {
                Spacer()
                Text("SETTINGS")
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack{
                    
                    HStack {
                        
                        WebImage(url: URL(string: Storage.image_url))
                            .placeholder {
                                Image("no_image")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 60, height: 60)
                                    .clipShape(Circle())
                                    .clipped()
                            }
                            .resizable()
                            .scaledToFill()
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                            .clipped()
                        
                        VStack(alignment: .leading) {
                            Text(Storage.full_name)
                                .font(headlineBold)
                            Text(Storage.email)
                                .font(subheadlineFont)
                                .colorMultiply(Color.blackTxtColor)
                        }
                        .foregroundColor(Color.black)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding([.horizontal, .top])
                    .padding(.bottom, 3)

                    Divider()
                    VStack(spacing: 15) {
                       
                       Group {
                           NavigationLink(destination: ChangePasswordView()) {
                               settingRow(title: "Change Password")
                           }
//                           Divider()
//                            NavigationLink(destination: CMSView(slug: "our-rates")) {
//                                settingRow(title: "Our Rates")
//                            }
                            Divider()
                            NavigationLink(destination: CMSView(slug: "about")) {
                                settingRow(title: "About")
                            }
                            Divider()
                            
                            NavigationLink(destination: CMSView(slug:"services")) {
                                settingRow(title: "Services")
                            }
                            Divider()
                        }
                        
                        Group {
                            NavigationLink(destination: CMSView(slug:"how-it-works")) {
                                settingRow(title: "How it works")
                            }
                            Divider()
                            NavigationLink(destination: ContactUsView()) {
                                settingRow(title: "Contact us")
                            }
//                            Divider()
//                            NavigationLink(destination: CMSView(slug:"help")) {
//                                settingRow(title: "Help")
//                            }
                            Divider()
                            NavigationLink(destination: FaqView()) {
                                settingRow(title: "FAQ")
                            }
                            Divider()
                        }
                        
                        Group{
//                            NavigationLink(destination: CMSView(slug: "support")) {
//                                settingRow(title: "Support")
//                            }
//                            Divider()
                            NavigationLink(destination: CMSView(slug: "privacy-policy")) {
                                settingRow(title: "Privacy Policy")
                            }
                            Divider()
                            NavigationLink(destination: CMSView(slug: "terms-conditions")) {
                                settingRow(title: "Terms & Conditions")
                            }
                            Divider()
                            
                            NavigationLink(destination: UserAmountLogView()) {
                                settingRow(title: "My Amount Balance Log")
                            }
                            Divider()
                            
                            NavigationLink(destination: ReferralCoupenCodeView()) {
                                settingRow(title: "Refer and Earn")
                            }
                            Divider()
                            
                            
                            
                        }
                        
                        VStack {
                            
                            //MARK: - User biometric true false -
                        
                            HStack {
                                VStack(alignment:.leading) {
                                    Text("Biometric Login")
                                  //  Text("Biometric & Screen locks")
                                }
                                .customFont(.regular, 16)
                                .foregroundColor(.black)
                                Spacer()
                                
                                Toggle("", isOn: Storage.$is_screen_lock.onChange({ (isOn) in
                                    print(isOn)
                                    if isOn {
                                        checkApplockStatus()
                                    }
                                }))
                                .labelsHidden()
                                .toggleStyle(SwitchToggleStyle(tint: Color.greenColor))
                            }
                            .padding(.horizontal)
                            Divider()
                        }
                        
                        Group {
                            
                            //MARK: - User Account Delete -
                            
                            Button {
                                alertItem = AlertItem(alert: Alert(title: Text("Money Drop"), message: Text("Are you sure you want to delete?"), primaryButton: .default(Text("YES"), action: deleteUserAccount), secondaryButton: .cancel(Text("NO"))))
                            } label: {
                                settingRow(title: "Delete Account")
                            }
                            Divider()
                            
                            //MARK: - Delete document -
                            
                            if Storage.is_document_verify == 1 && document_delete == 0 {
                                Button {
                                    alertItem = AlertItem(alert: Alert(title: Text("Money Drop"), message: Text("Are you sure, you want to delete your documents?"), primaryButton: .default(Text("YES"), action: deleteApprovedUserDocument), secondaryButton: .cancel(Text("NO"))))
                                } label: {
                                    settingRow(title: "Delete Document")
                                }
                                Divider()
                            }
                            
                            //MARK: - User logout -
                            
                            Button {
                                alertItem = AlertItem(alert: Alert(title: Text("Money Drop"), message: Text("Are you sure you want to logout?"), primaryButton: .default(Text("YES"), action: logoutApiCall), secondaryButton: .cancel(Text("NO"))))
                            } label: {
                                settingRow(title: "Logout")
                            }
                            Divider()
                            
                            //MARK: - Company Registration number -
                            
//                            VStack {
//                                Text("Austrac Registration Number: 71 659 255 062")
//                                    .customFont(.regular, 13)
//                                    .foregroundColor(.greenColor)
//                            }
//                            .padding(.horizontal)
//                            Divider()
                            

                            
                            //MARK: - App version -
                            
                            let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
                             
                            Text("Version \(String(describing: appVersion!))")
                                .customFont(.regular, 14)
                        }
                    }
                    .padding(.top)
                    .foregroundColor(Color.black)
                    .padding(.bottom, 90)
                    
                }
                .navigationBarHidden(true)
                .alert(item: $alertItem, content: { item in
                    item.alert
                })
            }
        }
        .background(Color.lightGray.ignoresSafeArea())
    }
    
    //MARK: - Setting Row -
    
    func settingRow(title: String) -> some View {
        HStack() {
            Text(title)
                .customFont(.regular, 16)
                .foregroundColor(.black)
            Spacer()
            Image(systemName : "chevron.right")
                .foregroundColor(.gray)
        }
        .padding(.horizontal)
       // .frame(height: 60)
    }
    
    //MARK: - Check App Lock Status -
    
    func checkApplockStatus() {
        
        let context = LAContext()
        var error:NSError?
        
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            Storage.is_screen_lock = false
            print(error?.localizedDescription)
            
            alertItem = AlertItem(alert: Alert(title: Text("Enable Face ID"), message: Text("Please enable Touch ID/Face ID on your device and provide permission to Money Drop app for security"), dismissButton: .default(Text("OK"), action: {
            })))
            return
        }
        Storage.is_screen_lock_slug = Storage.slug
    }
    
    //MARK: - Delete user approved document -
    
    func deleteApprovedUserDocument() {
        let parameter = [ApiKey.slug: Storage.slug] as [String : Any]
        
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .deleteApprovedUserDocument) { json , error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                makeToast(apiMessage(json))
                document_delete = 1
                Storage.is_document_deleted = 1
            } else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
            
        }
    }
    
    //MARK: - Delete Account api -
    
    func deleteUserAccount() {
        
        let parameter = [ApiKey.slug: Storage.slug] as [String : Any]
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .deleteUserAccount) { json , error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                Storage.login = ""
                makeToast(apiMessage(json))
                clearStorage()
                Storage.is_screen_lock_slug = ""
                Storage.is_screen_lock = false
                rootView()?.view.window?.rootViewController = UIHostingController(rootView:  LoginView() )
                
             } else {
                 let is_logout = json["is_logout"].intValue
                 if is_logout == 1 {
                     // Deleted Account Logout
                     userAccountDelete()
                 }
                 else {
                     makeToast(apiMessage(json))
                 }
            }
        }
    }
    
    //MARK: - Logout api call -
    
    func logoutApiCall() {
        showProgressHUD()
        let parameter = [ApiKey.slug: Storage.slug] as [String : Any]
        DataManager.getApiResponse(parameter, methodName: .logout) { json , error in
            
            dismissProgressHUD()
            makeToast(apiMessage(json))
        }
        Storage.login = ""
        clearStorage()
        rootView()?.view.window?.rootViewController = UIHostingController(rootView:  LoginView() )
    }
    
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}


 

 
