//
//  BeneficiariesListView.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI


struct BeneficiariesListView: View {
    
    @State var beneficiarylist    =   [BeneficiariesModel]()
    @State var no_of_page         =   1
    @State var total              =   0
    
    var body: some View {
        
        VStack{
            
            HStack {
                Spacer()
                Text("BENEFICIARIES")
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            
            .overlay(
                NavigationLink(destination: AddBeneficiaryView(), label: {
                    Image(systemName: "plus")
                        .padding(.vertical, 7)
                        .frame(maxWidth: .infinity)
                })
                .frame(width: 60)
                .background(Color.yellowColor)
                .foregroundColor(.black)
                .cornerRadius(5)
                .customFont(.bold, 20)
                .padding(.trailing)
                ,alignment: .trailing
            )
            
            VStack {
                
                ScrollView(.vertical, showsIndicators: false) {
                    
                    //MARK: - Beneficiary list -
                    
                    LazyVGrid(columns: [GridItem(.flexible())], alignment: .leading) {
                        
                        ForEach(beneficiarylist) { d in
                            
                            BeneficiarylistRow(beneficiary: d, deleteBeneficiary: {
                                deleteRecipientUser(recipient_user_id: d._id)
                            })
                            .onAppear {
                                if (beneficiarylist.last?._id ?? "") == d._id && total > beneficiarylist.count  {
                                    no_of_page += 1
                                    recipientUserList()
                                }
                            }
                        }
                        
                    }
                    .padding(.bottom, 90)
                }
                .background(emptyView(beneficiarylist.isEmpty))
            }
            .navigationBarHidden(true)
            .padding()
            .background(Color.lightGray.ignoresSafeArea())
        }
        .onAppear {
            beneficiarylist = []
            no_of_page = 1
            recipientUserList()
        }
        
    }
    
        //MARK: - Beneficiary list api call -
    
    func recipientUserList() {
        
        if no_of_page == 1 {
          beneficiarylist = []
        }
        
        let parameter = [ApiKey.slug: Storage.slug, ApiKey.page: no_of_page] as [String : Any]
        
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .recipientUserList) { json , error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                self.total  = json.total_record
                
                for data in json["result"]["data"].arrayValue {
                    if self.beneficiarylist.filter({ $0.id == data.id}).count > 0 { return }
                    self.beneficiarylist.append(BeneficiariesModel(data))
                }
            } else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
    //MARK: - Delete Beneficiary -
    
    func deleteRecipientUser(recipient_user_id: String) {
        
        var parameter = [String: Any]()
        parameter[ApiKey.slug]      = Storage.slug
        parameter[ApiKey.recipient_user_id]   = recipient_user_id
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .deleteRecipientUser) { json , error in
            dismissProgressHUD()
            if apiStatus(json) {
                makeToast(apiMessage(json))
                no_of_page = 1
                recipientUserList()
            }else{
                makeToast(apiMessage(json))
            }
        }
    }
    
}

struct BeneficiariesListView_Previews: PreviewProvider {
    static var previews: some View {
        BeneficiariesListView()
    }
}
