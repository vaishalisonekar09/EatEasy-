//
//  BeneficiarylistRow.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI

struct BeneficiarylistRow: View {
    
    var beneficiary         : BeneficiariesModel
    var deleteBeneficiary   : () -> () = {}
    @State var delete       = false
    
    var body: some View {
        
        if beneficiary.is_active == 1 {
            
            VStack(alignment: .leading, spacing: 0) {
                
                Text(beneficiary.recipient_name)
                    .customFont(.semibold, 16)
                    .foregroundColor(Color.black)
                Text(beneficiary.email)
                    .foregroundColor(Color.black)
                    .colorMultiply(Color.black.opacity(0.5))
                Text("(\(beneficiary.dial_code)) \(beneficiary.phone)")
                Spacer()
                
                HStack(spacing:0) {
                    Text("A/c no. ")
                        .customFont(.regular, 13)
                    Text(beneficiary.account_number)
                        .customFont(.light, 13)
                        .foregroundColor(Color.black)
                }
                
                HStack(alignment: .top, spacing:0) {
                    Text("Bank Name. ")
                        .customFont(.regular, 13)
                    Text(beneficiary.bank_name)
                        .foregroundColor(Color.black)
                }
            }
            .customFont(.regular, 13)
            .foregroundColor(Color.blackTxtColor)
            .frame(maxWidth:.infinity, alignment: .leading)
            
            .overlay(
                HStack(spacing: 15) {
                    NavigationLink {
                        EditBeneficiaryView(json: beneficiary , recipient_user_id : beneficiary._id)
                    } label: {
                        Image(systemName: "pencil")
                    }
                    Button {
                        delete.toggle()
                    } label: {
                        Image(systemName: "trash")
                    }
                }
                    .customFont(.bold, 20)
                    .foregroundColor(Color.black)
                ,alignment: .topTrailing
            )
            .padding()
            .outerShadow()
            .alert(isPresented: $delete) {
                Alert(
                    title:
                        Text("Money Drop").font(subheadlineFontMedium),
                    message: Text("Are you sure you want to delete this beneficiary?").font(footnoteFont)  ,
                    primaryButton: .default(Text("YES").font(subheadlineFont), action: {
                        deleteBeneficiary()
                    }),
                    secondaryButton: .cancel(Text("NO").font(subheadlineFont))
                )
            }
        }
    }
}
    
 

//struct BeneficiarylistRow_Previews: PreviewProvider {
//    static var previews: some View {
//        BeneficiarylistRow()
//    }
//}
