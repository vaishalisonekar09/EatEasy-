//
//  EditBeneficiaryView.swift
//  Moneydrop
//
//  Created by Gipl on 21/12/22.
//

import SwiftUI

struct EditBeneficiaryView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var  iban_code_error       =   ""
    @State var  bank_name_error       =   ""
    @State var  bic_code_error        =   ""
    @State var  account_number_error  =   ""
    @State var  name_error            =   ""
    @State var  email_error           =   ""
    @State var  dial_code_error       =   "+91"
    @State var  phone_number_error    =   ""
    @State var  swift_code_error      =   ""
    @State var  address_error         =   ""
    @State var  country_error         =   ""
    @State var  state_error           =    ""
    @State var  city_error            =     ""
    @State var  zip_error             =     ""
   // @State var  bank_name_error       =     ""

    @State var  iban_code           =   ""
    @State var  bank_name           =   ""
    @State var  bic_code            =   ""
    @State var  account_number      =   ""
    @State var  name                =   ""
    @State var  email               =   ""
    @State var  dial_code           =   "+91"
    @State var  phone_number        =   ""
    @State var  swift_code          =   ""
    @State var  address             =   ""
    @State var countrylist          =   [KeyValueModel]()
    @State var selectedCountry      =   KeyValueModel(id: "", value: "")
        
    @State var statelist            =   [KeyValueModel]()
    @State var selectedState        =   KeyValueModel(id: "", value: "")
        
    @State var citylist             =   [KeyValueModel]()
    @State var selectedCity         =   KeyValueModel(id: "", value: "")
    @State var zip_code             =   ""
    
    @State var banklist             =   [KeyValueModel]()
    @State var selectedBank         =   KeyValueModel(id: "", value: "")
    
    var json                        :   BeneficiariesModel
    @State var recipient_user_id    =   ""
    @State var error_index = 0
    
    var body: some View {
        
        VStack  {
            
            HStack {
                
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Image("back")
                }
                Spacer()
                Text("Edit Beneficiary".uppercased())
                    .customFont(.headingBrandon, 20)
                Spacer()
            }
            .frame(height: 50)
            .padding(.horizontal)
            
            VStack {
                ScrollViewReader { value in
                    
                    ScrollView(.vertical, showsIndicators: false) {
                        
                        VStack {
                            
                            VStack(alignment: .leading, spacing: 0) {
                                
                                Group {
                                
                                    Text("Beneficiaries Details").font(headlineBold)
                                    
                                    CustomTextFieldWithLabel(title: "Name", placeholder: "Enter name", text: $name, star: true, errorMsg: $name_error)
                                        .id(1)
                                    CustomTextFieldWithLabel(title: "Email Address", placeholder: "Enter valid email", text: $email, keyboard: .emailAddress, star: true, errorMsg: $email_error)    .id(2)
                                    NumberTextFieldView(title: "Phone Number", placeholder: "Enter valid phone number", dial_code: $dial_code, text: $phone_number, star: true)  .id(3)
                                }
                                
                                Group {
                                   
                                    CustomTextFieldWithLabel(title: "Address", placeholder: "Enter address here", text: $address,  star: true, errorMsg: $address_error)  .id(4)
                                    
                                    VStack(alignment: .leading, spacing: 15) {
                                        
                                        Menu {
                                            if countrylist.isEmpty {
                                                Text("Record not found")
                                            } else {
                                                ForEach (countrylist) { i in
                                                    Button(action: {
                                                        selectedCountry.id      =   i.id
                                                        selectedCountry.value   =   i.value
                                                        selectedState.value     =   ""
                                                        selectedState.id        =   ""
                                                        selectedCity.id         =   ""
                                                        selectedCity.value      =   ""
                                                        selectedBank.id         =   ""
                                                        selectedBank.value      =   ""
                                                        statelist               =   []
                                                        citylist                =   []
                                                        banklist                =   []
                                                        getStateList()
                                                        getActiveBankList()
                                                    }, label: {
                                                        Text(i.value)
                                                        if selectedCountry.id == i.id {
                                                            Image(systemName: "checkmark")
                                                        }
                                                    })
                                                }
                                            }
                                        } label: {
                                            
                                            DropDownFieldWithLabel(title: "Country", text: .constant(selectedCountry.value != "" ? selectedCountry.value  : "Select country") , star: true, is_error: $country_error)
                                            
                                        }
                                    }
                                    .frame(height: 75, alignment: .leading)
                                    .foregroundColor(Color.blackTxtColor)
                                    .id(5)
                                    
                                    VStack(alignment: .leading, spacing: 15) {
                                        
                                       
                                        Menu {
                                            if statelist.isEmpty {
                                                Text("Record not found")
                                            } else {
                                                ForEach (statelist) { i in
                                                    Button(action: {
                                                        selectedState.id    =   i.id
                                                        selectedState.value =   i.value
                                                        selectedCity.id     =   ""
                                                        selectedCity.value  =   ""
                                                        citylist            =   []
                                                        getCityList()
                                                    }, label: {
                                                        Text(i.value)
                                                        if selectedState.id == i.id {
                                                            Image(systemName: "checkmark")
                                                        }
                                                    })
                                                }
                                            }
                                        } label: {
                                            
                                            DropDownFieldWithLabel(title: "State", text: .constant(selectedState.value != "" ? selectedState.value   : "Select state") , star: true, is_error: $state_error)
                                            
                                        }
                                    }
                                    .frame(height: 75, alignment: .leading)
                                    .foregroundColor(Color.blackTxtColor)
                                    .id(6)
                                   
                                    VStack(alignment: .leading, spacing: 15) {
                                        
                                        //                                    HStack(spacing:0) {
                                        //                                        Text("City")
                                        //                                        Text("*").foregroundColor(Color.redColor)
                                        //                                    }
                                        //                                    .customFont(.semibold, 14)
                                        //                                    .multilineTextAlignment(.leading)
                                        
                                        Menu {
                                            if citylist.isEmpty {
                                                Text("Record not found")
                                            } else {
                                                ForEach (citylist) { i in
                                                    Button(action: {
                                                        selectedCity.id     = i.id
                                                        selectedCity.value  = i.value
                                                    }, label: {
                                                        Text(i.value)
                                                        if selectedCity.id == i.id {
                                                            Image(systemName: "checkmark")
                                                        }
                                                    })
                                                }
                                            }
                                        } label: {
                                            
                                            //                                        HStack {
                                            //                                            Text(selectedCity.value != "" ? selectedCity.value  : "Select city")
                                            //                                                .customFont(.regular, 15)
                                            //                                            Spacer()
                                            //                                            Image("down-arrow").renderingMode(.template)
                                            //                                        }
                                            //                                        .frame(maxWidth: .infinity)
                                            //                                        .overlay(
                                            //                                            Rectangle().fill(Color.greenColor).frame(height: 1)
                                            //                                                .frame(maxWidth: .infinity).offset(y:7)
                                            //                                            , alignment: .bottomLeading
                                            //                                        )
                                            
                                            DropDownFieldWithLabel(title: "City", text: .constant(selectedCity.value != "" ?selectedCity.value   : "Select city") , star: true, is_error: $city_error)
                                        }
                                    }
                                    .frame(height: 75, alignment: .leading)
                                    .foregroundColor(Color.blackTxtColor)
                                    .id(7)
                                    
                                    CustomTextFieldWithLabel(title: "Zip code", placeholder: "Enter zip code", text: $zip_code,  star: true, errorMsg: $zip_error)
                                        .id(8)

                                }
                            }
                            
                            VStack(alignment: .leading, spacing: 0) {
                                
                                Text("Bank Details").font(headlineBold)
                                
                                CustomTextFieldWithLabel(title: "Bank Name IBAN", placeholder: "Enter bank name IBAN", text: $iban_code, star: false, errorMsg: $iban_code_error)
                                    .id(9)
                               
                                CustomTextFieldWithLabel(title: "Bank Name", placeholder: "Enter bank name", text: $bank_name, star: true,errorMsg: $bank_name_error)
                                    .id(10)
                                
                                VStack(alignment: .leading, spacing: 15) {
                                    
                                    //                                HStack(spacing:0) {
                                    //
                                    //                                    Text("Bank Name")
                                    //                                    Text("*").foregroundColor(Color.redColor)
                                    //                                }
                                    //                                .customFont(.semibold, 14)
                                    //                                .multilineTextAlignment(.leading)
                                    
                                    Menu {
                                        if banklist.isEmpty {
                                            Text("Record not found")
                                        } else {
                                            ForEach (banklist) { i in
                                                Button(action: {
                                                    selectedBank.id     = i.id
                                                    selectedBank.value  = i.value
                                                }, label: {
                                                    Text(i.value)
                                                    if selectedBank.id == i.id {
                                                        Image(systemName: "checkmark")
                                                    }
                                                })
                                            }
                                        }
                                    } label: {
                                        
                                        DropDownFieldWithLabel(title: "Bank Name", text: .constant(selectedBank.id != "" ?selectedBank.value   : "Select bank name") , star: true, is_error: $bank_name_error)
                                        
                                        //                                    HStack {
                                        //                                        Text(selectedBank.id != "" ? selectedBank.value  : "Select bank name")
                                        //                                           .customFont(.regular, 15)
                                        //                                        Spacer()
                                        //                                        Image("down-arrow").renderingMode(.template)
                                        //                                    }
                                        //                                    .frame(maxWidth: .infinity)
                                        //                                    .overlay(
                                        //                                        Rectangle().fill(Color.greenColor).frame(height: 1)
                                        //                                            .frame(maxWidth: .infinity).offset(y:7)
                                        //                                        , alignment: .bottomLeading
                                        //                                    )
                                    }
                                }
                                .frame(height: 75, alignment: .leading)
                                .foregroundColor(Color.blackTxtColor)
                                .id(11)
                           
                                CustomTextFieldWithLabel(title: "Account/Mobile No", placeholder: "Enter account/mobile no", text: $account_number, keyboard: .numberPad, star: true, errorMsg: $account_number_error)
                                    .id(12)
                                
                                CustomTextFieldWithLabel(title: "BIC", placeholder: "Enter BIC", text: $bic_code, star: false, errorMsg: $bic_code_error)
                                    .id(13)
                                
                                CustomTextFieldWithLabel(title: "Swift Code", placeholder: "Enter swift code", text: $swift_code,  star: false, errorMsg: $swift_code_error)
                                    .id(14)
                         
                            }
                            
                            .padding(.top)
                            
                            Button {
                                
                                //MARK: - Update Beneficiary function call -
                                
                                EditBeneficiaryValid()
                                withAnimation {
                                    value.scrollTo(error_index, anchor: .top)
                                }
                                
                            } label: {
                                Text("UPDATE Beneficiary".uppercased())
                                    .frame(maxWidth: .infinity)
                            }
                            .yellowButton()
                            .padding(.top, 25)
                        }
                        .navigationBarHidden(true)
                        .padding()
                        .background(Color.white)
                        .padding()
                    }
                }
            }
            .background(Color.lightGray.ignoresSafeArea())
        }
        .onTapGesture {
            hideKeyboard()
        }.onAppear {
            
            
            if recipient_user_id != "" {
                
                iban_code               =   json.iban_code
                bank_name               =   json.bank_name
                bic_code                =   json.bic_code
                account_number          =   json.account_number
                name                    =   json.recipient_name
                email                   =   json.email
                dial_code               =   json.dial_code
                phone_number            =   json.phone
                swift_code              =   json.swift_code
                address                 =   json.address
                selectedCountry.id      =   json.country_id
                selectedCountry.value   =   json.country_name
                selectedState.id        =   json.state_id
                selectedState.value     =   json.state_name
                selectedCity.id         =   json.city_id
                selectedCity.value      =   json.city_name
                zip_code                =   json.zip_code
                selectedBank.id         =   json.pg_bank_id
                selectedBank.value      =   json.bank_name
                getActiveCurrencieCountryList()
            }
        }
    }
    
    func EditBeneficiaryValid() {
        
        iban_code_error      =    iban_code.isEmpty ? Messages.enterBankIBAN  : ""
        bank_name_error      =    bank_name.isEmpty ? Messages.enterBankIBAN  : ""
        bic_code_error       =    bic_code.isEmpty ?  Messages.enterBic : ""
        account_number_error =    account_number.isEmpty ? Messages.enterAccountNumber : ""
        name_error           =    name.isEmpty ?  Messages.enterName   : ""
        email_error          =    email.isEmpty ? Messages.enterEmail  : ""
        phone_number_error   =    phone_number.isEmpty ?  Messages.enterPhoneNumber  : ""
        swift_code_error     =    swift_code.isEmpty ? Messages.enterSwiftCode  : ""
        address_error        =    address.isEmpty ? Messages.enterAddress  : ""
        country_error        =    selectedCountry.id.isEmpty ? Messages.selectCountry : ""
        state_error          =    selectedState.id.isEmpty ? Messages.selectState : ""
        city_error           =    selectedCity.id.isEmpty ? Messages.selectCity : ""
        zip_error            =    zip_code.isEmpty ? Messages.enterZipcode  : ""
        
        //name_error email_error phone_number_error address_error country_error state_error city_error zip_error iban_code_error bank_name_error bank_name_error account_number_error bic_code_error swift_code_error
        if name_error != "" {
            error_index = 1
        } else if email_error != ""{
            error_index = 2
        } else if phone_number_error != ""{
            error_index = 3
        } else if address_error != "" {
            error_index = 4
        }else if country_error != "" {
            error_index = 5
        }else if state_error != "" {
            error_index = 6
        }else if city_error != "" {
            error_index = 7
        }else if zip_error != "" {
            error_index = 8
        }else if iban_code_error != "" {
            error_index = 9
        } else if bank_name_error != "" {
            error_index = 10
        } else {
            error_index = 0
        }
        
        
        if email.isEmpty {
            
            email_error = Messages.enterEmail
            
        } else if isValidEmail(email) {
            
            email_error = Messages.enterValidEmail
        }
        
  if iban_code_error == "" &&  bank_name_error  == "" &&  bic_code_error  == "" && account_number_error  == "" &&  name_error == "" &&      email_error    == "" &&  phone_number_error  == "" &&  swift_code_error  == "" &&  address_error  == "" &&   country_error == "" &&  state_error == "" &&  city_error == "" &&    zip_error == "" {
            
            updateBeneficiary()
            
        }
        
    }
    
    //MARK: - Update Beneficiary API call -
    
    func updateBeneficiary() {
        
        hideKeyboard()
        
        if ValidationClass().updateBeneficiaryForm(self) {
            
            let parameter = [ApiKey.recipient_user_id   : recipient_user_id,
                            ApiKey.slug                 : Storage.slug,
                             ApiKey.recipient_name      : name.trimWhitespaces(),
                             ApiKey.email               : email.trimWhitespaces(),
                             ApiKey.dial_code           : dial_code,
                             ApiKey.phone               : phone_number,
                             ApiKey.address             : address.trimWhitespaces(),
                             ApiKey.country             : selectedCountry.id,
                             ApiKey.state               : selectedState.id,
                             ApiKey.city                : selectedCity.id,
                             ApiKey.zip_code            : zip_code.trimWhitespaces(),
                             ApiKey.account_number      : account_number.trimWhitespaces(),
                             ApiKey.bank_name           : selectedBank.id,
                             ApiKey.iban_code           : iban_code.trimWhitespaces(),
                             ApiKey.bic_code            : bic_code.trimWhitespaces(),
                             ApiKey.swift_code          : swift_code.trimWhitespaces()] as [String : Any]
            
            showProgressHUD()
            
            DataManager.getApiResponse(parameter, methodName: .saveRecipientUser) { json , error in
                dismissProgressHUD()
                if apiStatus(json) {
                    makeToast(apiMessage(json))
                        presentationMode.wrappedValue.dismiss()
                } else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
    
    //MARK: - getActiveBankList Api Call -
    
    func getActiveBankList() {
        
        showProgressHUD()
        DataManager.getApiResponse([ApiKey.country_id : selectedCountry.id], methodName: .getActiveBankList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.banklist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
             } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - getActiveCurrencieCountryList List Api Call -
    
    func getActiveCurrencieCountryList() {
        showProgressHUD()
         DataManager.getApiResponse([:], methodName: .getActiveCurrencieCountryList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.countrylist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                getStateList()
                getActiveBankList()
             }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - getCountryList List Api Call -
    
    func getCountryList() {
        showProgressHUD()
         DataManager.getApiResponse([:], methodName: .getCountryList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.countrylist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                getStateList()
             }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - getStateList Api call -
    
    func getStateList() {
        showProgressHUD()
        
        DataManager.getApiResponse([ApiKey.country_id: selectedCountry.id], methodName: .getStateList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.statelist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
                getCityList()
             }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    //MARK: - getCityList Api call -
    
    func getCityList() {
        showProgressHUD()
        DataManager.getApiResponse([ApiKey.country_id: selectedCountry.id, ApiKey.state_id : selectedState.id], methodName: .getCityList) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.citylist = json["result"].arrayValue.map{ KeyValueModel(id: $0.id, value: $0.value) }
             }else {
                makeToast(apiMessage(json))
            }
        }
    }
    
}

//struct EditBeneficiaryView_Previews: PreviewProvider {
//    static var previews: some View {
//        EditBeneficiaryView(json: JSON())
//    }
//}
