//
//  BeneficiariesView.swift
//  Moneydrop
//
//  Created by Gipl on 09/12/22.
//

import SwiftUI

struct BeneficiariesView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var no_of_page               =   1
    @State var total                    =   0
    @Binding var sendAmount             :   String
    @Binding var recipientAmount        :   String
    @Binding var senderCurrencyCode     :   String
    @Binding var recipientCurrencyCode  :   String
    @Binding var source_country_id      :   String
    @Binding var received_country_id    :   String
    @State var selected_beneficiary_id  =   String()
    @State var beneficiarylist          =   [JSON]()
    @State var selection                :   String?
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }, label: {
                    Image("back")
                })
                Spacer()
                Text("BENEFICIARIES".uppercased())
                    .customFont(.headingBrandon, 20)
                    .foregroundColor(Color.black)
                Spacer()
            }
            .padding(.horizontal)
            
            //MARK: - Add New Beneficiary -
            
            .overlay(
                NavigationLink(destination: AddBeneficiaryView(), label: {
                    Image(systemName: "plus")
                        .padding(.vertical, 7)
                        .frame(maxWidth: .infinity)
                })
                .frame(width: 60)
                .background(Color.yellowColor)
                .foregroundColor(.black)
                .cornerRadius(5)
                .customFont(.bold, 20)
                .padding(.trailing)
                ,alignment: .trailing
            )
            
            // MARK: - Beneficiary Lists -
            
            ScrollView(.vertical, showsIndicators: false) {
                
                LazyVGrid(columns: [GridItem(.flexible())], alignment: .leading) {
                    
                    ForEach(0..<beneficiarylist.count, id: \.self) { i in
                        
                        BeneficiaryRow(beneficiary: beneficiarylist[i], selected_beneficiary_id: selected_beneficiary_id, index: i, callback: {
                            selected_beneficiary_id = beneficiarylist[i].id
                        })
                        .onAppear {
                            if (beneficiarylist.last?.id ?? "") == beneficiarylist[i].id && total > beneficiarylist.count {
                                no_of_page += 1
                                recipientUserList()
                            }
                        }
                    }
                }
                .padding()
                .padding(.bottom, 20)
            }
            .background(emptyView(beneficiarylist.isEmpty))
            
            VStack {
                
                Button(action: {
                    hideKeyboard()
                    if !selected_beneficiary_id.isEmpty {
                        checkBeneficiaryCurrency()
                    } else {
                        makeToast(Messages.selectBeneficiary)
                    }
                }, label: {
                    Text("CONTINUE")
                        .frame(maxWidth: .infinity)
                })
                .yellowButton()
                .padding()
            }
            .padding(.bottom)
            
            //MARK: - Confirm Payment View -
            
            NavigationLink(destination: ConfirmPaymentView(sendAmount: $sendAmount, recipientAmount: $recipientAmount, senderCurrencyCode: $senderCurrencyCode, recipientCurrencyCode: $recipientCurrencyCode, selected_beneficiary_id: $selected_beneficiary_id, source_country_id: $source_country_id, received_country_id: $received_country_id), tag: "next_step", selection: $selection) {
                EmptyView()
            }
        }
        .onAppear {
            recipientUserList()
        }
        .navigationBarHidden(true)
        .ignoresSafeArea(.all, edges: .bottom)
    }
    
    //MARK: - checkBeneficiaryCurrency Api call -
    
    func checkBeneficiaryCurrency() {
        
        let parameter = [ApiKey.slug: Storage.slug, ApiKey.receive_currency_code: recipientCurrencyCode, ApiKey.recipient_id: selected_beneficiary_id] as [String : Any]
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .checkBeneficiaryCurrency) { json , error in
            dismissProgressHUD()
            if apiStatus(json) {
               // makeToast(apiMessage(json))
                selection = "next_step"
            }
            else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    
    //MARK: - Beneficiary List API -
    
    func recipientUserList() {
        //       beneficiarylist = []
        let parameter = [ApiKey.slug: Storage.slug, ApiKey.page: no_of_page] as [String : Any]
        showProgressHUD()
        
        DataManager.getApiResponse(parameter, methodName: .recipientUserList) { json , error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                //makeToast(apiMessage(json))
                self.total  = json.total_record
                for list in json["result"]["data"].arrayValue {
                    if self.beneficiarylist.filter({$0.id == list.id}).count > 0 { return}
                    self.beneficiarylist.append(list)
                }
            } else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
}


struct BeneficiariesView_Previews: PreviewProvider {
    static var previews: some View {
        BeneficiariesView(sendAmount: .constant("0"), recipientAmount: .constant("0"), senderCurrencyCode: .constant("AUD"), recipientCurrencyCode: .constant("INR"), source_country_id: .constant(""), received_country_id: .constant(""))
    }
}

struct BeneficiaryRow: View {
    
    var beneficiary                 =   JSON()
    var selected_beneficiary_id     :   String
    var index                       :   Int
    var callback                    :   () -> () = { }
    
    var body: some View {
        
        //MARK: - Check beneficiary active -
        
        if beneficiary.is_active == 1 {
            
            VStack(alignment: .leading, spacing: 0) {
                
                Text(beneficiary.recipient_name)
                    .customFont(.semibold, 16)
                    .foregroundColor(Color.black)
                Text(beneficiary.email)
                    .foregroundColor(Color.black)
                    .colorMultiply(Color.black.opacity(0.5))
                Text("(\(beneficiary.dial_code)) \(beneficiary.phone)")
                Spacer()
                
                HStack(spacing:0) {
                    Text("A/c no. ")
                        .customFont(.regular, 13)
                    Text(beneficiary.account_number)
                        .customFont(.light, 13)
                        .foregroundColor(Color.black)
                }
                
                HStack(alignment: .top, spacing:0) {
                    Text("Bank Name. ")
                        .customFont(.regular, 13)
                    Text(beneficiary.bank_name)
                        .foregroundColor(Color.black)
                }
            }
            .customFont(.regular, 13)
            .foregroundColor(Color.blackTxtColor)
            .frame(maxWidth:.infinity, alignment: .leading)
            
            .overlay(
                Image(selected_beneficiary_id == beneficiary.id ? "radio-button-filled" : "radio-button")
                ,alignment: .topTrailing
            )
            .padding()
            .outerShadow()
            
            .onTapGesture {
                //            selected = index
                callback()
            }
        }
    }
}
