//
//  PayIdPopUpView.swift
//  Moneydrop
//
//  Created by Gipl on 17/02/23.
//

import SwiftUI


public extension UIApplication {
    func currentUIWindow() -> UIWindow? {
        let connectedScenes = UIApplication.shared.connectedScenes
            .filter({
                $0.activationState == .foregroundActive})
            .compactMap({$0 as? UIWindowScene})
        
        let window = connectedScenes.first?
            .windows
            .first { $0.isKeyWindow }

        return window
        
    }
}

struct PayIdPopUpView: View {
    
    @Binding var isShow: Bool
    var accessPayIdDescription: ((_ description: String) -> ()) = {_  in}
    @State var bsb = ""
    @State var bank = ""
    @State var account_number = ""
    @State var payid = ""
    @State var account_name = ""
    @State var description = ""
    @State var note_message = ""
    
    var body: some View {
        
        ZStack {
            Color.black.opacity(0.8).ignoresSafeArea()
            
            ScrollView {
                
                HStack {
                    Spacer()
                    Button(action: {
                        isShow = false
                    }, label: {
                        Image("cross")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                    })
                    .foregroundColor(Color.white)
                }
                .padding(.horizontal)
            }
            .scrollingDisabled(true)
            
            VStack {
                
                VStack(spacing: 5) {
                    
                    PayIdDetails(placeholder: "Bank", value: bank)
                    PayIdDetails(placeholder: "Account Name", value: account_name)
                    PayIdDetails(placeholder: "BSB", value: bsb)
                    PayIdDetails(placeholder: "Account number", value: account_number)
                    PayIdDetails(placeholder: "Bank Transfer/PayID", value: payid)
                    
                    VStack {
                        Text(note_message)
                            .customFont(.regular, 14)
                            .foregroundColor(Color.redColor)
                    }
                    .frame(maxWidth:.infinity, alignment: .leading)
                    .padding(.vertical, 10)

                    Button {
                        hideKeyboard()
                        payNow()
                    } label: {
                        Text("Pay now").frame(maxWidth: .infinity)
                    }
                    .yellowButton()
                    
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.white)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
        }
        .onTapGesture {
            hideKeyboard()
        }
        .onAppear {
            getPayidBankDetails()
        }
  }
   
    //MARK: - PayNow -
    
    func payNow() {
//        if description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
//            makeToast(Messages.enterDescription);
//            return
//        }
        showProgressHUD()
        accessPayIdDescription(description)
    }
    
    
    //MARK: - getPayidBankDetails -
    
    func getPayidBankDetails() {
        
        showProgressHUD()
        let parameter = [:] as [String:Any]
        DataManager.getApiResponse(parameter, methodName: .getPayidBankDetails) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                let data = json.result
                self.note_message = data["message"].stringValue
                self.bsb = data.bsb
                self.bank = data.bank
                self.account_number = data.account_number
                self.payid = data.payid
                self.account_name = data.account_name
             } else {
                makeToast(apiMessage(json))
            }
        }
    }
}

struct PayIdPopUpView_Previews: PreviewProvider {
    static var previews: some View {
        PayIdPopUpView(isShow: .constant(true))
    }
}


struct PayIdDetails: View {
    
    var placeholder, value: String
    
    var body: some View {
        
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            
            VStack {
                Text(placeholder)
                    .customFont(.regular, 14)
                    .foregroundColor(Color.blackTxtColor)
            }
            .frame(width: ScreenSize.SCREEN_WIDTH/2 - 50 , alignment: .leading)
            
            VStack {
                HStack(spacing: 5) {
                    Text(value)
                        .customFont(.semibold, 15)
                        .fixedSize(horizontal: false, vertical: true)
                        .foregroundColor(Color.black)
                    
                    if placeholder == "Bank Transfer/PayID" {
                        Button {
                            UIPasteboard.general.string = value
                            makeToast("Copied")
                        } label: {
                            Image(systemName: "doc.on.doc")
                                .font(.subheadline)
                                .foregroundColor(Color.black)
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
           // .frame(width: ScreenSize.SCREEN_WIDTH/2 - 50, alignment: .leading)
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
    }
}


 
