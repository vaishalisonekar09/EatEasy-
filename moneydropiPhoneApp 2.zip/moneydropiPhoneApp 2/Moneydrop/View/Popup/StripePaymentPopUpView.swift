//
//  StripePaymentPopUpView.swift
//  Moneydrop
//
//  Created by Gipl on 17/02/23.
//

import SwiftUI
import StripePayments
import StripePaymentsUI

struct StripePaymentPopUpView: View {
    
    @State private var paymentMethodParams: STPPaymentMethodParams?
    @Binding var isShow: Bool
    var accessToken: ((_ token: String) -> ()) = {_  in }
    
    var body: some View {
        
        ZStack {
            
            Color.black.opacity(0.8).ignoresSafeArea()
            
            ScrollView {
                HStack {
                    Spacer()
                    Button(action: {
                        isShow = false
                    }, label: {
                        Image("cross")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                    })
                    .foregroundColor(Color.white)
                }
                .padding(.horizontal)
            }
            .scrollingDisabled(true)
            
            VStack(spacing: 20) {
                
               STPPaymentCardTextField.Representable.init(paymentMethodParams: $paymentMethodParams)
                
                Button {
                    hideKeyboard()
                    stripePaymentTokenGenerate()
                } label: {
                    Text("Pay now").frame(maxWidth: .infinity)
                }
                .yellowButton()
            }
            .frame(height: 150)
            .padding()
            .background(Color.white)
            .padding()
             
        }
    }
    
    //MARK: - Stripe Payment token generate -
    
    func stripePaymentTokenGenerate() {
        
        showProgressHUD()
        let cardParams = STPCardParams()
        cardParams.number = paymentMethodParams?.card?.number
        cardParams.expMonth = UInt(truncating: paymentMethodParams?.card?.expMonth ?? 0)
        cardParams.expYear = UInt(truncating: paymentMethodParams?.card?.expYear ?? 0)
        cardParams.cvc = paymentMethodParams?.card?.cvc
        
        //MARK: Card valid and Invalid
        
//        let valid = STPCardValidator.validationState(forCard: cardParams) == .valid
        
        STPAPIClient.shared.createToken(withCard: cardParams) { (token, error) in
            
            if error == nil {
                //Success
                DispatchQueue.main.async {
                    if let token = token?.tokenId {
                        accessToken(token)
                        print(token)
                    }
                }
            } else {
                accessToken("Error")
                print(error?.localizedDescription)
                makeToast(error?.localizedDescription ?? "ERROR")
                print("Failed")
            }
        }
    }
    
}

struct StripePaymentPopUpView_Previews: PreviewProvider {
    static var previews: some View {
        StripePaymentPopUpView(isShow: .constant(true))
    }
}


