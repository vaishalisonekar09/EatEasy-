//
//  HomeView.swift
//  Moneydrop
//
//  Created by Gipl on 08/12/22.
//

import SwiftUI
import SDWebImageSwiftUI


struct HomeView: View {
    @State var alertItem                    :   AlertItem?
    @StateObject var viewModel = HomeViewModel()
    
    @State var selection                    :   String?
    @State var selectSenderCountry          =   false
    @State var selectRecipientCountry       =   false
    let columns                             =   [GridItem(.flexible())]
    @State private var flagDataShow         =   [JSON]()
    @State var recentactivity               =   [JSON]()
    
    var body: some View {
        
        ZStack {
            
            Color.lightGray.edgesIgnoringSafeArea(.all)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack(spacing: 0) {
                    
                    HStack(alignment: .top, spacing: 15) {
                        
                        Spacer()
                        
                        NavigationLink(destination:
                                        ReferralCoupenCodeView()) {
                            Image("gift-icon-top")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 30, height: 30)
                        }
                        
                        WebImage(url: URL(string: Storage.image_url))
                            .placeholder {
                                Image("no_image")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 40, height: 40)
                                    .clipShape(Circle())
                            }
                            .resizable()
                            .scaledToFill()
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                    }
                    .padding(.horizontal)
                    .padding(.top, 45)
                    .background(Color.greenColor.edgesIgnoringSafeArea(.top))
                    
                    VStack(spacing: 0) {
                        VStack {
                            
                            VStack {
                                VStack(alignment: .leading, spacing: 0) {
                                    Text("Hello "+Storage.first_name+"!").customFont(.headingBrandon, 30)
                                    Text("Let's start your Transfer")
                                        .customFont(.medium, 16)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundColor(Color.white)
                                
                                VStack(spacing: 7) {
                                    
                                    //MARK: - Sender amount textfield -
                                    
                                    HStack(spacing: 15) {
                                        SendAmountTextField(title: "Amount To Send", placeholder: "0.00", text: $viewModel.sendAmount, onEditingChanged:  { (isBegin) in
                                            viewModel.conversion = 1
                                        })
                                        .onChange(of: viewModel.sendAmount, perform: { value in
                                            if value.isEmpty {
                                                viewModel.recipientAmount = ""
                                            }
                                            
                                            viewModel.sendAmount = value
                                            
                                            if viewModel.received_country_id.isEmpty {
                                                hideKeyboard()
                                                makeToast(Messages.selectToCountry)
                                            } else if viewModel.conversion == 1 {
                                                viewModel.getCurrencyConversionValue()
                                            }
                                        })
                                        
                                        VStack(alignment: .leading, spacing: 17) {
                                            Text("") .customFont(.headingBrandon, 14)
                                            Button {
                                                hideKeyboard()
                                                selectSenderCountry.toggle()
                                            } label: {
                                                HStack{
                                                    
                                                    WebImage(url: URL(string: viewModel.senderCountryFlag))
                                                        .placeholder {
                                                            Image("no_image")
                                                                .resizable()
                                                                .scaledToFill()
                                                                .frame(width: 35, height: 20)
                                                        }
                                                        .resizable()
                                                        .scaledToFill()
                                                        .frame(width: 35, height: 20)
                                                    Spacer()
                                                    Image("white-dropdown")
                                                }
                                                .frame(maxWidth: .infinity)
                                            }
                                        }
                                        .frame(width: 60)
                                        .overlay(
                                            Rectangle().fill(Color.wihteBorder).frame(height: 1)
                                                .frame(maxWidth: .infinity).offset(y:8)
                                            , alignment: .bottomLeading
                                        )
                                    }
                                    .fullScreenCover(isPresented: $selectSenderCountry) {
                                        
                                        CountryPickerWithFlagView(currency:$viewModel.senderCurrency, selectedCountryFlag: $viewModel.senderCountryFlag, country_id: $viewModel.source_country_id, from_country: true) {
                                            // amt_send_country = true
                                            if !viewModel.received_country_id.isEmpty  {
                                                viewModel.getCurrencyConversionValue()
                                            }
                                        }
                                    }
                                    
                                    //MARK: - Recipient textfield -
                                    
                                    HStack(spacing: 15) {
                                        
                                        RecipientAmountTextField(title: "Recipient Will Get", placeholder: "0.00", text: $viewModel.recipientAmount, onEditingChanged:  { (isBegin) in
                                            viewModel.conversion = 2
                                        })
                                        .onChange(of: viewModel.recipientAmount, perform: { value in
                                            
                                            if value.isEmpty {
                                                viewModel.recipientAmount = ""
                                            }
                                            
                                            viewModel.recipientAmount = value
                                            if viewModel.received_country_id.isEmpty {
                                                hideKeyboard()
                                                makeToast(Messages.selectToCountry)
                                            }
                                            else if viewModel.conversion == 2 {
                                                viewModel.getCurrencyConversionValue()
                                            }
                                        })
                                        
                                        VStack(alignment: .leading, spacing: 17) {
                                            Text("") .customFont(.semibold, 14)
                                            Button {
                                                hideKeyboard()
                                                selectRecipientCountry.toggle()
                                            } label: {
                                                HStack{
                                                    if !viewModel.recipientCurrency.isEmpty && !viewModel.received_country_id.isEmpty  {
                                                        
                                                        WebImage(url: URL(string: viewModel.recipientCountryFlag))
                                                            .placeholder {
                                                                Image("no_image")
                                                                    .resizable()
                                                                    .scaledToFill()
                                                                    .frame(width: 35, height: 20)
                                                            }
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(width: 35, height: 20)
                                                    } else {
                                                        Rectangle().fill(Color.greenColor).frame(width: 35, height: 20)
                                                    }
                                                    
                                                    Spacer()
                                                    Image("white-dropdown")
                                                }
                                                .frame(maxWidth: .infinity)
                                            }
                                        }
                                        .frame(width: 60)
                                        .overlay(
                                            Rectangle().fill(Color.wihteBorder).frame(height: 1)
                                                .frame(maxWidth: .infinity).offset(y:8)
                                            , alignment: .bottomLeading
                                        )
                                    }
                                    .fullScreenCover(isPresented: $selectRecipientCountry) {
                                        CountryPickerWithFlagView(currency:$viewModel.recipientCurrency, selectedCountryFlag: $viewModel.recipientCountryFlag, country_id: $viewModel.received_country_id, from_country: false) {
                                            //amt_send_country = false
                                            
                                            if !viewModel.sendAmount.isEmpty {
                                                viewModel.getCurrencyConversionValue()
                                            } else if !viewModel.recipientAmount.isEmpty {
                                                viewModel.getCurrencyConversionValue()
                                            }
                                            
                                        }
                                    }
                                    
                                }
                                
                                //MARK: - Exchange Rate and Processing Fee -
                                
                                VStack (spacing:3) {
                                    
                                    HStack(spacing: 0) {
                                        
                                        Text("Our Exchange Rate")
                                        Text(" 1 \(viewModel.amt_send_country ? viewModel.senderCurrency : viewModel.recipientCurrency)")
                                            .fontWeight(.bold)
                                            .foregroundColor(Color.yellowColor)
                                        Text(" = ")
                                        Text(viewModel.exchangeRate+" \(viewModel.amt_send_country ? viewModel.recipientCurrency : viewModel.senderCurrency) ")
                                            .fontWeight(.bold)
                                            .foregroundColor(Color.yellowColor)
                                    }
                                    
                                    
                                    if viewModel.api_call_status == 1 {
                                        
                                        HStack(spacing: 0) {
                                            
                                            Text("Processing Fee = ")
                                            Text("\(viewModel.processingFee)")
                                            
                                                .fontWeight(.bold)
                                                .foregroundColor(Color.yellowColor)
                                        }
                                    }
                                }
                                .padding(.vertical, 25)
                                .customFont(.regular, 14)
                                .foregroundColor(Color.white)
                                .padding(.bottom, 30)
                                
                            }
                            .padding(.horizontal, 10)
                        }
                        .padding()
                    }
                    .background(Color.greenColor.edgesIgnoringSafeArea(.top))
                    
                    VStack {
                        
                        //MARK: - Recent Activity -
                        
                        VStack {
                            
                            VStack {
                                
                                HStack {
                                    
                                    Text("Recent Activity")
                                        .customFont(.headingBrandon, 17)
                                    Spacer()
                                }
                                .foregroundColor(Color.black)
                                .padding(.top, 20)
                                
                                ScrollView(.vertical, showsIndicators: false) {
                                    
                                    LazyVGrid(columns: [GridItem(.flexible())], alignment: .leading) {
                                        
                                        ForEach(0..<recentactivity.count, id: \.self) { i in
                                            RecentActivityRow(index: i, recentactivity: recentactivity[i])
                                        }
                                        
                                    }
                                    .padding(.bottom, 20)
                                }
                                .background(emptyView(recentactivity.isEmpty))
                            }
                            .padding(.horizontal, 10)
                        }
                        .padding()
                        
                        //MARK: - Transfer Now Button -
                        
                        .overlay(
                            Button(action: {
                                hideKeyboard()
                                
                                viewModel.conversion = viewModel.conversion
                                
                                if viewModel.sendAmount.isEmpty {
                                    makeToast(Messages.enterSentAmount);
                                }
                                else if Double(viewModel.sendAmount) ?? 0 <= 0 {
                                    makeToast(Messages.enterCurrectSentAmount); return
                                }
                                else if viewModel.received_country_id.isEmpty {
                                    makeToast(Messages.selectToCountry)
                                    return
                                }
                                
                                //MARK: - Check document verify and not verified -
                                
                                else  if Storage.is_document_verify == 0 {
                                    checkUserDocument()
                                }
                                else  if Storage.is_selfie_verify == 0 {
                                    checkUserDocument()
                                }
                                else {
                                    selection = "transfer_now"
                                }
                                
                            }, label: {
                                Text("TRANSFER NOW")
                                    .frame(maxWidth: .infinity)
                                    .foregroundColor(Color.black)
                            })
                            .yellowButton()
                            .padding()
                            .padding(.horizontal, 10)
                            .offset(y: -60)
                            , alignment: .topLeading
                        )
                        
                        NavigationLink(destination: BeneficiariesView(sendAmount: $viewModel.sendAmount, recipientAmount: $viewModel.recipientAmount, senderCurrencyCode: $viewModel.senderCurrency, recipientCurrencyCode: $viewModel.recipientCurrency, source_country_id: $viewModel.source_country_id, received_country_id: $viewModel.received_country_id), tag: "transfer_now", selection: $selection) {
                            EmptyView()
                        }
                        
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(.bottom, 90)
                }
                .alert(item: $alertItem, content: { item in
                    item.alert
                })
                .navigationBarBackButtonHidden(true)
                .navigationBarHidden(true)
                .onAppear {
                    
                    flagApicall()
                    getRecentActivity()
                    
                    //MARK: - Document not verified then alert show -
                    
                    //                    if Storage.is_document_verify == 0 {
                    //                        alertItem = AlertItem(alert:    Alert(title: Text("Money Drop"), message: Text("Your document has not been verified yet. Please contact site administrator."), dismissButton: .default(Text("OK"))))
                    //                    }
                    
                }
                .onTapGesture {
                    hideKeyboard()
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
    
    //MARK: - Check document verify and not verified -
    
    func checkUserDocument() {
        hideKeyboard()
        showProgressHUD()
        DataManager.getApiResponse([ApiKey.slug: Storage.slug], methodName: .getUserProfileData) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                
                let result   = json.result
                
                if result.is_document_verify == 0 {
                    makeToast(Messages.verified_document)
                    return
                }
                else if result.is_selfie_verify == 0 {
                    makeToast(Messages.selfieVerify)
                    return
                }
                else {
                    Storage.is_document_verify = result.is_document_verify
                    Storage.is_selfie_verify    = result.is_selfie_verify
                    selection = "transfer_now"
                }
                
            }else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
    // MARK: - Recent Activity Api call -
    
    func getRecentActivity() {
        
        showProgressHUD()
        
        DataManager.getApiResponse([ApiKey.slug: Storage.slug], methodName: .getRecentActivity) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                self.recentactivity = json["model"]["data"].arrayValue
                //print(recentactivity)
            } else {
                let is_logout = json["is_logout"].intValue
                if is_logout == 1 {
                    // Deleted Account Logout
                    userAccountDelete()
                }
                else {
                    makeToast(apiMessage(json))
                }
            }
        }
    }
    
    //MARK: - Flag api call -
    
    func flagApicall() {
        
        showProgressHUD()
        
        let parameter = [ApiKey.from_country: true] as [String : Any]
        DataManager.getApiResponse(parameter, methodName: .currencyListWithFlag) { json, error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                self.flagDataShow           = json["result"].arrayValue
                
                let sender = json["sender"]
                let receiver = json["receiver"]
                
                self.viewModel.senderCountryFlag  = viewModel.senderCountryFlag.isEmpty ?  json.flag_folder_path+sender.flag_name : viewModel.senderCountryFlag
                
                self.viewModel.source_country_id = viewModel.source_country_id.isEmpty ? sender.id : viewModel.source_country_id
                
                self.viewModel.senderCurrency    = viewModel.senderCurrency.isEmpty ? sender.currency : viewModel.senderCurrency
                
                self.viewModel.processingFee = viewModel.recipientCurrency.isEmpty ? "10 AUD" : viewModel.processingFee
                self.viewModel.recipientCurrency = viewModel.recipientCurrency.isEmpty ? sender.currency : viewModel.recipientCurrency
                
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

//MARK: - For Finding index from list (Int)

extension Array where Element: Equatable {
    func indexes(of element: Element) -> [Int] {
        return self.enumerated().filter({ element == $0.element }).map({ $0.offset })
    }
}


//MARK: - Recent Activity Row -

struct RecentActivityRow: View {
    var index: Int
    var recentactivity: JSON
    var body: some View {
        if !recentactivity["recipient_details"].isEmpty {
            
            NavigationLink {
                TransactionDetailsView(transaction_id: recentactivity.id)
            } label: {
                
                VStack {
                    
                    HStack {
                        
                        ZStack {
                            Circle()
                                .fill(index % 2 == 0 ? Color.yellowColor.opacity(0.3) : Color.listLightGreenColor.opacity(0.3))
                                .frame(width: 45, height: 45, alignment: .center)
                            
                            Text(recentactivity["recipient_details"].recipient_name.prefix(1).uppercased())
                                .customFont(.headingBrandon, 30)
                                .foregroundColor(Color.greenColor)
                        }
                        
                        VStack {
                            
                            HStack {
                                Text(recentactivity["recipient_details"].recipient_name.localizedCapitalized)
                                Spacer()
                                let amount = Double(recentactivity.sent_amount)

                                Text("\(amount?.price ?? "0.00")")
                            }
                            .customFont(.bold, 15.8)
                            .foregroundColor(Color.black)
                            
                            HStack {
                                Text(recentactivity.sent_date.getDateStringFromUTC())
                                Spacer()
                                HStack {
                                    Text(recentactivity.sent_currency_code)
                                    Image(systemName: "arrow.left.arrow.right")
                                        .customFont(.regular, 8)
                                    Text(recentactivity.received_currency_code)
                                }
                            }
                            .customFont(.regular, 14)
                            .foregroundColor(Color.lightBlackTxtColor)
                        }
                    }
                    .padding(.horizontal, 7)
                }
                .frame(height: 62)
                .frame(maxWidth: .infinity)
                .background(Color.white)
                .outerShadow()
            }
        }
    }
}

