//
//  ConfirmPaymentView.swift
//  Moneydrop
//
//  Created by Gipl on 23/12/22.
//

import SwiftUI
import WebKit
import StripePayments
import StripePaymentsUI

struct ConfirmPaymentView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @Binding var sendAmount                 :   String
    @Binding var recipientAmount            :   String
    @Binding var senderCurrencyCode         :   String
    @Binding var recipientCurrencyCode      :   String
    @Binding var selected_beneficiary_id    :   String
    @Binding var source_country_id          :   String
    @Binding var received_country_id        :   String
    
    @State var selected_beneficiary         =   JSON()
    @State var sending_reasons              =   [JSON]()
    @State var selected_sending_reasons     =   JSON()
    
    
    @State private var showWebView          =   false
    @State var redirect_url                 =   ""
    @State var selection                    :   String?
    @State var transactionID                =   ""
    @State var currencyCode                 =   ""
    @State var paymentAmount                =   ""
    @State var transactionToasr             =   false
    @State var payment_gateway_type         =   ""
    @State var stripeToken                  =   ""
    
    @State var final_currency               =   ""
    @State var final_amount                 =   ""
    @State var processingFee                =   ""
    @State var transferAmount               =   ""
    @State var sentCurrency                 =   ""
    @State var sentAmount                   =   ""
    @State private var paymentMethodParams  :   STPPaymentMethodParams?
    @State var stripePopShow                =   false
    @State var payIdPopShow                 =   false
    @State var payDescription               =   ""
    
    @State var per_destination_currency         =   ""
    @State var received_country_code            =   ""
    @State var exchange_sent_currency_code      =   ""
    @State var credit_card_transaction_charge   =   ""
    @State var final_amount_with_cc_charges     =   ""
    @State var credit_card_transaction_amount   =   ""
    @State var transfer_amoun                   =   ""
    
    @State var redeem_referral_credit           = false
    @State var coupon_code                      = ""
    
    @State var amount_balance                   =   ""
    @State var user_amount_balance              =   ""
    @State var apply_coupon_code                =   0
    @State var discount_amount                  = ""
    
    @State var discounttype                 =   ""
    @State var discount                     =   ""
    @State var max_discount_allowed         =   ""
 
    @State var site_trans_amount            =   ""
    @State var site_transaction_charge      =   ""
    @State var site_transaction_charge_type =   ""
    @State var tid = ""
    @State var monoova_pay_id   = ""
    @State var currency_code   = ""
 //   @State var final_amount     = ""
        
    var body: some View {
        
        ZStack {
            
            VStack {
                
                HStack {
//                    Button(action: {
//                        presentationMode.wrappedValue.dismiss()
//                    }, label: {
//                        Image("back")
//                    })
                    Spacer()
                    Text("Confirm Payment".uppercased())
                        .customFont(.headingBrandon, 20)
                        .foregroundColor(Color.black)
                    Spacer()
                }
                .padding(.horizontal)
               
                ScrollView(.vertical, showsIndicators: false) {
                    
                    VStack(spacing:0) {
                        
                        VStack(spacing: 10) {
                            ConfirmPaymentDetailsRow(placeholder: "NAME", value: selected_beneficiary.recipient_name)
                            ConfirmPaymentDetailsRow(placeholder: "PHONE NUMBER", value: selected_beneficiary.phone_number)
                            ConfirmPaymentDetailsRow(placeholder: "EMAIL", value: selected_beneficiary.email)
                            ConfirmPaymentDetailsRow(placeholder: "CITY", value: selected_beneficiary.city_name)
                            ConfirmPaymentDetailsRow(placeholder: "STATE", value: selected_beneficiary.state_name)
                            ConfirmPaymentDetailsRow(placeholder: "COUNTRY", value: selected_beneficiary.country_name)
                        }
                        .padding()
                        
                        VStack {
                            Text("EXCHANGE RATE : 1 \(exchange_sent_currency_code) = \(per_destination_currency) \(received_country_code)")
                                .customFont(.bold, 14)
                                .foregroundColor(Color.greenColor)
                                .padding(.horizontal)
                                .padding(.vertical, 10)
                        }
                        .frame(maxWidth: .infinity)
                        .background(Color.grayLightColor)
                        
                        VStack(spacing: 10) {
                            
                            ConfirmPaymentDetailsRow(placeholder: "ACCOUNT/MOBILE NO", value: selected_beneficiary.account_number)
                            ConfirmPaymentDetailsRow(placeholder: "BANK NAME", value: selected_beneficiary.bank_name)
                            
                            let transferAmount1 = Double(transferAmount)
                            let user_transferAmount = transferAmount1?.price
                            
                            let recipientAmount1 = Double(recipientAmount)
                            let recipientAmount2 = recipientAmount1?.price
                            
                            let processingFee1 = Double(processingFee)
                            let processingFee2 = processingFee1?.price
                            
                            let finalamount = Double(final_amount)
                            let total_amount = finalamount?.price
                            
                            let credit_card_transaction_amt = Double(credit_card_transaction_amount)
                            let cc_transaction_amt = credit_card_transaction_amt?.price
                            
                            let final_amount_with_cc = Double(final_amount_with_cc_charges)
                            let final_total_amount = final_amount_with_cc?.price
                            
                            let transfer_amt = Double(transfer_amoun)
                            let beneficiaryGetAmount = transfer_amt?.price
                            
                            ConfirmPaymentDetailsRow(placeholder: "TRANSFER AMOUNT", value: "\(sentCurrency) \(user_transferAmount ?? "0.0")" )
                            ConfirmPaymentDetailsRow(placeholder: "BENEFICIARY WILL GET", value: "\(recipientCurrencyCode) \(recipientAmount2 ?? "0.0") \n(\(final_currency) \(beneficiaryGetAmount ?? "0.0"))")
                            
                            
                            ConfirmPaymentDetailsRow(placeholder: "PROCESSING FEE", value: "\(final_currency) \(processingFee2 ?? "0.0")" )
                            
                            
                            let discount_amt = Double(discount_amount)
                            let discount = discount_amt?.price
                            
                            if redeem_referral_credit {
                                ConfirmPaymentDetailsRow(placeholder: "Referral discount".uppercased(), value: "\(final_currency) \(discount ?? "0.0")" )
                            }
                            
                            if apply_coupon_code == 1 {
                               ConfirmPaymentDetailsRow(placeholder: "Coupon discount".uppercased(), value: "\(final_currency) \(discount ?? "0.0")" )
                            }
                         
                            ConfirmPaymentDetailsRow(placeholder: "TOTAL", value:  "\(final_currency) \(total_amount ?? "0.0")")
                            
                        }
                        .padding()
                    }
                    .grayOuterShadow(5)
                    .padding()
                    
                    VStack {
                         
                        VStack(alignment: .leading) {
                            
                            HStack(spacing:0) {
                                Text("Please select reason for send")
                            }
                            .customFont(.bold, 14)
                            .multilineTextAlignment(.leading)
                            
                            VStack {
                                Menu {
                                    
                                    ForEach(0..<sending_reasons.count, id: \.self) { i in
                                        
                                        Button(action: {
                                            self.selected_sending_reasons = sending_reasons[i]
                                        }) {
                                            HStack {
                                                
                                                Text(sending_reasons[i]["value"].stringValue)
                                               
                                                if selected_sending_reasons.id ==  sending_reasons[i]["id"].stringValue {
                                                    Image(systemName: "checkmark")
                                                }
                                            }
                                        }
                                    }
                                    
                                } label: {
                                    HStack {
                                        Text(selected_sending_reasons.id != "" ? selected_sending_reasons.value :  "Please select season for send")
                                        Spacer()
                                        Image("down-arrow").renderingMode(.template)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .customFont(.regular, 15)
                                    
                                }
                            }
                            .frame(minHeight: 40)
                            .overlay(
                                Rectangle().fill(Color.greenColor).frame(height: 1)
                                    .frame(maxWidth: .infinity),
                                alignment: .bottomLeading
                            )
                         }
                    }
                    .foregroundColor(Color.blackTxtColor)
                    .padding()
                    .grayOuterShadow(5)
                    .padding(.horizontal)
                    .padding(.bottom)
                    
                    //MARK: - Redeem Referral/ Coupon code -
                    
                    VStack (spacing: 20){
                        
                        if Double(user_amount_balance) ?? 0 > 0 {
                            
                            Toggle(isOn: $redeem_referral_credit) {
                                
                                let user_amt_balance = Double(user_amount_balance)
                                let referral_amount = user_amt_balance?.price
                                
                                Text("Redeem referral credit (\(final_currency) \(referral_amount ?? "0.0"))")
                                    .customFont(.semibold, 15)
                            }
                            .onChange(of: redeem_referral_credit) { value in
                                if value {
                                    coupon_code = ""
                                    discount = ""
                                    discounttype = ""
                                    max_discount_allowed = ""
                                    apply_coupon_code = 0
                                }
                                getFinalAmount()
                            }
                        }
                        
                        if redeem_referral_credit != true {
                            
                            VStack(alignment: .leading, spacing: 15) {
                                
                                ZStack(alignment: .leading) {
                                    
                                    if coupon_code.isEmpty {
                                        Text("Enter coupon code")
                                            .foregroundColor(Color.blackTxtColor)
                                    }
                                    
                                    HStack {
                                        TextField("", text: $coupon_code)
                                            .keyboardType(.default)
                                            .disabled(apply_coupon_code == 1 ? true : false)
                                        
                                        Button {
                                            hideKeyboard()
                                            
                                            redeem_referral_credit = false
                                            
                                            if apply_coupon_code == 1 {
                                                
                                                getFinalAmount()
                                                coupon_code = ""
                                                discount = ""
                                                discounttype = ""
                                                max_discount_allowed = ""
                                                apply_coupon_code = 0
                                            }
                                            else {
                                                
                                                if coupon_code.isEmpty {
                                                    makeToast("Please enter your coupon code.")
                                                } else {
                                                    applyCoupon()
                                                }
                                            }
                                            
                                        } label: {
                                            Text(apply_coupon_code == 1 ? "Remove" : "Apply")
                                            
                                                .customFont(.semibold, 15)
                                                .foregroundColor(Color.black)
                                        }
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(Color.yellowColor)
                                        .cornerRadius(5)
                                    }
                                }
                                .frame(height: 20)
                                .overlay(
                                    Rectangle().fill(Color.greenColor).frame(height: 1)
                                        .frame(maxWidth: .infinity)
                                        .offset(y:17)
                                    ,alignment: .bottomLeading
                                )
                            }
                            .multilineTextAlignment(.leading)
                            .customFont(.regular, 15)
                            .padding(.bottom)
                        }
                    }
                    .padding()
                    .grayOuterShadow(5)
                    .padding(.horizontal)
                    // .padding(.bottom, 5)
                    
                    
                    VStack {
                        
                        //MARK: - Payment method -
                        
                        VStack(alignment: .leading, spacing: 15) {
                            
                            HStack(spacing:0) {
                                Text("Please select payment method from below options")
                            }
                            .customFont(.bold, 14)
                            .multilineTextAlignment(.leading)
                            
                            Menu {
                                
//                                Button(action: {
//                                    self.payment_gateway_type = "Poli Payment"
//                                }) {
//                                    Text("Poli Payment")
//                                }
                                Button(action: {
                                    self.payment_gateway_type = "Azupay Payment"
                                }) {
                                    Text("Pay with payID")
                                    
                                }
                                
                                Button(action: {
                                    self.payment_gateway_type = "monoova"
                                }) {
                                    Text("monoova")
                                }
//                                Button(action: {
//                                    self.payment_gateway_type = "PayID"
//                                }) {
//                                    Text("Bank Transfer/PayID")
//                                }
                            } label: {
                                HStack {
                                    
                                    if payment_gateway_type == "Credit Card" {
                                        Text("Debit/Credit Card (3% card fees)")
                                        
                                    } else if payment_gateway_type == "PayID" {
                                        Text("Bank Transfer/PayID")
                                    }
                                    else {
                                        Text(payment_gateway_type != "" ? payment_gateway_type :  "Please select payment type")
                                    }
                                    
                                    Spacer()
                                    Image("down-arrow").renderingMode(.template)
                                }
                                .frame(maxWidth: .infinity)
                                .customFont(.regular, 15)
                            }
                        }
                        .frame(height: 75, alignment: .leading)
                        .foregroundColor(Color.blackTxtColor)
                        .padding()
                        
                    }
                    .grayOuterShadow(5)
                    .padding()
                    
                    let finalamount = Double(final_amount)
                    let total_amount = finalamount?.price
                    
                    let final_amount_with_cc = Double(final_amount_with_cc_charges)
                    let final_total_amount = final_amount_with_cc?.price
                    
                    //MARK: - Credit/Debit Card Charges Note -
                    
                    if payment_gateway_type == "Credit Card" {
                        
                        VStack {
                            
                            Text("* A \(credit_card_transaction_charge)% additional fee will be charged on the amount of \(final_currency) \(total_amount ?? "0.0"). Total amount will be charged ***\(final_currency) \(final_total_amount ?? "0.0")***.")
                            
                                .foregroundColor(Color.redColor)
                                .multilineTextAlignment(.leading)
                                .customFont(.regular, 14)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal)
                        .padding(.bottom, 25)
                    }
                    
                }
                
                VStack{
                    
                    Button {
                        
                        if selected_sending_reasons.id.isEmpty {
                            makeToast(Messages.selectSendingReason)
                            return
                        }
//                        else if payment_gateway_type == "Poli Payment" {
//                            payDescription  = ""
//                            stripeToken     = ""
//                            moneyTransfer()
//                        }
                        else if payment_gateway_type == "Azupay Payment" {
                            payDescription  = ""
                            stripeToken     = ""
                            moneyTransfer()
                        }
                        else if payment_gateway_type == "monoova" {
                     // payDescription  = ""
                   //   stripeToken     = ""
                           moneyTransfer()
                        }
                        
                        else if payment_gateway_type == "Credit Card" {
                            payDescription  = ""
                            stripePopShow.toggle()
                        }
                        else if payment_gateway_type == "PayID" {
                            stripeToken     = ""
                            payIdPopShow.toggle()
                        }
                        else {
                            makeToast("Please select payment type.")
                        }
                        
                    } label: {
                        Text("CONFIRM PAYMENT")
                            .frame(maxWidth: .infinity)
                    }
                    .yellowButton()
                    .padding(.horizontal)
                    .padding(.bottom)
                    
                    //MARK: - Successfully Payment  -
                    
                    NavigationLink(destination: SuccessfullPaymentView(transactionID: $transactionID, currencyCode: $currencyCode, paymentAmount: $paymentAmount, paymentType: $payment_gateway_type), tag: "confirmpayment", selection: $selection) {
                        EmptyView()
                    }
                    
                    NavigationLink( destination: PaymentSuccessView(tid: $tid, monoova_pay_id: $monoova_pay_id, currency_code: $currency_code, final_amount: $final_amount), tag: "paymentsuccess", selection: $selection) {
                        EmptyView()
                    }
                    
                    
                    
                    
                }
                //.padding(.bottom)
            }
            .onTapGesture {
                hideKeyboard()
            }
            
            //MARK: - Poli payment web view -
            
            .fullScreenCover(isPresented: $showWebView, content: {
                NavigationView {
                    PaymentWebView(redirect_url: $redirect_url) { result, token  in
                        //makeToast(result)
                        showWebView = false
                        DispatchQueue.main.asyncAfter(deadline: .now()+1) {
                            //makeToast(result)
                        }
                        if result == "Success transaction" {
                            getTransactionResponse(token: token)
                        }
                    }
                    .navigationBarTitle("", displayMode: .inline)
                        .navigationBarItems(leading:
                                                Button(action: {
                            rootView()?.dismiss(animated: true, completion: nil)
                        }) {
                            Image("back")
                        })
                }
            })
            .navigationBarHidden(true)
            // .edgesIgnoringSafeArea(.bottom)
            //.ignoresSafeArea(.all, edges: .bottom)
            
            //MARK: - Stripe Debit/Credit Card popup show -
            
            if stripePopShow {
                StripePaymentPopUpView(isShow: $stripePopShow) { token in
                    stripePopShow = false
                    if token == "Error" {
                        dismissProgressHUD()
                        makeToast("Please enter valid details.")
                    } else {
                        stripeToken = token
                        moneyTransfer()
                    }
                }
            }
            
            //MARK: - PayID popup show -
            
            if payIdPopShow {
                
                PayIdPopUpView(isShow: $payIdPopShow) { description in
                    payIdPopShow = false
                    payDescription = description
                    moneyTransfer()
                }
            }
        }
        .onAppear {
            getFinalAmount()
        }
    }

    
    //MARK: - Get Final Amount api call -
    
    func getFinalAmount() {
        
        showProgressHUD()
        let parameter = [ApiKey.slug                    :   Storage.slug,
                         ApiKey.sent_amount             :   sendAmount,
                         ApiKey.sent_currency_code      :   senderCurrencyCode,
                         ApiKey.received_currency_code  :   recipientCurrencyCode,
                         ApiKey.received_amount         :   recipientAmount,
                         ApiKey.receive_country_id      :   received_country_id,
                         ApiKey.recipient_id            :   selected_beneficiary_id,
                         ApiKey.coupon_code             :   coupon_code.trimWhitespaces(),
                         ApiKey.source_country_id       :   source_country_id,
                         ApiKey.amount_balance          :  (redeem_referral_credit == false ? "" : user_amount_balance)
                         
        ] as [String:Any]
        
        DataManager.getApiResponse(parameter, methodName: .getFinalAmount) { json, error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                sending_reasons = json["sending_reasons"].arrayValue
                
                self.selected_beneficiary           =   json["recipient"]
                self.final_currency                 =   json.final_currency
                self.final_amount                   =   json.final_amount
                self.processingFee                  =   json.processing_fee
                self.transferAmount                 =   json.sent_amoun
                self.sentCurrency                   =   json.sent_currency
                self.sentAmount                     =   json.sent_amoun
                self.credit_card_transaction_charge =   json.credit_card_transaction_charge
                self.final_amount_with_cc_charges   =   json.final_amount_with_cc_charges
                self.credit_card_transaction_amount =   json.credit_card_transaction_amount
                self.transfer_amoun                 =   json.transfer_amoun
                self.user_amount_balance            =   json.user_amount_balance
                self.discount_amount                =   json.discount_amount
                
                self.site_transaction_charge        =   json.site_transaction_charge
                self.site_trans_amount              =   json.site_trans_amount
                self.site_transaction_charge_type   =   json.site_transaction_charge_type
                
                let exchange_rate                   =   json["exchange_rate"]
                self.per_destination_currency       =   exchange_rate.per_destination_currency
                self.received_country_code          =   exchange_rate.received_country_code
                self.exchange_sent_currency_code    =   exchange_rate.sent_currency_code
                
            } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    
    //MARK: - ApplyCouponCode -
    
    func applyCoupon() {
        var parameter = [:] as [String:Any]
        
        parameter = [ApiKey.slug                     :      Storage.slug,
                     ApiKey.coupon_code              :      coupon_code.trimWhitespaces()
        ]
        showProgressHUD()
        DataManager.getApiResponse(parameter, methodName: .applyCoupon) { json, error in
            
            dismissProgressHUD()
            
            if apiStatus(json) {
                makeToast(apiMessage(json))
                let data = json["couponDetail"]
                self.coupon_code    =   data.coupon_code
                 self.discount      =   data["discount"].stringValue
                self.discounttype   =   data["discounttype"].stringValue
                self.max_discount_allowed   =   data["max_discount_allowed"].stringValue
                
                apply_coupon_code = 1
                getFinalAmount()
            }
            else {
                makeToast(apiMessage(json))
            }
        }
        
    }
    
    //MARK: - Transfer Api call -
    
    func moneyTransfer() {
        
        var paymentType = ""
        
//        if payment_gateway_type == "Poli Payment" {
//            paymentType = "poli"
//        }
//        else
        if payment_gateway_type == "Azupay Payment" {
            paymentType = "azupay"
            
        } else if payment_gateway_type == "monoova" {
            
            paymentType = "monoova"
            
        } else if payment_gateway_type == "Credit Card" {
            paymentType = "stripe"
        } else {
            paymentType = "payid"
        }
        
        showProgressHUD()
        var parameter = [:] as [String:Any]
        parameter = [   ApiKey.slug                     :   Storage.slug,
                        ApiKey.sent_amount              :   sendAmount,
                        ApiKey.sent_currency_code       :   senderCurrencyCode,
                        ApiKey.from_country_code        :   senderCurrencyCode,
                        ApiKey.received_amount          :   recipientAmount,
                        ApiKey.received_currency_code   :   recipientCurrencyCode,
                        ApiKey.received_country_code    :   recipientCurrencyCode,
                        ApiKey.recipient_id             :   selected_beneficiary_id,
                        ApiKey.payment_gateway_type     :   paymentType,
                        ApiKey.stripeToken              :   stripeToken,
                        ApiKey.description              :   payDescription.trimWhitespaces(),
                        ApiKey.received_country_id      :   received_country_id,
                        ApiKey.source_country_id        :   source_country_id,
                        ApiKey.coupon_code              :   coupon_code,
                        
                        ApiKey.discounttype                 :   discounttype,
                        ApiKey.discount                     :   discount,
                        ApiKey.max_discount_allowed         :   max_discount_allowed,
                        ApiKey.discounted_amount            :   discount_amount,
                        
                        ApiKey.used_referal_amount          :   Double(user_amount_balance) ?? 0 > 0 ? (redeem_referral_credit == false ? "" : discount_amount) : "",
                        
                        ApiKey.site_transaction_charge_type :   site_transaction_charge_type,
                        ApiKey.site_transaction_charge      :   site_transaction_charge,
                        ApiKey.site_trans_amount            :   site_trans_amount,
                        ApiKey.final_amount                 :   final_amount,
                        ApiKey.reason_for_send              :   selected_sending_reasons.id
                        
        ]
        
        DataManager.getApiResponse(parameter, methodName: .moneyTransfer) { json, error in
            dismissProgressHUD()
            
            if apiStatus(json) {
                
                // makeToast(apiMessage(json))
                
                //MARK: - Poli payment -
                
//                if payment_gateway_type == "Poli Payment" {
//                    redirect_url = json.redirect_url
//                    showWebView.toggle()
//                }
                if payment_gateway_type == "Azupay Payment" {
                    redirect_url = json.redirect_url
                    showWebView.toggle()
                }
                
                
                
                //MARK: - Stripe payment (Debit/Credit Card) -
                
                else if payment_gateway_type == "Credit Card" {
                    
                    self.paymentAmount  = final_amount
                    self.currencyCode   = final_currency
                    selection           = "confirmpayment"
                }
                else if payment_gateway_type == "monoova" {
                    
                    self.tid  =  json["tid"].stringValue
                    self.monoova_pay_id = json["monoova_pay_id"].stringValue
                    self.currency_code = json["currency_code"].stringValue
                    self.final_amount = json["final_amount"].stringValue


//                    self.paymentAmount  = final_amount
//                    self.currencyCode   = final_currency
                    selection           = "paymentsuccess"
                    
                }
//                else {
//                    self.paymentAmount  = final_amount
//                    self.currencyCode   = final_currency
//                    selection           = "paymentsuccess"
//                }
                
            } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
    
   
    
    //MARK: - getTransactionResponce -
    
    func getTransactionResponse(token: String) {
        
        showProgressHUD()
        let parameter = [ApiKey.token : token, ApiKey.payment_gateway_type : "azupay"] as [String:Any]
        
        DataManager.getApiResponse(parameter, methodName: .getTransactionResponce) { json, error in
            dismissProgressHUD()
            if apiStatus(json) {
                let data = json.result
//                makeToast(apiMessage(json))
                self.paymentAmount  = data["PaymentRequestStatus"].amountReceived
                self.currencyCode   = json["currency_code"].stringValue
                self.transactionID  = data["PaymentRequestStatus"].amountReceived
                selection           = "confirmpayment"
             } else {
                makeToast(apiMessage(json))
            }
        }
    }
    
}

struct ConfirmPaymentView_Previews: PreviewProvider {
    static var previews: some View {
        ConfirmPaymentView(sendAmount: .constant("0"), recipientAmount: .constant("0"), senderCurrencyCode: .constant("AUD"), recipientCurrencyCode: .constant("INR"), selected_beneficiary_id: .constant(""), source_country_id: .constant(""), received_country_id: .constant("") )
    }
}

 
//MARK: - Confirm payment details row -

struct ConfirmPaymentDetailsRow: View {
    var placeholder, value: String
    
    var body: some View {
        
        HStack(alignment: .firstTextBaseline, spacing: 15 ) {
            
            VStack {
                Text(placeholder)
                    .customFont(.semibold, 14)
            }
            .frame(width: ScreenSize.SCREEN_WIDTH/2 - 50 , alignment: .leading)
            
            VStack {
                Text(value)
                    .customFont(placeholder == "BENEFICIARY WILL GET" || placeholder == "TOTAL" ? .semibold : .regular, 15)
                    .fixedSize(horizontal: false, vertical: true)
                    .foregroundColor(placeholder == "BENEFICIARY WILL GET" || placeholder == "TOTAL" ? Color.black : Color.blackTxtColor)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
    }
}


 




