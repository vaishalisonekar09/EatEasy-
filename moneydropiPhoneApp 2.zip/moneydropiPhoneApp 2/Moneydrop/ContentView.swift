//
//  ContentView.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
         Image("launch_image")
                .resizable()
                .scaledToFill()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
