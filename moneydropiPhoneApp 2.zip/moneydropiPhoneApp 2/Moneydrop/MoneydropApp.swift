//
//  MoneydropApp.swift
//  Moneydrop
//
//  Created by Gipl on 07/12/22.
//

import SwiftUI
import LocalAuthentication
import StripePayments
 
@main
struct MoneydropApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        
        WindowGroup {
            if Storage.login == "yes" {
                NavigationView { TabBarView() }
            } else {
                IntroductionView()
            }
        }
    }
}



func checkDeviceAuthentication() {
    let context = LAContext()
    var error:NSError?
    guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
        print(error?.localizedDescription)
        Storage.is_screen_lock = false
        return
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        checkDeviceAuthentication()
        
        // register notification
        registerForNotification(application)

        StripeAPI.defaultPublishableKey = Config.stripePublishableKey
 
        return true
    }
    
}

extension AppDelegate: UNUserNotificationCenterDelegate {
    
    func registerForNotification(_ application: UIApplication) {
        
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .badge, .sound]) { (granted, error) in
        }
        
        let notificationCenter = UNUserNotificationCenter.current()
        
        application.registerForRemoteNotifications()
        notificationCenter.delegate = self
    }
    
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        var cleanToken = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        cleanToken = cleanToken.lowercased()
        Storage.deviceToken = cleanToken
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let data = JSON(notification.request.content.userInfo) 
        print(data)
        completionHandler([.alert, .badge, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        let data = JSON(response.notification.request.content.userInfo)
        print(data)
        completionHandler()
    }
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // self.window?.rootViewController = UIHostingController(rootView: TabBarController().edgesIgnoringSafeArea(.all))
        return true
    }
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        let sceneConfig = UISceneConfiguration(name: nil, sessionRole: connectingSceneSession.role)
        sceneConfig.delegateClass = SceneDelegate.self
        return sceneConfig

    }
    
    
}


class SceneDelegate: NSObject, UIWindowSceneDelegate, ObservableObject {
    
    func sceneDidBecomeActive(_ scene: UIScene) {
        
        checkUpdate()
    }
    
    func checkUpdate() {
        
        guard let info = Bundle.main.infoDictionary, let identifier = info["CFBundleIdentifier"] as? String, let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)"), let currentVersion = info["CFBundleShortVersionString"] as? String else { return }
        do {
            
            let data = try Data(contentsOf: url)
            let json: JSON = try JSON(data: data)
            if let result = json["results"].array?.first, let version = result["version"].string {
                print("version in app store", version)
                print("current Version", currentVersion)
                
                if Double(version)! > Double(currentVersion)! {
                    popupUpdateDialogue(version)
                }
            }
        } catch {
            print("ERROR FOUND: ", error)
        }
    }
    
    
    func popupUpdateDialogue(_ versionInfo: String ) {
        
        let alertMessage = "A new version of"+" \(Config.APP_NAME) "+"Application is available, Please update to version "+versionInfo;
        let alert = UIAlertController(title: "New Version Available", message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        
        let okBtn = UIAlertAction(title: "Update", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            if let url = URL(string: "itms-apps://itunes.apple.com/us/app/\(Config.APP_ID)"),
               UIApplication.shared.canOpenURL(url){
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
            rootView()?.present(alert, animated: true, completion: nil)
        })
        alert.addAction(okBtn)
        rootView()?.present(alert, animated: true, completion: nil)
    }

}
