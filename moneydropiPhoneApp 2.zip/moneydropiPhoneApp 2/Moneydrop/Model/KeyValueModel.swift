//
//  CountryListModel.swift
//  Moneydrop
//
//  Created by Gipl on 26/12/22.
//

import Foundation

struct KeyValueModel: Identifiable {
    
    var id   :       String
    var value    :   String
    
    init(id : String ,value : String) {
        self.id            = id
        self.value         = value
    }
}

 
