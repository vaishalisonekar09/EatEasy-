//
//  TransactionModel.swift
//  Moneydrop
//
//  Created by Gipl on 02/02/23.
//

import Foundation

class TransactionModel: Identifiable {
    
    var id                          =   UUID().uuidString
    var _id                         :   String
    var sent_amount                 :   String
    var sent_date                   :   Double
    var sent_currency_code          :   String
    var received_currency_code      :   String
    var recipient_name              :   String
     
    init(_ j: JSON) {
        self._id                        =   j.id
        self.sent_amount                =   j.sent_amount
        self.sent_date                  =   j.sent_date
        self.sent_currency_code         =   j.sent_currency_code
        self.received_currency_code     =   j.received_currency_code
        self.recipient_name             =   j["recipient_details"].recipient_name
    }
}
