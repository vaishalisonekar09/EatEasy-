//
//  BeneficiariesModel.swift
//  Moneydrop
//
//  Created by Gipl on 23/01/23.
//

import Foundation

class BeneficiariesModel: Identifiable {
    
    var id              =   UUID().uuidString
    var _id             :   String
    var email           :   String
    var dial_code       :   String
    var phone           :   String
    var account_number  :   String
    var bank_name       :   String
    var recipient_name  :   String
    var iban_code       :   String
    var bic_code        :   String
    var swift_code      :   String
    var address         :   String
    var country_name    :   String
    var city_name       :   String
    var state_name      :   String
    var country_id      :   String
    var city_id         :   String
    var state_id        :   String
    var zip_code        :   String
    var pg_bank_id      :   String
    var is_active       :   Int
    
    init(_ j: JSON) {
        
        self._id                =   j.id
        self.email              =   j.email
        self.dial_code          =   j.dial_code
        self.phone              =   j.phone
        self.account_number     =   j.account_number
        self.bank_name          =   j.bank_name
        self.recipient_name     =   j.recipient_name
        self.iban_code          =   j.iban_code
        self.bic_code           =   j.bic_code
        self.swift_code         =   j.swift_code
        self.address            =   j.address
        self.country_name       =   j["country_name"].country_name
        self.state_name         =   j["state_name"].state_name
        self.city_name          =   j["city_name"].city_name
        self.zip_code           =   j.zip_code
        self.country_id         =   j.country
        self.state_id           =   j.state
        self.city_id            =   j.city
        self.pg_bank_id         =   j.pg_bank_id
        self.is_active         =   j.is_active
    }
}
