//
//  AlertItem.swift
//  Moneydrop
//
//  Created by Gipl on 23/12/22.
//

import SwiftUI

struct AlertItem: Identifiable {
    var id = UUID().uuidString
    var alert: Alert
}
