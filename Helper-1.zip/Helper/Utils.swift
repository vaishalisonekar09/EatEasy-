//
//  Utils.swift
//  AxisVD
//
//  Created by Gipl on 14/09/23.
//

import SwiftUI

//MARK: - Custom Views
func titleView(_ title: String) -> some View {
    Text(title)
        .font(h18Font)
        .foregroundColor(.white)
}
