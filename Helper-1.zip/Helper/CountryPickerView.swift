//
//  CountryPickerView.swift
//  AxisVD
//
//  Created by gipl on 13/09/23.
//

import SwiftUI

struct CountryPickerView: View {
    
    @Binding var  country_name: String
    
    @Environment(\.presentationMode) var presentation
    
    @State private var countries = [JSON]()
    @State private var filter_countries = [JSON]()
    @State private var search_text = ""
    
    var body: some View {
        
        NavigationView {
            
            VStack(spacing: 0) {
                
                TextField("Search", text: $search_text)
                    .frame(height: 44)
                    .padding(.horizontal)
                    .onChange(of: search_text) { newValue in
                        doSearch()
                    }
                
                Divider()
                
                List {
                    ForEach(0..<filter_countries.count, id: \.self) { i in
                        Button {
                            country_name = filter_countries[i].name
                            presentation.wrappedValue.dismiss()
                            
                        } label: {
                            HStack(spacing: 10) {
                           
                                VStack(alignment: .leading, spacing: 4) {
                                    
                                    Text(filter_countries[i].name)
                                        .foregroundColor(.white)
                                }
                                
                                Spacer(minLength: 0)
                                
                                if country_name == filter_countries[i].name {
                                    Image(systemName: "checkmark")
                                }
                            }
                        }
                        
                    }
                } .listStyle(.plain)
                
            }.navigationBarTitle(Text(""), displayMode: .inline)
                .toolbar {
                    
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button {
                            self.presentation.wrappedValue.dismiss()
                        } label: {
                            Image(systemName: "xmark")
                                .foregroundColor(.white)
                                .imageScale(.large)
                        }
                    }
                    
                    ToolbarItem(placement: .principal) {
                        Text("Countries")
                            .font(h28Font)
                    }
                }
                .foregroundColor(.white)
                .onAppear {
                    loadData()
                }
        }
    }
    
    func doSearch() {
        if search_text.isEmpty {
            filter_countries = countries
        } else {
            filter_countries = countries.filter {
                $0.name.lowercased().range(of: search_text.lowercased()) != nil ||
                $0.dial_code.lowercased().range(of: search_text.lowercased()) != nil
            }
        }
    }
    
    func loadData()  {
        guard let url = Bundle.main.url(forResource: "countries", withExtension: "json")
        else {
            print("Json file not found")
            return
        }
        
        let data = try? Data(contentsOf: url)
        let json = JSON(data ?? Data())
        self.countries = json.arrayValue
        doSearch()
    }
}

struct CountryPickerView_Previews: PreviewProvider {
    static var previews: some View {
        CountryPickerView(country_name: .constant(""))
    }
}
