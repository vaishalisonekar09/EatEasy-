//
//  Constants.swift
//  AxisVD
//
//  Created by Gipl on 18/09/23.
//

import SwiftUI

struct SSize {
    static let WIDTH = UIScreen.main.bounds.size.width
    static let HEIGHT = UIScreen.main.bounds.size.height
}


struct Storage {
    @AppStorage("login") static var login = false
}
