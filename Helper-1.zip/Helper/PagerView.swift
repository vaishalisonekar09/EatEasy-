//
//  PagerView.swift
//  AxisVD
//
//  Created by Gipl on 02/10/23.
//

import SwiftUI

struct PagerView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct PagerView_Previews: PreviewProvider {
    static var previews: some View {
        PagerView()
    }
}
