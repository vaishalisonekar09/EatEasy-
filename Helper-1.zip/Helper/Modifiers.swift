//
//  Modifiers.swift
//  AxisVD
//
//  Created by Gipl on 11/09/23.
//

import SwiftUI

struct AuthBaseModifier: ViewModifier {
    
    func body(content: Content) -> some View {
        
        ZStack(alignment: .bottom) {
            
            Color.bgColor
                .ignoresSafeArea()
            
            Image("vd")
            
            content
        }
    }
}

struct BlackBackgroundModifier: ViewModifier {
    
    func body(content: Content) -> some View {
        
        ZStack(alignment: .bottom) {
            
            Color.bgColor
                .ignoresSafeArea()
            
            content
        }
    }
}

struct GradientView: ViewModifier {
    
    let height: CGFloat
    
    init(_ height: CGFloat = 48) {
        self.height = height
    }
    
    func body(content: Content) -> some View {
        
        content
            .font(p4Font)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: self.height)
            .background(
                LinearGradient(colors: [Color.blueColor, Color.greenColor], startPoint: .leading, endPoint: .trailing)
            )
            .cornerRadius(8)
    }
}

struct Modifier_Previews: PreviewProvider {
    
    static var previews: some View {
        
        ZStack {
            
            Color.bgColor
                .ignoresSafeArea()
            
            Text("Log in")
            .modifier(GradientView())
            
        }.foregroundColor(.white)
    }
}
