//
//  TextField.swift
//  AxisVD
//
//  Created by Gipl on 11/09/23.
//

import SwiftUI

struct CustomTextField: View {
    
    let title: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var isSecure = false
    var rightView: AnyView?
    var is_required = true
    var is_dropdown = false
    
    @State private var editingChanged = false
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 5) {
            
            Text("\(title) \(Text(is_required ? "*" : "").foregroundColor(.redColor))")
                .font(p4Font.bold())
            
            ZStack(alignment: .leading) {
                
                if text.isEmpty {
                    Text(placeholder)
                }
                
                HStack {
                    
                    if is_dropdown {
                        
                        Text(text)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .frame(height: 40)
                        
                    } else if isSecure {
                        SecureField("", text: $text)
                    } else {
                       
                        TextField("", text: $text) { editingChanged in
                            withAnimation {
                                self.editingChanged = editingChanged
                            }
                        }
                    }
                
                    if let rightView = self.rightView {
                        rightView
                    }
                }
            }
            .keyboardType(keyboardType)
            .frame(height: 20)
            .font(p6Font)
        }
        .padding(12)
        .frame(height: 65)
        .overlay (
            RoundedRectangle(cornerRadius: 12)
                .stroke(editingChanged ? Color.greenColor : Color.white.opacity(0.5), lineWidth: 1)
        )
    }
}

struct LineTextField: View {
    
    let title: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var rightView: AnyView?
    var isDropDown = false
    
    @State private var editingChanged = false
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            VStack(alignment: .leading, spacing: 0) {
                
                Text(title)
                    .font(h16Font.bold())
                
                ZStack(alignment: .leading) {
                    
                    if text.isEmpty {
                        Text(placeholder)
                            .foregroundColor(.borderColor)
                    }
                    
                    HStack {
                        
                        if isDropDown {
                            
                            Text(text)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .frame(height: 40)
                            
                        } else {
                            TextField("", text: $text) { editingChanged in
                                withAnimation {
                                    self.editingChanged = editingChanged
                                }
                            }
                            .frame(height: 40)
                        }
                        
                        if let rightView = self.rightView {
                            rightView
                        }
                    }
                }
                .keyboardType(keyboardType)
                .font(p6Font)
            }
            .padding(.horizontal)
            
            Divider()
                .overlay(editingChanged ? Color.blueColor : Color.white)
            
        }
    }
}

struct LineTextEditor: View {
    
    let title: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var rightView: AnyView?
    
    @State private var editingChanged = false
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            VStack(alignment: .leading, spacing: 0) {
                
                Text(title)
                    .font(h16Font.bold())
                
                ZStack(alignment: .leading) {
                    
                    if text.isEmpty {
                        Text(placeholder)
                            .foregroundColor(.borderColor)
                    }
                    
                    HStack {
                        
                        TextEditor(text: $text)
                            .frame(height: 80)
                        
                        if let rightView = self.rightView {
                            rightView
                        }
                    }
                }
                .keyboardType(keyboardType)
                .font(p6Font)
            }
            .padding(.horizontal)
            
            Divider()
                .overlay(editingChanged ? Color.blueColor : Color.white)
            
        }
        .foregroundColor(.white)
    }
}

struct TextField_Previews: PreviewProvider {
    
    static var previews: some View {
        
        ZStack {
            
            Color.red.ignoresSafeArea()
            
            LineTextEditor(title: "Email", placeholder: "Enter your email", text: .constant(""))
            
        }.foregroundColor(.white)
            
    }
}
