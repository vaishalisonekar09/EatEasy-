//
//  Font.swift
//  AxisVD
//
//  Created by Gipl on 11/09/23.
//

import SwiftUI

struct Poppins {
    static var light    = "Poppins-Light"
    static var regular  = "Poppins-Regular"
    static var medium   = "Poppins-Medium"
    static var semiBold = "Poppins-SemiBold"
    static var bold     = "Poppins-Bold"
}

struct Nunito {
    static var light    = "Nunito-Light"
    static var regular  = "Nunito-Regular"
    static var medium   = "Nunito-Medium"
    static var bold     = "Nunito-Bold"
}

var h28Font: Font {
    Font.custom(Poppins.bold, size: 28)
}

var h20Font: Font {
    Font.custom(Poppins.bold, size: 20)
}

var h18Font: Font {
    Font.custom(Poppins.semiBold, size: 18)
}

var h16Font: Font {
    Font.custom(Poppins.semiBold, size: 16)
}


var p7Font: Font {
    Font.custom(Nunito.regular, size: 17)
}

var p6Font: Font {
    Font.custom(Nunito.regular, size: 16)
}

var p5Font: Font {
    Font.custom(Nunito.regular, size: 15)
}

var p4Font: Font {
    Font.custom(Nunito.regular, size: 14)
}

var p3Font: Font {
    Font.custom(Nunito.regular, size: 13)
}

var p2Font: Font {
    Font.custom(Nunito.regular, size: 12)
}

var p1Font: Font {
    Font.custom(Nunito.regular, size: 11)
}

