//
//  Color.swift
//  AxisVD
//
//  Created by Gipl on 11/09/23.
//

import SwiftUI

extension Color {
    
    init(_ hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: alpha
        )
    }
    
    static let bgColor      = Color("bgColor")
    static let blueColor    = Color("blueColor")
    static let greenColor   = Color("greenColor")
    static let borderColor  = Color("borderColor")
    static let grayColor    = Color("grayColor")
    static let skyBlueColor = Color("skyBlueColor")
    static let purpleColor  = Color("purpleColor")
    static let redColor     = Color("redColor")
    static let btnBgColor   = Color("btnBgColor")
    
}
