//
//  MediaPicker.swift
//  AxisVD
//
//  Created by Gipl on 18/09/23.
//

import SwiftUI
import YPImagePicker

struct MediaPicker: UIViewControllerRepresentable {
    
    typealias UIViewControllerType = YPImagePicker
    
    var completion: (UIImage) -> Void = {_ in}
    
    func makeUIViewController(context: Context) -> YPImagePicker {
        
        var config = YPImagePickerConfiguration()
        config.libraryMediaType = .photoAndVideo
        
        let picker = YPImagePicker(configuration: config)
        
        picker.didFinishPicking { [unowned picker] items, _ in
            
            picker.dismiss(animated: true, completion: nil)
            
            for item in items {
                switch item {
                case .photo(let photo):
                    completion(photo.image)
                default:
                    break
                }
            }
            
        }
        
        return picker
    }
    
    func updateUIViewController(_ uiViewController: YPImagePicker, context: Context) {
        
    }
}

struct MediaPicker_Previews: PreviewProvider {
    static var previews: some View {
        MediaPicker()
    }
}
